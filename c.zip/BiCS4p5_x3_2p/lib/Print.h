/************************************************************************************************
    File name   : Print.h
    Description : General Print functions
    Revision    : 6.1
************************************************************************************************/

void Check_Ascii(char *array, uint8 length)
{
    uint8 i;
    for(i = 0; i < length; i++)
    {
        if((array[i]>=33)&&(array[i]<=122))
            ;
        else
            array[i]='?';
    }
}

void Print_Test_Beginning(uint8 section)
{
    print(0,"\n ++++++ CDT Section ~ ++++++ \n", section);
}

void Print_TB_Number(uint16 number)
{
    print(0, "Test Block Number: ~\n", number);
}

void Print_Init_Info()
{
    print(0,"Product: %\n", PRODUCT_STR);
    print(0,"Code Rev: ~\n", MTST_REVISION);
    print(0,"Lib Rev: ~\n",  LIB_REVISION);
    print(0,"Log Format Rev: ~\n", CDT_LOG_REV);
    print(0,"TOTAL DIE: ~\n", TOTAL_DIE);
    print(0,"TOTAL PLN: ~\n", TOTAL_PLN);
}

void Print_CST_HW_Info()
{
    print(0,"DC HW Ver: ~\n", g_Daughter_Card_Ver);
    print(0,"DUT#     : ~\n", DC_DUT);
    print(0,"BIB S/N  : $$$$$$\n", BIB_SN);
    print(0,"DC TEST  : ^^/^^/^^^^ ", ((DC_DATE>>8)&0xFF), (DC_DATE&0xFF), (((DC_DATE>>24)&0x00FF) | ((DC_DATE>>8)&0xFF00)));
    print(0,"^^:^^:^^\n", ((DC_TIME>>16)&0xFF),((DC_TIME>>8)&0xFF), (DC_TIME&0xFF));
}

void Print_Dut_Location_CST(uint8 col_num, uint8 row_num)
{
    print(0,"Size: ~*~\n", col_num, row_num);
    if((DC_DUT>0)&&(DC_DUT<=col_num*row_num))
    {
        uint8 col_now=12-((DC_DUT-1)/row_num);
        uint8 row_now=(DC_DUT-1)%row_num;
        uint8 words[2];
        words[1]='\0';
        words[0]='A'+row_now;
        print(0,"Location : %~\n", words, col_now);
    }
    else print(0,"Location : FF\n");
}

// void Print_ID(uint8 die)
// {
//     uint8 i;

//     print(0, "ID_DIE@: ", die);

//     for(i = 0; i < 5; i++)
//     {
//         print(1, "@ ", g_ID_Byte[die][i]);
//     }

//     print(0, "\n");
// }

// if input value of str is 0xFF, this function won't print str information
/*
void Print_Stamp(uint8 die, uint16 blk, uint8 WL, uint8 Str, uint16 start_col, uint8 BytesNo)
{
    uint8 i;

	print(0, "Stamp_DIE@_BLK@_WL$$_STR$_COL$$$$: ", die, blk, WL, Str, start_col);

    for(i = 0; i < BytesNo; i++)
    {
    	  print(0, "$$ ", g_Stamp_Byte[die][i]);
    }

    print(0, "\n");
}
*/
void Print_DS_Parm_Ver(uint8 die, int Ver)
{
    uint64 Ver_t=Ver;
    uint8 data[2], i;
    data[1]='\0';

    print(0,"DSParm_DIE@: ",die);
    for(i = 0; i < 5; i++)
    {
        data[0]=(Ver_t>>(8*(4-i)));
        if (data[0]!=0x00)
            print(0,"%", data);
    }
    print(0,"\n");
}

void Print_Temperature(uint8 PrtLev)
{
    uint8 i;
    print(PrtLev,"Temp: ");
    for(i = 0; i < TOTAL_DIE; i++)
    {
        if (g_temperature_array[i]>=42)    print(PrtLev,"~ ", g_temperature_array[i]-42);
        else    print(PrtLev,"-~ ", 42-g_temperature_array[i]);
    }
    print(PrtLev,"\n");
}

void Print_BB(uint8 BBType)
{
    uint8 pln, die;
    uint16 blk, cnt;

    for(die = 0; die < TOTAL_DIE; die++)
    {
        for(pln = 0; pln < TOTAL_PLN; pln++)
        {
            cnt = 0;

            print(0, "GBB_DIE@_P$: ", die, pln);

            for (blk = pln; blk < TOTAL_BLK; blk+=TOTAL_PLN)
            {
                if(Is_BB(die, blk, BBType))
                {
                    cnt++;
                    print(0, "@ ", blk);
                }
            }

            print(0, "cnt = ~\n", cnt);
        }
    }

}

void Print_Wafer_Info(uint8 die, char **all)
{
    uint8 i, j, length[]={LOT_LEN-1, W_LEN-1, X_LEN-1, Y_LEN-1};
    
    for(i=0; i<4; i++)
    {
        Check_Ascii(all[i], length[i]);
        
        FOR_EACH_LOOP(j, 0, length[i], 1)
        {
            switch(i)
            {
                case 0: {
                            g_WXY[die][j] = (uint8)(all[i][j]);
                            break;
                        }
                case 1: {
                            g_WXY[die][j+LOT_LEN-1] = (uint8)(all[i][j]);
                            break;
                        }
                case 2: {
                            g_WXY[die][j+LOT_LEN+W_LEN-2] = (uint8)(all[i][j]);
                            break;
                        }
                case 3: {
                            g_WXY[die][j+LOT_LEN+W_LEN+X_LEN-3] = (uint8)(all[i][j]);
                            break;
                        }
            }
            
        }
    }

    print(0,"DIE@ LOT:% W:% X:% Y:%\n", die, all[0], all[1], all[2], all[3]);
}

void Print_Param()
{
    uint8 die;
    uint16 Parm_addr, Parm_cnt;

    for(die = 0; die < TOTAL_DIE; die++)
    {
        print(0, "P_DIE$$ 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n", die);

        for (Parm_cnt = 0x10; Parm_cnt < TOTAL_PARA; Parm_cnt++)
        {
            Parm_addr = Parm_cnt;

            if(Parm_cnt % 16 ==0)
            {
                if(Parm_cnt != 0x10) PrtLog(0, "\n");
            }

            if(Parm_cnt % 16 == 0) print(0, "P0x$$$: ", Parm_addr);

            print(0, "$$ ", g_Incoming_Para[die][Parm_cnt]);
        }

        print(0, "\n\n");
    }
}

void Print_BC(uint8 die, uint8 plane, uint8 pre_pst_mask)
{
    uint16 col=0, cnt=0, idx;
    uint8 bitmask;

    cnt=0;

    print(0, "BC_DIE@_P$: ", die, plane);

    bitmask = 0xFF&(pre_pst_mask<<(plane*4));

    for(col=0; col<TOTAL_COL; col+=2)
    {
        idx = (col&0xFFFE)/2;
        if((g_Temp_Col[idx]&bitmask)==bitmask)
        {
            cnt++;
            print(0, "@ ", col);
        }
    }
    print(0, "cnt = ~\n", cnt);
}

void Print_GBC(uint8 die, uint8 plane, uint8 pre_pst_mask)
{
    uint16 col=0, cnt=0, idx;
    uint8 pre_bitmask, pst_bitmask;

    cnt=0;

    if(pre_pst_mask!=PSTBCMASK)
    {
        print(0, "Invalid GBC printing mask\n");
    }

    print(0, "GBC_DIE@_P$: ", die, plane);

    pre_bitmask = 0xFF&(PREBCMASK<<(plane*4));
    pst_bitmask = 0xFF&(PSTBCMASK<<(plane*4));

    for(col=0; col<TOTAL_COL; col+=2)
    {
        idx = (col&0xFFFE)/2;

        if(((g_Temp_Col[idx]&pre_bitmask)!=pre_bitmask)&&((g_Temp_Col[idx]&pst_bitmask)==pst_bitmask))
        {
            cnt++;
            print(0, "@ ", col);
        }
    }
    print(0, "cnt = ~\n", cnt);
}

void Print_Pln_Failure(uint8 die,uint8 pln, const char *string)
{
    print(0,"##DIE@ failed % on PLN@\n",die, string,pln);
}

// void Print_Hard_Bin(uint8 bincode)
// {
//     print(0,"##HBin:@\n", bincode);
// }

//print status, if any address info is None, please input 0xFF or 0xFFFF. These function will ignore print 0xE0 and the failue blocks which in MAIN
//if title is None, please input ""
// void Print_Status(uint8 PrtLev, const char *title, uint8 die, uint16 block, uint8 wl, uint8 str, uint8 prefix, uint8 cmd, uint8 status)
// {
//     uint8 pln0_flag=0, pln1_flag=0, block_p0_flag=0, block_p1_flag=0;
//     uint16 block_p0, block_p1;

//     if(status !=0xE0)
//     {
//         if((cmd==0x71)||(cmd==0x72))
//         {
//             if(block<TOTAL_BLK)
//             {
//                 pln0_flag=status&0x02;
//                 pln1_flag=status&0x04;
//                 block_p0=block&0xFFFE;
//                 block_p1=block_p0+1;
//                 block_p0_flag=BB_Check(die, block_p0, MAIN);
//                 block_p1_flag=BB_Check(die, block_p1, MAIN);

//                 if((pln0_flag&&!block_p0_flag)||(pln1_flag&&!block_p1_flag))
//                 {
//                     print(PrtLev, "%Status(0x@)_DIE@_BLK@", title,cmd,die,block);
//                     if (wl!=0xFF)   print(PrtLev, "_WL@", wl);
//                     if (str!=0xFF)  print(PrtLev, "_STR@",str);
//                     if (prefix!=0xFF) print(PrtLev, "_PRE@", prefix);
//                     print(PrtLev, ": @\n", status);
//                 }
//                 else if((status!=0xE3)&&(status!=0xE5)&&(status!=0xE7))//other stange status
//                 {
//                     print(PrtLev, "%Status(0x@)_DIE@_BLK@", title,cmd,die,block);
//                     if (wl!=0xFF)   print(PrtLev, "_WL@", wl);
//                     if (str!=0xFF)  print(PrtLev, "_STR@",str);
//                     if (prefix!=0xFF) print(PrtLev, "_PRE@", prefix);
//                     print(PrtLev, ": @\n", status);
//                 }
//             }
//             else print(PrtLev, "Please input valid block address for cmd 0x71 & 0x72!\n");
//         }

//         else if(cmd==0x70)
//         {
//             if((BB_Check(die, block, MAIN)==0)||(block==0xFFFF))
//             {
//                 print(PrtLev, "%Status(0x@)_DIE@", title,cmd,die);
//                 if (block!=0xFFFF) print(PrtLev, "_BLK@", block);
//                 if (wl!=0xFF)   print(PrtLev, "_WL@", wl);
//                 if (str!=0xFF)  print(PrtLev, "_STR@",str);
//                 if (prefix!=0xFF) print(PrtLev, "_PRE@", prefix);
//                 print(PrtLev, ": @\n", status);
//             }
//         }

//         else    print(PrtLev,"unknown check status command\n");
//     }
// }
void Print_Test_Failure(uint16 bincode, const char *string)
{
    print(0,"##FAIL: C$$$ %\n", bincode, string);
}

void Print_Test_Pass(uint8 section)
{
    print(0,"\n ++++++ Section ~ Completed ++++++ \n", section);
}

void Print_Die_Failure(uint8 die, const char *string)
{
    print(0,"##DIE@ failed %\n",die, string);
}

void Print_Die_Failure_Add_BD(uint8 die, const char *string)
{
    Print_Die_Failure(die, string);
    BD_Add(die, TEMP);
}

void Efuse_WF_Info()
{
    uint32 tmp32;
    extern Status_t Efuse_Read_ROM(uint32 EfuseWord, uint32 *data);
    // PrtLog(TB_NAME_PRINT_LEVEL,  "d_Efuse_WF_Info\n");

    if(ENABLE_EFUSE_CRC_CHECK)
    {
        print(0,"DC Efuse Code: ");
        Efuse_Read_ROM(0, &tmp32);
        print(0,"$$$$",(tmp32>>16)&0xFFFF);//Wafer Lot
        print(0,"$$",(tmp32>>8)&0xFF);//X coordinate
        Efuse_Read_ROM(3, &tmp32);
        print(0,"$$",(tmp32>>3)&0xFF);//Y coordinate new
        Efuse_Read_ROM(1, &tmp32);
        print(0,"$$\n",tmp32&0x1F);//Wafer ID
    }
}
void Print_Die_Map(uint8 map_type)
{
    uint8 die, cnt=0;

    print(0,"Fail_Die:");
    for(die=0; die<TOTAL_DIE; die++)
    {
        if(Is_Bad_Die(die, map_type))
        {
            cnt++;
            print(0,"$ ",die);
        }
    }
    print(0,"cnt = ~\n", cnt);
}

void Print_Key_Value_Start(const char *string)
{
    PrtLog(0, "$");
    print(0,"%:",string);
}
void Print_Key_Value_Stop(uint8 die, uint8 pln)
{
    PrtLog(0, "$");
    if(pln>=TOTAL_PLN) print(0,"D@\n", die);
    else print(0,"D@ P~\n", die, pln);
}
void Print_Pln_Failure_Add_BD(uint8 die,uint8 pln, const char *string)
{
    print(0,"##DIE@ failed % on PLN@\n",die, string, pln);
    BD_Add(die, TEMP);
}