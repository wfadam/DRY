uint8 t_SCREEN_bl_leak_0gbc_scr2331p0(void)  //tb__167 nvcc SCR902p3
{
    uint8 die, P91_Value;

#ifdef DENS_256_SW
    P91_Value = 0x06;
#endif
#ifdef DENS_512_SW
    P91_Value = 0x0B;
#endif

    Para_Table Para_Array[] =
    {
        {0x103, 0x00, 0x20}, // NEG_SLC = 0
        {0x0AB, 0x00, 0x0F}, // ZONESTEP =0; ZONESTEP_WL=0
        {0x06C, 0x0A, 0x0F}, // set VBLC_PVFY_SLC to 0.5V
        {0x06B, 0x10, 0x1F}, // set VBLC_PVYF_MLC to 0.4V
        {0x093, 0x1F, 0x1F}, // set R5_READ_SLC or RP7 =42.32 us(Max)
        {0x091, P91_Value, 0x1F}, // set R5_READ_LP or SP2 = 15.44us
        {0x010, 0x00, 0x02}, //F_CRD_EN=disable
        {0x113, 0x00, 0x0c}, //SV_MANUAL_MLC/SV_AUTO_MLC=0       //parameter mask changes in BiCS4.5
        {0x120, 0x00, 0x30}, //F_LAY_READ_EN=disable in TSB mode 
    };

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);
        if(Bitline_Leakage_All_One_Detect(die)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
        RESET_PARAMETERS(die, Para_Array);
    }

    return(PF_Check());
}
