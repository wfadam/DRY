uint8 t_SCREEN_BLK_SEL_VDDVDDA_MINUS2_SCR2288p0(void) //tb_837 nvcc SCR894p0
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(BLK_SEL_VDDVDDA_Shift(die, 2, MINUS, BIT_IGNORE_8) != PASS)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}
