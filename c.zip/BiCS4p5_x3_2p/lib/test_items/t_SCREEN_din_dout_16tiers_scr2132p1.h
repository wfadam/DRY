uint8 t_SCREEN_din_dout_16tiers_scr2132p1(void) //tb_191 nvcc SCR2132p0
{
    uint8 die, Org_P0DE, P0DE_Minus6, P0DE_Plus6;

    FOR_EACH_DIE(die)
    {
        POR_From_RF(die, 0, DONOT_USE_4C);

        Org_P0DE = Get_Param(die, 0x0DE);
        Org_P0DE = Org_P0DE&0x1F;

        if((Org_P0DE>=6)&&(Org_P0DE<=0x19))
        {
            P0DE_Minus6 = Org_P0DE-6;
            P0DE_Plus6  = Org_P0DE+6;
        }
        else
        {
            print(0, "D@ P0xDE:@ cannot +-6", die, Org_P0DE);
            BD_Add(die, TEMP);
            continue;
        }

        if((XDL_Din_Dout_16Tiers(die,P0DE_Minus6,P0DE_Plus6,Org_P0DE)!=0) 
         ||(XDL_Din_Dout_16Tiers(die,P0DE_Plus6,P0DE_Minus6,Org_P0DE)!=0))
        {
            Print_Die_Failure_Add_BD(die, "");
        }

        POR_From_RF(die, 0, USE_4C);
    }

    return(PF_Check());
}
