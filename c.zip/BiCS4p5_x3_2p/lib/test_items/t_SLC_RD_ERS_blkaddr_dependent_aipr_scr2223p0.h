uint8 t_SLC_RD_ERS_blkaddr_dependent_aipr_scr2223p0()  // tb__399 nvcc SCR1186p4
{
    uint8 Loop = 0;
    uint16 blk = 0;

    FOR_EACH_LOOP(Loop,0,0xF,2)
    {
        FOR_EACH_LOOP(blk, Loop, TOTAL_BLK, 0x10)
        {
        	SLC_AIPR_Read_Delay(blk, blk+1,MARKBB,BIT_IGNORE_8);
            SLC_Erase(blk, blk+1,MARKBB);
        }
    }
    FULLARRAY_BB_CHECK;
    return(PF_Check());
}
