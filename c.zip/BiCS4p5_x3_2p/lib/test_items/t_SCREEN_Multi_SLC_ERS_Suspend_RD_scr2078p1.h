uint8 t_SCREEN_Multi_SLC_ERS_Suspend_RD_scr2078p1(void) //tb_734 nvcc SCR2078p0
{
    uint8 die=0, i;
    uint16 blk_a, blk_b,blk_c;
    uint8 Suspend_CMD[3] = {0xFA, 0xFF, 0x51};

    GBB_Check_Init(GBB_limit);

    FOR_EACH_DIE(die)
    {         
        blk_a=Search_Pair_Blk_BBMap_Erase_by_Die(die, 0x300, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,SLC_ERASE);
        blk_b=Search_Pair_Blk_BBMap_Erase_by_Die(die, blk_a+2, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,SLC_ERASE);
        blk_c=Search_Pair_Blk_BBMap_Erase_by_Die(die, blk_b+2, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,SLC_ERASE);

        if((blk_a != TOTAL_BLK) && (blk_b != TOTAL_BLK) && (blk_c != TOTAL_BLK))
        {

            for(i = 0; i < 3; i ++)
            {
                SLC_Program_6D_By_Die(die, blk_a, blk_a+2, MARKBB, PRINT_FAIL);
                SLC_Program_6D_By_Die(die, blk_b, blk_b+2, MARKBB, PRINT_FAIL);
                SLC_Program_6D_By_Die(die, blk_c, blk_c+2, MARKBB, PRINT_FAIL);

                
                if(SLC_Erase_Suspend_6D_Sample_WL(die, blk_b, blk_a, BIT_IGNORE_8, IGN_BITS_SLC, DLY_100, Suspend_CMD[i])!=0)  BD_Add(die, TEMP);
                if(SLC_Erase_Suspend_6D_Sample_WL(die, blk_c, blk_a, BIT_IGNORE_8, IGN_BITS_SLC, DLY_1000, Suspend_CMD[i])!=0) BD_Add(die, TEMP);                

                if(SLC_Read_6D_For_WL(die, blk_a,IGN_BITS_SLC)!=0) BD_Add(die, TEMP);

                SLC_Erase_by_Die(die, blk_a, blk_a+2, MARKBB);
                SLC_Erase_by_Die(die, blk_b, blk_b+2, MARKBB);
                SLC_Erase_by_Die(die, blk_c, blk_c+2, MARKBB);
            }
        }
    }

    GBB_limit.GBB_CHECK_PLN=0;
    GBB_limit.MarkBB=DONOT_MARKBB;

    GBB_Check(GBB_limit); 

    return(PF_Check());
}
