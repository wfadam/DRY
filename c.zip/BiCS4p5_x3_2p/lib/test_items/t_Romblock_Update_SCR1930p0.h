uint8 t_Romblock_Update_SCR1930p0(void)
{
    ROMBLOCK_UPDATE;

    return(PF_Check());
}