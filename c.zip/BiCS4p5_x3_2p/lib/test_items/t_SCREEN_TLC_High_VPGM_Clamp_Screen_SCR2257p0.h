uint8 t_SCREEN_TLC_High_VPGM_Clamp_Screen_SCR2257p0(void) //tb_832 nvcc SCR1927p3
{
    Para_Table Para_Array[] =
    {
        {0x113, 0x00, 0x04}, // SV_AUTO_MLC Disable Smart verify for MLC
        {0x015, 0x0F, 0x0F}, // SDE_PMP_VM_RIGHT set to 33.75ns
        {0x0BD, 0x0F, 0x0F}, // SDE_PMP_UM_RIGHT set to 54ns
        {0x0F7, 0x0F, 0x0F}, // SDE_PMP_UM_LEFT - Pump clock for VPGM and VERA set to 54ns
        {0x0FD, 0x0F, 0x0F}, // SDE_PMP_VM_LEFT set to 33.75ns
        {0x0B9, 0x80, 0xC0}, // PMPDRREF_LEVEL = 1.95V
        {0x0BD, 0x80, 0x80}, // PMPCLK_X2 using X2 option instead of X1
        {0x0A6, 0x00, 0x20}, // F_STB_RR_SCAN disable
        {0x136, 0x00, 0x80}, // Smart PCV disable
    };

    MLC_Erase(0, TOTAL_BLK, DONOT_MARKBB);

    SET_PARAMETERS_ALL_DIE(Para_Array);

    AllG_PGM_CMD44(0, TOTAL_BLK);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Erase(0, TOTAL_BLK, DONOT_MARKBB);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
