uint8 t_POR_Restore(void)//tb220-233 nvcc
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(POR_Check(die)!=0)
        {
            Print_Die_Failure(die, "POR");
            Reset_Unit_Set_Parm(die);
            Restore_BB_BC_Parm_From_DS(die, DS_BACKUP_BLK, DS_BACKUP_WL, DS_BACKUP_STR);
            if(POR_Check(die)!=0) BD_Add(die, TEMP);
        }
    }
    return(PF_Check());
}