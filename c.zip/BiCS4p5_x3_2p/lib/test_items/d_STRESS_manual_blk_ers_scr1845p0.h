uint8 d_STRESS_manual_blk_ers_scr1845p0()  //tb_702 nvcc SCR709p4
{
    Single_Pulse_Erase(20000);
  
    return (PF_Monitor());
}
