uint8 t_SLC_PRG_flash_write_bbk_allG_scr2038p1(void)//tb__262 nvcc Base on SCR1571.0
{
    Para_Table Para_Array[] = 
    {
        {0x02D, 0x78, 0xFF}, //Set G state verify level to 5.5V.
        {0x002, 0xC0, 0xC0}, //F_TESTTEMP= 2'b11
        {0x138, 0x00, 0x38}, //F_BSPF_GV_D = 0
        {0x050, 0x0E, 0x0F}, //F_DVPGMU_XM = 0.7V
        {0x136, 0x00, 0x80}, //Smart PCV disable
        {0x0A6, 0x00, 0x20}, //F_STB_RR_SCAN disable
    };

    Reset_All_BBlk();
    Set_Datalog_Block_as_BB();

    SET_PARAMETERS_ALL_DIE(Para_Array);

    Sub_AllG_Pgm_BB_Sample_WL(0x12);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
