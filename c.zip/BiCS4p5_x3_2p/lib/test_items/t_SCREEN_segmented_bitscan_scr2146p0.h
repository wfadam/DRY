uint8 t_SCREEN_segmented_bitscan_scr2146p0(void) //tb__194 nvcc Base on SCR578.3
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Segmented_Bit_Scan(die)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }
    return(PF_Check());
}
