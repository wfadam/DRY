uint8 t_SCREEN_ers_prg_delay_scr2056p0(void)//tb__431 nvcc 976p1
{
    uint8 die;
    uint16 good_blk, blk;

    FOR_EACH_DIE(die)
    {
        good_blk=Search_Pair_Blk_BBMap_by_Die(die,0,TOTAL_BLK,TOTAL_PLN,PAIR_2);

        if(good_blk != TOTAL_BLK)
        {

            FOR_EACH_LOOP(blk, good_blk, (good_blk+4), 1)
            {
                if(SLC_Erase_Program_DLY(die, blk)!=0)
                {
                    Print_Die_Failure_Add_BD(die, "");
                    break;
                }
            }
            
            SLC_Erase_by_Die(die, good_blk, good_blk+4, DONOT_MARKBB);
        }
    }

    return(PF_Check());
}
