uint8 d_MONITOR_sgd_rc_scr2239p1(void) //tb__540 Base on SCR2003.1 nvcc
{
    //SCR-2239.B4B.1: Changed Min limit to 08h (8) and Max limit to 78h (120)Changed only for KGD , others remain same as before. 
    uint8 die;
    ADR_Init(adr);
    adr.phy.wl = SGD;
    
    Para_Table Para_Array[] =
    {
        {0x103, 0x00, 0x10}, // LVSTAGEFLG = Disable 
        {0x002, 0x40, 0xC0}, // F_TESTTEMP = 2'b01
        {0x00E, 0x20, 0xFF}, // F_RC_MEAS = 1/F_RC_MON = 0 (t1 Meas) 
        {0x12E, 0x20, 0x20}, // F_SDE_2X_TEST = 1(SCAN_SLOW=1)   
        {0x00A, 0x00, 0xFF}, // Upper Criteria MSB=0 & Lower Criteria MSB=0
        {0x00B, 0x05, 0xFF}, // Lower Criteria=5.       
        {0x00C, 0x28, 0xFF}, // Upper Criteria=40. 
    };

    Reset_All_BBlk();

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);

        FOR_EACH_LOOP(adr.phy.blk, 0, TOTAL_BLK, 1)
        {
            FOR_EACH_STR(adr.phy.str)
            {
                WL_RC_Check_By_Die(die, adr, DLY_400); 
            }
        }

        RESET_PARAMETERS(die, Para_Array);
        
        POR_One_Die(die);
    }

    GBB_MONITOR_PRINT;  // for easy debug and tracking, print out the failing BB and EOC block seperately.

    BB_Check_EOC(0, TOTAL_BLK, 4, 5, TEMP);
    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
