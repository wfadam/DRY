uint8 t_SCREEN_POR_margin_emulation_scr2259p2(void) //tb_238_nvcc
{
    uint8 die = 0, FailFlag = 0;
    uint8 tb_number[8] = {0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    uint16 stamp_col = 0x31E0;

    if ((Read_UR_Stamp_4C(0, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR  , stamp_col, BIT_IGNORE_8, 0xAA, BYTE_8) == EXIST)
            ||(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR+1, stamp_col, BIT_IGNORE_8, 0xAA, BYTE_8) == EXIST)) 
    {
        print(0, "Fail Stamp exists\n");
        Mark_All_Die_Bad(TEMP);
        return(PF_Check());
    }

    FOR_EACH_DIE(die)
    {
        if(POR_Margin_Emulation_TTR(die, 0x0A, 0x37, 0x1A, 0x3A, 3) != PASS) 
        {
            FailFlag |= 1;
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    if (FailFlag)
    {
        tb_num_conversion(g_TestNum, tb_number);
        Program_UR_Stamp_4C(0x00, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR, stamp_col, BYTE_8);
        Program_UR_Stamp_4C(0x00, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR+1, stamp_col, BYTE_8);
        Program_UR_Stamp_4C_with_tbnum(0x00, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR, stamp_col+8, tb_number);
        Program_UR_Stamp_4C_with_tbnum(0x00, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR+1, stamp_col+8, tb_number);
    }

    return(PF_Check());
}
