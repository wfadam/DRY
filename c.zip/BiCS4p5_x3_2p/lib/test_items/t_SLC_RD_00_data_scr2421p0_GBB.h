uint8 t_SLC_RD_00_data_scr2421p0_GBB(void) //tb__392 nvcc SCR1947p0
{
    SLC_Read_Pattern_2A(0, TOTAL_BLK, ALL00, IGN_BITS_SLC_ALL00);

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN=6;
    GBB_limit.MarkBB=MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
