uint8 d_MONITOR_mh_open_scr2221p0_2Bit(void)  //tb_496 nvcc Base on SCR1882.1
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        MH_Open(die, BIT_IGNORE_2);
    }

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
