uint8 t_MLC_ERS_PRG_scr1846p2(void)//tb__300 nvcc
{
    uint16 blk = 0;

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET,	   NLE_MLC_MASK},
        {NLP_MLC_ADR, NLP_MLC_SET,     NLP_MLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    for(blk = 0; blk < TOTAL_BLK; blk+=TOTAL_PLN)
    {
        if ((THROTTLE_PRODUCT == THROTTLE)&&((blk%0x80)==0))
        {
            print(0,"B@:", blk);
            Cool_temp(90, 1);
        }

        MLC_Erase(blk, blk+1, MARKBB);
        MLC_Program_6E_2A_CMD85(blk, blk+1, MARKBB);
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
