uint8 t_Parm_Trim(void)  //BiCS4.5
{
    uint8 die;

    //g_Mask_Rev = Check_Mask_Rev(0);   //Need Double Confirm ID90 for BiCS4.5 about Parameter 0x0FB
    
    g_Update_Para_Array_En = 1; //enable parameter array update

    FOR_EACH_DIE(die)
    {
        if(Parm_Trim(die)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    g_Update_Para_Array_En = 0; //disable parameter array update

    ROMBLOCK_UPDATE;

    return(PF_Check());
}
