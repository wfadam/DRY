uint8 t_SCREEN_block_addressing_scr2048p0(void) //tb__674__ nvcc
{
    uint16 Ref_BLK[11][8] = 
    {
        {0x00,0x01,0x20,0x21,0x40,0x41,0x80,0x81},
        {0x00,0x02,0x20,0x22,0x40,0x42,0x80,0x82},
        {0x00,0x04,0x20,0x24,0x40,0x44,0x80,0x84},
        {0x00,0x08,0x20,0x28,0x40,0x48,0x80,0x88},
        {0x00,0x10,0x20,0x30,0x40,0x50,0x80,0x90},
        {0x00,0x20,0x02,0x22,0x40,0x60,0x80,0xA0},
        {0x00,0x40,0x20,0x60,0x04,0x44,0x80,0xC0},
        {0x00,0x80,0x20,0xA0,0x40,0xC0,0x08,0x88},
        {0x000,0x100,0x020,0x120,0x040,0x140,0x080,0x180},
        {0x000,0x200,0x020,0x220,0x040,0x240,0x080,0x280},
        {0x000,0x400,0x020,0x420,0x040,0x440,0x080,0x480}
    };
    uint16 GB1, GB2;
    uint8 die=0, IO_Index, BLK_Index, pln=0;

    FOR_EACH_DIE(die)
    {
        FOR_EACH_PLN(pln)
        {
            FOR_EACH_LOOP(IO_Index,0,11,1)
            {
                FOR_EACH_LOOP(BLK_Index,0,8,2)
                {
                    if((Is_BB(die, Ref_BLK[IO_Index][BLK_Index]+pln, MAIN)==0) && (Is_BB(die, Ref_BLK[IO_Index][BLK_Index+1]+pln, MAIN)==0))
                    {
                        GB1 = Ref_BLK[IO_Index][BLK_Index]+pln;
                        GB2 = Ref_BLK[IO_Index][BLK_Index+1]+pln;

                        // print(0,"DIE@ GB1 @ GB2 @\n", die, GB1, GB2);

                        SLC_Erase_SP_by_Die(die, GB1, GB1+1, DONOT_MARKBB);
                        SLC_Erase_SP_by_Die(die, GB2, GB2+1, DONOT_MARKBB);
                        
                        if(SLC_ALL00_Program_SP_By_DIE(die, GB1, GB1+1) != 0)
                        {
                            Print_Die_Failure_Add_BD(die, "SLC ALL00 program");
                        }
                        
                        if(SLC_Read_Pattern_SP_By_DIE(die, GB2, GB2+1, ALLFF, 110) != 0)
                        {
                            Print_Die_Failure_Add_BD(die, "SLC ALLFF Read");
                        }
                        SLC_Erase_SP_by_Die(die, GB1, GB1+1, DONOT_MARKBB);
                        if(SLC_ALL00_Program_SP_By_DIE(die, GB2, GB2+1) != 0)
                        {
                            Print_Die_Failure_Add_BD(die, "SLC ALL00 program");
                        }
                        if(SLC_Read_Pattern_SP_By_DIE(die, GB1, GB1+1, ALLFF, 110) != 0)
                        {
                            Print_Die_Failure_Add_BD(die, "SLC ALLFF Read");
                        }
                        SLC_Erase_SP_by_Die(die, GB2, GB2+1, DONOT_MARKBB);
                        break;
                    }
                    if(BLK_Index == 6)
                    {
                        Print_Die_Failure_Add_BD(die, "Find GB");
                        continue;
                    }

                }
            }
        }		
    }
    Reset_Select_BB_Map(TEMP);
    return(PF_Check());
}			

