uint8 t_SCREEN_cmd_f1_f2_scr1961p0(void)//tb__730 nvcc
{
	uint8 die; //Total die stack

    FOR_EACH_DIE(die) // need to implement for both the FIM.
    {
        if(F1F2_check(die)!=0)
        {
            BD_Add(die, TEMP);
        }
    }

    return(PF_Check());
}
