uint8 t_Prog_Read_BI_Stamp()
{
    uint16 BI_STAMP=0x1800;

    Program_Stamp_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, BI_STAMP, BYTE_8);

    if(Stamp_Exist_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, BI_STAMP, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
    {
        Print_Die_Failure(0, "RD stamp");
        Mark_All_Die_Bad(TEMP);
    }

    return (PF_Check());
}
