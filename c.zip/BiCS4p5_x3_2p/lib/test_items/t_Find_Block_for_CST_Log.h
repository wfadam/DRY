uint8 t_Find_Block_for_CST_Log()
{
    uint8 FailFlag=0;

    if(Decode_data_log_block()!=CST_DATLOG_BLOCK_INVALID)
    {
        FailFlag |= Erase_Block_for_CST_Log();
    }
    else
    {
        FailFlag |= Find_Block_for_CST_Log();
    }

    if(FailFlag!=0) return(FailFlag);

    ROMBLOCK_UPDATE;  

    return(PF_Check());
    //Normal CST data log block function, 1st die and last die has data log block and stamp is on every die
    //just return fail if anything wrong as it's a package failure not die level failure.
}
