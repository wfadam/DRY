uint8 t_SCREEN_TProgram_1p6ms_Screen_SCR10612p0(void) //tb_840 nvcc SCR871p5
{
    //search good blk on both plane. Starting from the top edge blk down to blk 0
    // 1) Use 2A to do MLC Erase, MLC Prog with default parm, MLC Erase if a block can pass these 3 step, proceed to the next step
    // 2) MLC Prog with short Tprog. WL0-47 use Delay_1, WL48-95 use Delay_2.
    // 3) Read Program status if status is pass, fail the block.
    uint8 die, blk_cnt, ItemFlag = 0;

    ADR_Init(adr);

    FOR_EACH_DIE(die)
    {
        print(0, "D@ ", die);
        blk_cnt = 0;

        FOR_EACH_LOOP_BACK(adr.phy.blk, TOP_BLK_EDGE, 0, TOTAL_PLN)
        {
            ItemFlag = 0;

            ItemFlag |= MLC_Erase_2A_By_Die(die, adr.phy.blk, adr.phy.blk+2, DONOT_MARKBB);
            ItemFlag |= MLC_Program_6E_2A_By_Die(die, adr.phy.blk, adr.phy.blk+2, DONOT_MARKBB);
            ItemFlag |= MLC_Erase_2A_By_Die(die, adr.phy.blk, adr.phy.blk+2, DONOT_MARKBB);

            if(ItemFlag == 0) //Test block pass 2 erase and 1 program
            {
                print(0, "B@ ", adr.phy.blk);
                blk_cnt ++; //count the valid block

                MLC_Over_Program_6D_2A_By_Die(die, adr.phy.blk, 1600, 1600);
                MLC_Erase_2A_By_Die(die, adr.phy.blk, adr.phy.blk+2, DONOT_MARKBB);
            }
            if(blk_cnt >= 4) break; //total loop 4 pairs of block for each die
        }

        print(0, "\n");
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = 7;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
