uint8 t_SCREEN_set_dynamic_read_scr2222p1(void)    // tb_749_nvcc
{
    uint8  die,FailFlag = 0;
    uint16 good_blk_SLC, good_blk_MLC;

    Para_Table Para_Array[] =
    {
        {0x116, 0x80, 0x80},        // SET 5D_EEEF_VCGSFT = 1 to enable dynamic read
        {0x036, 0x1F, 0x1F},        // DVCG_SLCR P0 = 0 V to change default read level in order to avoid overkill issue
        {0x03E, 0x1F, 0x1F},        // DVCG_SLCR P1 = 0 V to change default read level in order to avoid overkill issue
        {0x0DE, 2, MINUS|0x1F},     // VDD -2DAC margin check 
    };


    //CC: Double check the feature value array when you try to change it.
    uint32 SLC_DAC_shift[1] = {0x0000007F};
    uint32 LP_DAC_shift[2][1] =
    {
        {0x0000007F},
        {0x007F0000},
    };
    uint32 MP_DAC_shift[3][1] =
    {
        {0x0000007F},
        {0x00007F00},
        {0x007F0000},
    };
    uint32 UP_DAC_shift[2][1] =
    {
        {0x00007F00},
        {0x7F000000},
    };

    uint8 SLC_DAC_cnt = sizeof(SLC_DAC_shift)/sizeof(SLC_DAC_shift[0]);//1
    uint8 LP_DAC_cnt = sizeof(LP_DAC_shift[0])/sizeof(LP_DAC_shift[0][0]);//1
    uint8 MP_DAC_cnt = sizeof(MP_DAC_shift[0])/sizeof(MP_DAC_shift[0][0]);//1
    uint8 UP_DAC_cnt = sizeof(UP_DAC_shift[0])/sizeof(UP_DAC_shift[0][0]);//1

    print(0,"cnt~ LP~ MP~ UP~\n",SLC_DAC_cnt,LP_DAC_cnt, MP_DAC_cnt,UP_DAC_cnt);

    //Search 1 good block
    FOR_EACH_DIE(die)
    {
        good_blk_SLC = Search_Singel_Blk_BBMap_by_Die(die,0x100, TOTAL_BLK, TOTAL_PLN, ONE_BLK);
        good_blk_MLC = Search_Singel_Blk_BBMap_by_Die(die,good_blk_SLC+2, TOTAL_BLK, TOTAL_PLN, ONE_BLK);
      
        if((good_blk_SLC != TOTAL_BLK) && (good_blk_MLC != TOTAL_BLK))
        {
            
            SLC_Erase_SP_by_Die(die,good_blk_SLC,good_blk_SLC+1,DONOT_MARKBB);
            SLC_Program_SP_6D_By_Die(die,good_blk_SLC,good_blk_SLC+1,DONOT_MARKBB,PRINT_FAIL);
            MLC_Erase_SP_By_Die(die,good_blk_MLC,DONOT_MARKBB);
            MLC_Program_SP_6D_By_Die(die,good_blk_MLC,good_blk_MLC+1,DONOT_MARKBB,PRINT_FAIL, SET_AB);

            SET_PARAMETERS(die, Para_Array);

            FailFlag |= Set_Get_Feature_Dynamic_Read(die,good_blk_SLC, SLC_DAC_shift, SLC_DAC_cnt, SLC, 0x14, BIT_IGNORE_10);
            FailFlag |= Set_Get_Feature_Dynamic_Read(die,good_blk_MLC, *LP_DAC_shift, LP_DAC_cnt, LOWER, 0x12, BIT_IGNORE_55);
            FailFlag |= Set_Get_Feature_Dynamic_Read(die,good_blk_MLC, *MP_DAC_shift, MP_DAC_cnt, MIDDLE, 0x13, BIT_IGNORE_55);
            FailFlag |= Set_Get_Feature_Dynamic_Read(die,good_blk_MLC, *UP_DAC_shift, UP_DAC_cnt, UPPER, 0x12, BIT_IGNORE_55);
            
            RESET_PARAMETERS(die, Para_Array);

            if(FailFlag != 0)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }

        FEATURE_RESET;
        NAND_RESET;
    }

    return(PF_Check());
}
