uint8 t_SLC_RD_stamp_KGD_scr2184p0()  // tb__818 nvcc 
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Read_UR_Stamp_4C(die, MTST_UROM_BLK1, WL20, STR0, 0x0140, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }


    return(PF_Check());
}
