uint8 t_SCREEN_div2_check_scr2190p0(void) //tb__174 nvcc
{
    uint8 die;
    FOR_EACH_DIE(die)
    {
        if(BC_DIV_Check(die) != 0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }
    return(PF_Check());
}
