uint8 t_SCREEN_latches_folding1_scr2188p0(void) //tb__195 nvcc SCR813p3
{
    uint8 die;
    uint16 good_blk;

    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_Erase_by_Die(die, 0, TOTAL_BLK, TOTAL_PLN, PAIR_1, SLC_ERASE);

        if(good_blk != TOTAL_BLK)
        {
            if(Folding_SLC_Program(die, good_blk) != 0) BD_Add(die, TEMP);     //2] SLC program on block SLC source block
            if(Folding_SLC_Read(die, good_blk, BIT_IGNORE_0) != 0) BD_Add(die, TEMP);
        }
    }
    return(PF_Check());
}
