uint8 t_SLC_RD_stamp_DL(void)
{
	if (DL_STAMP_READ==1)
	{
		if(Stamp_Exist_In_Range(0x00, MTST_UROM_BLK0, WL51, WL51, STR0, STR0+1, 0x1800, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
    	{
        	print(0,"no DL stamp"); 
        	Mark_All_Die_Bad(TEMP);
    	}
	}
    
    return(PF_Check());
} 