uint8 t_MLC_Erase_Program_SCR2422p0_GBB(void) //tb__300 nvcc SCR1846p0
{
    uint16 blk = 0;

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {NLP_MLC_ADR, NLP_MLC_SET, NLP_MLC_MASK},
        {0x0AB, 0x08, 0x08}, //enable ocs6D to enable every string have different random data in same wl.
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    for(blk = 0; blk < TOTAL_BLK; blk+=TOTAL_PLN)
    {
        if ((THROTTLE_PRODUCT == THROTTLE)&&((blk%0x80)==0))
        {
            print(0,"B@:", blk);
            Cool_temp(90, 1);
        }

        MLC_Erase(blk, blk+1, MARKBB);
        MLC_Program_6D_2A(blk, blk+1, MARKBB, DONOT_SET_AB); //0xAB set outside for TTR
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN=6;
    GBB_limit.MarkBB=MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
