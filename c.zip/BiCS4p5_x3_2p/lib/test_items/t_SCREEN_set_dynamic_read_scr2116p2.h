uint8 t_SCREEN_set_dynamic_read_scr2116p2(void) //tb_743_nvcc
{
    uint8  die,FailFlag = 0;
    uint16 good_blk_SLC;

    Para_Table Para_Array[] =
    {
        {0x116, 0x80, 0x80},        // SET 5D_EEEF_VCGSFT = 1 to enable dynamic read
        {0x036, 0x1F, 0x1F},        // DVCG_SLCR P0 = 0 V to change default read level in order to avoid overkill issue
        {0x03E, 0x1F, 0x1F},        // DVCG_SLCR P1 = 0 V to change default read level in order to avoid overkill issue
        {0x0DE, 2, MINUS|0x1F},     // VDD -2DAC margin check 
    };


   //CC: Double check the feature value array when you try to change it.
    uint32 SLC_DAC_shift[1] = {0x0000007C};
    uint8 SLC_DAC_cnt = sizeof(SLC_DAC_shift)/sizeof(SLC_DAC_shift[0]);//1
    print(0,"SLC_DAC_cnt~  \n",SLC_DAC_cnt);

    FOR_EACH_DIE(die)
    {
        good_blk_SLC = Search_Pair_Blk_BBMap_by_Die(die,0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1);
        
        if(good_blk_SLC != TOTAL_BLK)
        {

            SLC_Erase_by_Die(die,good_blk_SLC,good_blk_SLC+1,DONOT_MARKBB);
            SLC_Program_6D_By_Die(die,good_blk_SLC,good_blk_SLC+1,DONOT_MARKBB,PRINT_FAIL);

            SET_PARAMETERS(die, Para_Array);

            FailFlag |= Set_Get_Feature_Dynamic_Read_2A_AIPR(die,good_blk_SLC, SLC_DAC_shift, SLC_DAC_cnt, SLC, 0x14, 0x87, BIT_IGNORE_5);

            RESET_PARAMETERS(die, Para_Array);

            if(FailFlag != 0)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }

        FEATURE_RESET;
        NAND_RESET;
    }

    return(PF_Check());
}
