uint8 t_SLC_ERS_SH_scr2445p0(void)  //tb_332 nvcc SCR1405p7
{
    uint8 TOP_DIE;

    Para_Table Para_Array[] =
    {
        {NLE_SLC_ADR, NLE_SLC_SET, NLE_SLC_MASK},
    };

    if((TOTAL_DIE == 4) || (TOTAL_DIE == 8)) //For iNand Only 4/8D Top Die: FIM0 DIE1
    {
        TOP_DIE = 1;

        Sel_CE_FIM_by_Die(TOP_DIE);

        SLC_Program_6D_By_Die(TOP_DIE, 0, TOTAL_BLK, DONOT_MARKBB, DONOT_PRINT); //Background Condition
        
        SET_PARAMETERS(TOP_DIE, Para_Array);

        SLC_Erase_by_Die(TOP_DIE, 0, TOTAL_BLK, MARKBB);

        RESET_PARAMETERS(TOP_DIE, Para_Array);

        GBB_Check_PerPlane(TOP_DIE, 0, TOTAL_BLK, 6, DONOT_MARKBB);
    }
    else
    {
        print(0, "@D Skip\n", TOTAL_DIE);
    }

    return(PF_Check());
}
