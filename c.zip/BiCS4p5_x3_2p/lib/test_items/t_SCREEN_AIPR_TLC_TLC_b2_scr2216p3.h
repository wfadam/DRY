uint8 t_SCREEN_AIPR_TLC_TLC_b2_scr2216p3(void)  // tb_748 nvcc SCR2216p2
{
    uint8 die;
    g_CMDB2_FLAG = CMDB2_ENABLE;

    FOR_EACH_DIE(die)
    {
        TLC_TLC_AIPR_Read_Sample_BLK_WL_STR_Delay(die, IGN_BITS_SCR2216P2);
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 4;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
