uint8 d_MONITOR_dyn_read_linearity_VDD2_scr2375p0(void) //tb_763 nvcc SCR2362p0
{
    uint8 die, loop;
    uint16 good_blk;

    Para_Table Para_Array[] = 
    {
        {0x116, 0x80, 0x80}, // F_5D_EEEF_VCGSFT = 1
    };

    Para_Table Para_Array1[2][1] = 
    {
        {0x0DE, 2, MINUS|0x1F}, //VDD-2DAC
        {0x0DE, 2,  PLUS|0x1F}, //VDD+2DAC
    };

    FOR_EACH_DIE(die)
    {
        // Search 1 pair good blk
        good_blk = Search_Pair_Blk_BBMap_by_Die(die, 0, TOTAL_BLK, TOTAL_PLN, PAIR_1);
        if(good_blk != TOTAL_BLK)
        {
            FOR_EACH_LOOP(loop, 0, 2, 1)
            {
                SET_PARAMETERS(die, Para_Array1[loop]);
                // SLC erase, SLC program, SLC dynamic_read
                SLC_Erase_by_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);
                SLC_Program_Scramble_WL0_STR0_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);
                SET_PARAMETERS(die, Para_Array);
                if(SLC_Dynamic_Read_DAC_Linearity_1page_AIPR(die, good_blk, good_blk + 1, BIT_IGNORE_10000, DLY_0))
                {
                    Print_Die_Failure_Add_BD(die, "SLC");
                }

                // MLC erase, MLC program, MLC dynamic read
                MLC_Erase_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);
                MLC_Program_Scramble_WL0_STR0_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);
                if(MLC_Dynamic_Read_DAC_Linearity_1page_AIPR(die, good_blk, good_blk + 1, BIT_IGNORE_10000, DLY_0))
                {
                    Print_Die_Failure_Add_BD(die, "MLC");
                }
                MLC_Erase_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);
                RESET_PARAMETERS(die, Para_Array);
                RESET_PARAMETERS(die, Para_Array1[loop]);

                FEATURE_RESET;
                _RUN();
            }
        }
    }

    return(PF_Monitor());
}
