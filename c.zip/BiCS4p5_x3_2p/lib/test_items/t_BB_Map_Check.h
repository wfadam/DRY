uint8 t_BB_Map_Check(void)
{
    uint8 die;

    Reset_Select_BB_Map(TEMP);

    FOR_EACH_DIE(die)
    {
        if(BB_Map_Check(die) != 0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    Print_BB(MAIN);

    return(PF_Check());
}
