uint8 t_SCREEN_CRD_clk_out_scr2356p1(void) //tb_216 nvcc
{
    uint8 die, loop;

    Para_Table Para_Array[2][1] =
    {
        {0x0DE, 4,  PLUS|0x1F}, //VDD+4DAC
        {0x0DE, 4, MINUS|0x1F}, //VDD-4DAC
    };

    FOR_EACH_LOOP(loop, 0, 2, 1)
    {
        FOR_EACH_DIE(die)
        {
            SET_PARAMETERS(die, Para_Array[loop]);

            if(CRD_Latch_Check(die) != 0)
            {
                Print_Die_Failure_Add_BD(die, "");
            }

            RESET_PARAMETERS(die, Para_Array[loop]);
        }
    }

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
