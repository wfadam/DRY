uint8 t_SCREEN_TLC_Cache_2Plane_SCR10598p0()//tb__844 nvcc SCR1001.4
{
    uint8 die;
    uint16 good_blk;

    Para_Table Para_Array[] =
    {
        {NLP_MLC_ADR, NLP_MLC_SET, NLP_MLC_MASK},
        {0xDE,    4, MINUS|0x1F},  //Set VDD-4DAC
        {0x11,    2, PLUS|0x3F},  //Set SDE+2DAC
    };


    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_Erase_by_Die(die, 0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1,MLC_ERASE);
        if(good_blk != TOTAL_BLK)
        {

            SET_PARAMETERS(die, Para_Array);
            TLC_Cache_Program_DP_Scramble_By_Die(die, good_blk, good_blk + 2);
            TLC_Cache_Read_DP_Scramble_Sample_Page_By_Die(die, good_blk, good_blk + 2);
            RESET_PARAMETERS(die, Para_Array);
        }
    } 

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = 0;
    GBB_limit.MarkBB = MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
