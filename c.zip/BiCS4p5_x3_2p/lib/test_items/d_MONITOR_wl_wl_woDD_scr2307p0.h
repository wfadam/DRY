uint8 d_MONITOR_wl_wl_woDD_scr2307p0(void)//tb__499 nvcc Base on SCR1872.1
{
    uint8 die, Org_46, Param_Flag;
    int value;
    uint16 majority_outgoing = 0x100;
    Majority_Vote vote_array_temp;

    Para_Table Para_Array[] =
    {
        {0x046, 0x00, 0xFF},
        {0x002, 0x40, 0xC0}, //F_TESTTEMP=1
        {0x00D, 0x80, 0x80}, //F_VPGM2VDD_STRPCG_EN=1
        {0x118, 0x04, 0x04}, // F_WL2WLLD_EN=1
        {0x118, 0x00, 0x02}, // F_WL2SUB_EN=0
        {0x119, 0x00, 0x0C}, // F_PPNPPE_MLC/SLC=0
        {0x117, 0x00, 0x30}, // F_PAP_ERASE=0
        {0x118, 0x10, 0x10}, // F_WLLD_N0ERA=1
        {0x04C, 0x00, 0xC0}, // F_PROGSRC_WLLD=VSS
        {0x100, 0x01, 0x01}, // F_BL_BIAS_STRPCG=VDDSA
        {0x118, 0x20, 0x20}, // F_WLLD_WAY=1 HALF WLS
        {0x052, 0x10, 0xF0}, // F_INC_VPGM_WL2WL=+0.8v
        {0x0AE, 0x24, 0x3C}, // F_WLLD_IDT= 500nA
        {0x0AE, 0x01, 0x03}, // F_WLLD_ICM= 1000nA
        {0x0AE, 0xC0, 0xC0}, // F_WLLD_ICS_RANGE= 12.5nA
        {0x083, 0xC0, 0xF0}, // F_PD1_WLLD= 2079.68us
        {0x0B8, 0x00, 0xF0}, // F_VSGDPCH = 3.0V
        {0x12C, 0x00, 0x08}, //F_HR_EN=0 //Disable auto H-IVR
        {0x12C, 0x00, 0x10}, //F_HR_EN_ERASE=0 //Disable auto H-IVR
        {0x011,    7, PLUS|0x3F}, //SDE=default(71.6ns) + 7DAC = 80ns
	};

    FOR_EACH_DIE(die)
    {
        Org_46 = Get_Param(die, 0x46);
        value = Org_46;
        Param_Flag = 0;

        vote_array_temp = Read_DS_and_Majority_Vote(die, 1, 13, 2, 0x260);

        if(vote_array_temp.win_flag && (vote_array_temp.vote_cnt >= 2))
        {
            majority_outgoing = vote_array_temp.vote_value;
            if(majority_outgoing >= (Org_46 - 40) && (majority_outgoing <= (Org_46 + 40)))
            {
                value = majority_outgoing + 20;
                Param_Flag = 1;
            }
        }

        if(Param_Flag == 0)
        {
            value = Org_46 + 10;
        }

        if(value <= 0xFF)
        {
            Para_Array[0].value = value;
        }
        else
        {
            Para_Array[0].value = 0xFF;
            print(0, "D@ P46>FF, set FF\n", die);
        }

        SET_PARAMETERS(die, Para_Array);
    }

    WL_WL_Leakage_Dummy_Read(DONOT_USE_DD, EVEN_ODD_WL);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
