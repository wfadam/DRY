uint8 t_SCREEN_TLC_cache_backnd_ops_scr2117p0_WO_TM()  // tb_783 nvcc Base on SCR1003.2
{
    // This TB use 2 buffer
    Cache_Background_Screen();

    return(PF_Check());
}
