uint8 d_MONITOR_mh_mh_scr2009p0(void) // tb__494 nvcc Base on SCR1958p0
{
    uint8 die;

    Para_Table Para_Array[] =
    {
        {0x103, 0x00, 0x20},  // 103h[5]=0 F_NEG_SLC=0 disable
        {0x0AB, 0x00, 0x07},  // ABh[1:0]=0 F_ZONESTEP=0 disable //ABh[2]=0 F_ZONESTEP_WL=0 disable
        {0x11B, 0x00, 0x01},  // 11Bh[0]=0 F_SGD_USEL_RD=0 VSS
        {0x104, 0x80, 0x80},  // 104h[0]=0 F_SGS_OFF=1 enable
    };

    FOR_EACH_DIE(die)
    {
        // Ignore bit come from xml file, please check with PE first before implement this item.
        SET_PARAMETERS(die, Para_Array);
        MH_MH_LEAK(die, BIT_IGNORE_28);
        RESET_PARAMETERS(die, Para_Array);
    }

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
