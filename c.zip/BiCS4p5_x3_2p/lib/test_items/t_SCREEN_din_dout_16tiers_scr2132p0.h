uint8 t_SCREEN_din_dout_16tiers_scr2132p0() // tb_191 nvcc 
{
    uint8 die,Org_P0DE, P0DE_Minus4, P0DE_Plus4;

    FOR_EACH_DIE(die)
    {
        POR_From_RF(die, 0, DONOT_USE_4C);

        Org_P0DE=Get_Param(die, 0x0DE);
        Org_P0DE = Org_P0DE&0x1F;

        if((Org_P0DE>=4)&&(Org_P0DE<=0x1B))
        {
            P0DE_Minus4=Org_P0DE-4;
            P0DE_Plus4=Org_P0DE+4;
        }
        else
        {
            print(0, "D@ P0xDE:@ cannot +-4", die, Org_P0DE);
            BD_Add(die, TEMP);
            continue;
        }

        if((XDL_Din_Dout_16Tiers(die,P0DE_Minus4,P0DE_Plus4,Org_P0DE)!=0) 
         ||(XDL_Din_Dout_16Tiers(die,P0DE_Plus4,P0DE_Minus4,Org_P0DE)!=0))
        {
            Print_Die_Failure_Add_BD(die, "");
        }

        POR_From_RF(die, 0, USE_4C);

    }

    return(PF_Check());
}
