uint8 t_SLC_PRG_flash_write_reset_bb_scr1956p0(void) //tb_261, tb_276, tb277 nvcc Base on SCR592.5
{
    // tune the VPGMU Shift and delay time as need to achieve median VT of ~3.8-4.0V, VPGMU Shift and delay time defined at local
    // Check out condition: take the VT distribution on WL40-43 dec string0 to 3 block 0 and 1. Low VT 2.2-2.4V and High VT 4.6-4.8V

    Para_Table Para_Array[] =
    {
        {0x113, 0x00, 0x08},  // F_SV_MANUAL_MLC=0     // Mask changed in BiCS4.5
        {0x113, 0x00, 0x04},  // F_SV_AUTO_MLC=0 
        {0x111, 0x00, 0x10},  // F_SV_VPGM_HALF=0 
        {0x112, 0x00, 0x01},  // F_QPWEN=0
        {0x112, 0x00, 0x02},  // F_FQPW=0
        {0x136, 0x00, 0x04},  // F_QPWEN_SV=0
        {0x114, 0x00, 0x80},  // F_PREPVFY=0
        {0x127, 0x00, 0x02},  // F_SGS_WLLD_MPRO=VSGS
        {0x072, 0xE0, 0xE0},  // F_P5TOP7_VPGM_CTRL=0
        {0x046, PARA_46_PLUS, PLUS|0xFF},  // Adjusting VPGMU
    };

    Reset_All_BBlk();
    Set_Datalog_Block_as_BB();

    SET_PARAMETERS_ALL_DIE(Para_Array);

    Flash_Write(0, TOTAL_BLK, DELAY_TIME_SCR1956p0);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
