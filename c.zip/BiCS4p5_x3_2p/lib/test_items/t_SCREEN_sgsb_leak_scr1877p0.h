uint8 t_SCREEN_sgsb_leak_scr1877p0(void) //tb_486 nvcc SCR702p8
{
    Para_Table Para_Array[] =
    {
        {0x118, 0x08, 0x08}, //F_WLLD_EN = 1
        {0x118, 0x04, 0x04}, //F_WL2WLLD_EN = 1
        {0x118, 0x00, 0x02}, //F_WL2SUBLD_EN = Disable
        {0x118, 0x10, 0x10}, //F_WLLD_NOERA = 1
        {0x117, 0x00, 0x30}, //F_PAP_ERASE = 0
        {0x119, 0x00, 0x0C}, //F_PPNPPE_MLC and F_PPNPPE_SLC = 0 = Disable
        {0x118, 0x20, 0x20}, //F_WLLD_WAY = 1
        {0x043, 0xE0, 0xE0}, //VISO1 = VSS
        {0x052, 0x00, 0xF0}, //F_INC_VPGM_WL2WL = 0
        {0x083, 0x60, 0xF0}, //F_PD1_WLLD = 1096.64us(max) @ SDE = 80ns
        {0x084, 0xE0, 0xE0}, //F_PR8= 4.56us
        {0x100, 0x00, 0x01}, //F_BL_BIAS_STRPCG = VSS
        {0x04C, 0x00, 0xC0}, //F_PROGSRC_WLLD = 0 (VSS)
        {0x0DF, 0x60, 0x60}, //F_WL2WL_REFTAIL_BOOST = x10
        {0x104, 0x80, 0x80}, //SGS_OFF = 1 (SGS = VSS fix)
        {0x0AE, 0x03, 0x03}, //F_WLLD_ICM = 2000nA
        {0x0AE, 0x00, 0xC0}, //F_WLLD_ICS_RANGE = 50nA
        {0x0AD, 0x40, 0xC0}, //WLLD_HIGH_CUR = 16uA
        {0x002, 0x40, 0xC0}, //F_TESTTEMP = 2`b01
        {0x00C, 0x02, 0x42}, //F_WLLD_OPT = 1 and F_SGSB_SGLD_SGLI = 0 (SGSG = VPGM)
        {0x046, 0x42, 0xFF}, //VPGMU = 10V
        {0x0AE, 0x20, 0x3C}, //F_WLLD_IDT = 250nA
        {0x0AD, 0x38, 0x38}, //WLLD_CC_LDCLK = 2621.44us
        {0x011,    7, PLUS|0x3F}, //SDE = Default(71.6ns) + 7DAC = 80ns
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    SGS_SGD_Leakage(SGSB_LEAK, DUAL_PLN);

    RESET_PARAMETERS_ALL_DIE(Para_Array);
    
    FULLARRAY_BB_CHECK;
    
    return(PF_Check());
}
