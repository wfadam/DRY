uint8 t_SCREEN_bb_latch_set_vddvdda_SCR2036p0(void) // tb_671_nvcc
{
    uint8 die;

    Para_Table Para_Array[] =
    {
        {0x011, 6, MINUS|0x3F},
        {0x0DE, 2, MINUS|0x1F},
        {0x0DB, 2, MINUS|0x0F},
    };

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);

        if(BB_LATCH_SET_SHIFT(die,0,BLK0_1)!=0)
        {
            Print_Die_Failure(die, "BB_LATCH_SET_MINUS2");
            BD_Add(die, TEMP);
        }

        RESET_PARAMETERS(die, Para_Array);
        
        POR_One_Die(die);
    }
    
   return(PF_Check());
}
