uint8 t_SCREEN_sgdvt_sgdrc_combo_scr2549p0(void) //tb_644 nvcc
{

    uint8 die;
    uint16 blk = 0;
    uint16 xferBlk;

#ifdef DENS_256_SW
    uint16 edge_blkList[8] = {0x3DE, 0x3DF, 0x3E0, 0x3E1, 0x0, 0x1, 0x79A, 0x79B};
#endif
#ifdef DENS_512_SW
    uint16 edge_blkList[8] = {0x7AE, 0x7AF, 0x7B0, 0x7B1, 0x0, 0x1, 0xF2A, 0xF2B};
#endif

    ADR_Init(adr);
    adr.phy.wl = SGD;

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
    };

    Para_Table Para_Array2[] =
    {
        {0x103, 0x00, 0x10}, // LVSTAGEFLG = Disable
        {0x002, 0x40, 0xC0}, // F_TESTTEMP = 2'b01
        {0x00E, 0x20, 0xFF}, // F_RC_MEAS = 1/F_RC_MON = 0 (t1 Meas)
        {0x12E, 0x20, 0x20}, // F_SDE_2X_TEST = 1(SCAN_SLOW=1)
        {0x00A, 0x00, 0xFF}, // Upper Criteria MSB=0 & Lower Criteria MSB=0
        {0x00B, 0x05, 0xFF}, // Lower Criteria=5.
        {0x00C, 0x28, 0xFF}, // Upper Criteria=40.
    };

    Reset_All_BBlk();
    Set_Datalog_Block_as_BB(); // prevent datalog block erased by below MLC_erase

    SET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Erase(0, TOTAL_BLK, DONOT_MARKBB);

    VSGS_VSGD_Detection_2A(SGD, HIGH_VT, 3200, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E);  //VCGRV = 3.2V

    Reset_Select_BB_Map(SUBBB);
    Add_Map1_to_Map2(TEMP, SUBBB);

    Reset_Select_BB_Map(TEMP);

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array2);

        FOR_EACH_LOOP(adr.phy.blk, 0, TOTAL_BLK, 1)
        {
            FOR_EACH_STR(adr.phy.str)
            {
                WL_RC_Check_By_Die(die, adr, DLY_400);
            }
        }

        RESET_PARAMETERS(die, Para_Array2);

    }

    BB_Map_intersect(TEMP, SUBBB);    // compare the number of BB in TEMP and SUBBB and put common BB in TEMP. other BB in SUBBB.

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(blk, 0, TOTAL_BLK, 1)
        {
            if((Is_BB(die, blk, TEMP)) && (Is_Element_In_List(edge_blkList, sizeof(edge_blkList)/sizeof(edge_blkList[0]), blk) == 0))
            {
                if((blk%4)<2)
                {
                    xferBlk = blk - 2;
                }
                else
                {
                    xferBlk = blk + 2;
                }

                BB_Add(die, xferBlk, TEMP);
            }
        }
    }

    Add_Map1_to_Map2(SUBBB, TEMP);
    Reset_Select_BB_Map(SUBBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FLASH_WRITE;

    FULLARRAY_BB_CHECK;

    POR_CHECK_ALL_DIE;

    return(PF_Check());

}
