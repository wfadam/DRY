uint8 d_MONITOR_wl_mh_ivr_scr1960p1(void) // tb_492 nvcc Base on SCR-1568.1
{
    uint8 die;
    Para_Table Para_Array[] =
    {
        {0x103, 0x00, 0x20},   //F_NEG_SLC=0
        {0x0AB, 0x00, 0x03},   //F_ZONESTEP =0
        {0x0AB, 0x00, 0x04},   //F_ZONESTEP_WL=0
        {0x06C, 0x02, 0x0F},   //F_VBLC_PVFY_SLC=0.1V   //DAC value change for CS2 material
        {0x06B, 0x1C, 0x1F},   //F_VBLC_PVFY_MLC =0.7V  //DAC value change for CS2 material
        {0x093, 0x1F, 0x1F},   //F_R5_READ_SLC =42.32us
        {0x120, 0x00, 0x30},   //F_LAY_READ_EN = disable
        {0x104, 0x80, 0x80},   //F_SGS_OFF=enable
        {0x105, 0x80, 0x80},   //F_SGSB_OFF=enable
        {0x094, 0xC0, 0xC0},   //F_RR1=2.24us
        {0x091, 0x40, 0x60},   //F_RR3_READ=3.36us
        {0x093, 0x60, 0x60},   //F_RR6=2.72us
        {0x002, 0x40, 0xC0},   //F_TESTTEMP=01
        {0x00F, 0x01, 0x01},   //F_TSB=1 for TSB read mode
        {0x011,    7, PLUS|0x3F}, //SDE Address  0x11[5:0] =71.6ns Default and +7DAC (decimal) = 80ns
    };

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);

        WL_MH_IVR_WO_Str(die, IGN_BITS_SCR1960P0, DLY_200);

        RESET_PARAMETERS(die, Para_Array);
    }

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
