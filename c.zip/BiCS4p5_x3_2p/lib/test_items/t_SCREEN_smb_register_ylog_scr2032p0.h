uint8 t_SCREEN_smb_register_ylog_scr2032p0(void)  // tb_199 nvcc Base on SCR-1050.3
{
    uint8 die;

    Para_Table Para_Array[] =
    {
        {0xDE,  4,  MINUS|0x1F},  // VDD=Default-4DAC
    };

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);

        SMB_Screen_YLOG_FIFO(die, IGN_BITS_SCR2032P0);

        RESET_PARAMETERS(die, Para_Array);
    }

    return(PF_Check());
}
