uint8 t_SCREEN_TLC_cache_prog_2plane_b2_scr2118p1(void) //tb_784 nvcc
{
    uint8 die;
    uint16 good_blk;

    g_CMDB2_FLAG = CMDB2_ENABLE;

    Para_Table Para_Array[] =
    {
        {0xDE,    4, PLUS|0x1F},  //Set VDD+4DAC
        {0x16,    2, PLUS|0x1F},  //Set VDDSA+2DAC
        {0x17,    2, PLUS|0x1F},
    };

    TM_Entry();

    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_by_Die(die, 0x100, TOTAL_BLK, TOTAL_PLN, PAIR_10);
        if(good_blk != TOTAL_BLK)
        {
            MLC_Erase_By_Die(die, good_blk, good_blk + 20, MARKBB);

            SET_PARAMETERS(die, Para_Array);

            TLC_Cache_Program_SP_Scramble_By_Die(die, good_blk, good_blk + 20);
            TLC_Cache_Read_SP_Sample_Page_By_Die(die, good_blk, good_blk + 20, STR3);

            RESET_PARAMETERS(die, Para_Array);
        }
    } 

    TM_Exit();

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = 3;
    GBB_limit.MarkBB = MARKBB;
    GBB_Check(GBB_limit);

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
