uint8 t_SCREEN_VDDA_scr2158p0(void) //tb435 nvcc 662p3
{
    uint8 i;

    GBB_Check_Init(GBB_limit);

    Para_Table Para_Array[2][1] =
    {
        {{0xDB, 2, PLUS|0x0F}},
        {{0xDB, 2, MINUS|0x0F}}, 
    };

    MLC_Margin_Erase();

    for(i = 0; i < 2; i ++)
    {              
        SET_PARAMETERS_ALL_DIE(Para_Array[i]);
        
        Margin_Block_Check(BIT_IGNORE_110);

        RESET_PARAMETERS_ALL_DIE(Para_Array[i]);
    } 

    MLC_Margin_Erase();

    GBB_limit.GBB_CHECK_PLN=4;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 

    return(PF_Check());
}
