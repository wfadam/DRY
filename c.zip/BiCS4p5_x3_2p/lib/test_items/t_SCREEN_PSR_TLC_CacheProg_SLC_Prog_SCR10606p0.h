uint8 t_SCREEN_PSR_TLC_CacheProg_SLC_Prog_SCR10606p0(void) //tb_849 nvcc SCR958p4
{
    uint8 die, loop, FailFlag = PASS;
    uint16 SLC_Blk, TLC_Blk, delay, i;

    Para_Table Para_Array[] =
    {
        {0x114, 0x01, 0x01}, //FVFYFULL=1, full pvfy
        {0x131, 0x80, 0x80}, //AIPR_SUSR = enable
    };

    Para_Table Para_Array1[2][3] =
    {
        {{VDD_ADR, 2,  PLUS|0x1F}, {VDDSA_PB0_ADR, 2,  PLUS|0x1F}, {VDDSA_PB1_ADR, 2,  PLUS|0x1F}}, //Set VDD/VDDSA_P0/VDDSA_P1+2DAC
        {{VDD_ADR, 2, MINUS|0x1F}, {VDDSA_PB0_ADR, 2, MINUS|0x1F}, {VDDSA_PB1_ADR, 2, MINUS|0x1F}}, //Set VDD/VDDSA_P0/VDDSA_P1-2DAC
    };

    g_BuFF_Prt = (uint8 *)SETBUF(0); //TLC Pattern
    Scramble_Random_Byte(MLC_SEED, 0, TOTAL_COL + TOTAL_PAGE * OFFSET_ALIGN);

    g_BuFF_Prt = (uint8 *)SETBUF(1); //SLC Pattern
    FOR_EACH_LOOP(i, 0, TOTAL_COL_NO_CRD, 2)
    {
        g_BuFF_Prt[i]   = 0xAA;
        g_BuFF_Prt[i+1] = 0x55;
    }
    g_BuFF_Prt = (uint8 *)SETBUF(0);

    SET_PARAMETERS_ALL_DIE(Para_Array);

    TM_Entry();

    FOR_EACH_DIE(die)
    {
        SLC_Blk = Search_Pair_Blk_BBMap_by_Die(die, TOP_BLK_EDGE, 0, TOTAL_PLN, PAIR_1);
        TLC_Blk = Search_Pair_Blk_BBMap_by_Die(die, BOT_BLK_EDGE, TOTAL_BLK, TOTAL_PLN, PAIR_1);

        if((SLC_Blk != TOTAL_BLK) && (TLC_Blk != TOTAL_BLK))
        {
            FOR_EACH_LOOP(loop, 0, 2, 1) //Set VDD/VDDSA+-2DAC
            {
                SET_PARAMETERS(die, Para_Array1[loop]);

                FOR_EACH_LOOP(delay, 0, 2600, 120)
                {
                    if(PSR_TLC_CacheProg_SLC_Prog(die, TLC_Blk, SLC_Blk, delay) != PASS)
                    {
                        Print_Die_Failure_Add_BD(die, "");
                        FailFlag |= FAIL;
                    }
                    if(FailFlag) break;
                }

                RESET_PARAMETERS(die, Para_Array1[loop]);
                
                if(FailFlag) break;
            }
        }
    }

    TM_Exit();

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    return(PF_Check());
}
