uint8 d_Scan_Parm()
{
	uint8 die;

	FOR_EACH_DIE(die)
	{
		Parm_Scan(die);
	}

	g_Incoming_Para_Scan_En = 1;
	
	return(PF_Monitor());
}
