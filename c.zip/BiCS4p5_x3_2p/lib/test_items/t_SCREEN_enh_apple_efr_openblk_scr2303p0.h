uint8 t_SCREEN_enh_apple_efr_openblk_scr2303p0(void)//tb__761 nvcc
{
    uint8 die;
    uint16 array_idx, blk;
    GBB_Check_Init(GBB_limit);
    uint16 start_blk[3] = {MARGIN_G1_START, MARGIN_G0_START, MARGIN_G2_START};

    FOR_EACH_LOOP(array_idx,0,3,1)
    {
        FOR_EACH_LOOP(blk, start_blk[array_idx], start_blk[array_idx]+16, 2)
        {
            FOR_EACH_DIE(die)
            {
                MLC_Erase_By_Die(die, blk, blk+1, DONOT_MARKBB);
                TLC_Cache_Program_By_Die(die,0, 1, blk); //program WL0
                TLC_Cache_Read_WL_Loop(die, 0, 1, blk, 110);    //read WL0

                POR_One_Die(die);

                TLC_Cache_Read_WL_Loop(die, 0, 1, blk, 110);    //read WL0
                TLC_Cache_Program_By_Die(die,1, 24, blk); //program WL1-23
                TLC_Cache_Read_WL_Loop(die, 1, 24, blk, 110); //Read WL1-23
                TLC_Cache_Program_By_Die(die,24, 48, blk); //prorgam WL24-27
                TLC_Cache_Read_WL_Loop(die, 47, 24, blk, 110); //Read WL47-24

                POR_One_Die(die);

                TLC_Cache_Program_By_Die(die,48, 95, blk); //program WL48-94
                TLC_Cache_Read_WL_Loop(die, 0, 95, blk, 110); //Read WL0-94
                TLC_Cache_Program_By_Die(die, 95, TOTAL_WL, blk); //program WL95
                TLC_Cache_Read_WL_Loop(die, 0, TOTAL_WL, blk, 110); //Read WL0-95
                MLC_Erase_By_Die(die, blk, blk+1, DONOT_MARKBB);
            }
        }
    }
    
    GBB_limit.GBB_CHECK_PLN=3;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 

    return(PF_Check());
}
