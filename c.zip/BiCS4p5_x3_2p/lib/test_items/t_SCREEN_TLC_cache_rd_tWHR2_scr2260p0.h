uint8 t_SCREEN_TLC_cache_rd_tWHR2_scr2260p0(void) //tb_786 nvcc SCR2201p0
{
    uint8 die;
    uint16 GoodBlk;


    FOR_EACH_DIE(die)
    {
        GoodBlk = Search_Pair_Blk_BBMap_by_Die(die, 0, TOTAL_BLK, TOTAL_PLN, PAIR_1);

        if(GoodBlk != TOTAL_BLK)
        {
            MLC_Erase_By_Die(die, GoodBlk, GoodBlk+2, DONOT_MARKBB);
            MLC_Program_Scramble_By_Die(die, GoodBlk, GoodBlk+2, DONOT_MARKBB, DONOT_PRINT);
            
            if(MLC_Cache_Read_Scramble_STR0_By_Die(die, GoodBlk, GoodBlk+2, IGN_BITS_SCR2260p0) != PASS)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }
    }


    return(PF_Check());
}
