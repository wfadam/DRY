uint8 d_XY_Location_Display(void)//tb__120
{
    uint8 die = 0;

    FOR_EACH_DIE(die)
    {
        POR_Check(die);

        if(WXY_CRC_Verify(die) != 0)
        {
            Print_Die_Failure(die, "CRC Check");
            Read_XY_3copy_by_Die(die);
        }
    }

    return(PF_Monitor());
}
