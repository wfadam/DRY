uint8 t_SCREEN_bl_leak_repair_256G_out_scr2034p0(void)  //tb__172 nvcc SCR532p5
{
    uint8 die;

    Para_Table Para_Array[] =
    {
        {0x010, 0x00, 0x02}, //F_CRD_EN=disable
        {0x103, 0x00, 0x20}, //F_NEG_SLC=0
        {0x0AB, 0x00, 0x07}, //F_ZONESTEP=0, F_ZONESTEP_WL=0
        {0x06C, 0x0A, 0x0F}, //F_VBLC_PVFY_SLC=0.9V
        {0x06B, 0x10, 0x1F}, //F_VBLC_PVFY_MLC =0.4V
        {0x093, 0x1F, 0x1F}, //F_R5_READ_SLC =42.32us
        {0x091, 0x06, 0x1F}, //F_R5_READ_LP=18us  
        {0x113, 0x00, 0x0C}, //F_SV_MANUAL_SLC=0, F_SV_MANUAL_MLC=0 
        {0x120, 0x00, 0x30}, //F_LAY_READ_EN=disable in TSB mode
    }; 

    FOR_EACH_DIE(die)
    {
        Scan_BC_To_Select_Array(die, g_Temp_BC, PREBCMASK, NOBC_PRINT);
        
        SET_PARAMETERS(die, Para_Array);

        if(Bitline_Leakage(die) != 0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }

        RESET_PARAMETERS(die, Para_Array);

        Scan_BC_To_Select_Array(die, g_Outgoing_BC, PSTBCMASK, GBC_PRINT);
    }

    BC_Limit_Check(BC_LIMIT_PER_PLN, GBC_LIMIT_PER_PLN, g_Temp_BC, g_Outgoing_BC);

    ROMBLOCK_UPDATE;

    return(PF_Check());
}
