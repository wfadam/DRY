uint8 t_SCREEN_mh_open_scr1882p1(void)  //tb_470 nvcc Base on SCR543.2
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        MH_Open(die, BIT_IGNORE_4);
    }

    FULLARRAY_BB_CHECK;
    return(PF_Check());
}
