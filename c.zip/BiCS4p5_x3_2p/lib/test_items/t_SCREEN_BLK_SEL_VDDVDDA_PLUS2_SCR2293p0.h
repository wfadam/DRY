uint8 t_SCREEN_BLK_SEL_VDDVDDA_PLUS2_SCR2293p0(void) //tb_836 nvcc SCR892p1
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(BLK_SEL_VDDVDDA_Shift(die, 2, PLUS, BIT_IGNORE_8) != PASS)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}
