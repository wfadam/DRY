uint8 t_SCREEN_set_get_w_chip_select_scr2112p1(void) //tb_742_nvcc
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Set_Get_Feature(die,0xD5,0xD4)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
        FEATURE_RESET;
    }

   return(PF_Check());
}
