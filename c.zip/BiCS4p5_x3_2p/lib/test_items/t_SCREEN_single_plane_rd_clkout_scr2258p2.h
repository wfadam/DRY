uint8 t_SCREEN_single_plane_rd_clkout_scr2258p2()    //tb__215 nvcc BICS4 SCR2258p2
{

    uint8 die=0, pln=0;
    uint16 good_blk=0;

    Para_Table Para_Array[] =
    {
        {0xDE, 7, MINUS|0x1F},	//VDD -7DAC
    };


    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_by_Die(die, 0x20, TOTAL_BLK, TOTAL_PLN, PAIR_1);

        if(good_blk != TOTAL_BLK)
        {

            SLC_Erase_2A_by_Die(die, good_blk, good_blk+1, DONOT_MARKBB);

            FOR_EACH_PLN(pln)
            {
                SLC_Program_SP_Scramble_By_Die(die, good_blk+pln, good_blk+1+pln, DONOT_MARKBB, PRINT_FAIL);			//program plane0/1
            }

            SET_PARAMETERS(die, Para_Array);

            FOR_EACH_PLN(pln)
            {
                if(SLC_Read_SP_Scramble_Data_Clkin_By_Die_DLY40ms(die, good_blk+pln, BIT_IGNORE_255)!=0)
                {
                    Print_Die_Failure_Add_BD(die, "");
                }
            }

            RESET_PARAMETERS(die, Para_Array);
        }
    }

    return(PF_Check());

}
