uint8 t_SCREEN_slc_combos2e_scr1867p1(void) //tb_521_nvcc scr907p7
{   
    Para_Table Para_Array[] =
    {   
        {0x137, 0x08, 0x38}, //BSPF_EV_SLC[5:3] = 8(h08) bits
        {0x12F, 0x40, 0xF0}, //NLE_SLC[7:4] = 4 loops (default = 10 loops)
        {0x026, 0x60, 0xE0}, //F_DVCG_EVFY_SLC[7:5]=1.2V(default = 2V)
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    SLC_Erase_2A(0,TOTAL_BLK,MARKBB); 

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}