uint8 t_SCREEN_broken_daisy_chain_pt1_scr2010p0(void) //tb__732 nvcc Base on SCR1278p1
{
    uint8 die = 0;
    uint8 i = 0, j = 0;
    uint8 Err_Cnt = 0;

    uint16 Params[45] = { 0x03, 0x09, 0x15, 0x1D, 0x27, 0x2F, 0x37, 0x41, 0x47, 0x4F, 0x58, 0x5F, 0x67, 0x6F, 0x77, 0x7E, 0x86, 0x8E, 0x96, 0x9E, 0xA6, 0xA9, 0xB1, 0xB9, 0xC1 ,0xC8, 0xCB, 0xD3, 0xDB, 0xE3, 0xE7, 0xEF, 0xF8, 0x100, 0x108, 0x110, 0x116, 0x11A, 0x122, 0x12A, 0x12C, 0x134, 0x13C, 0x143, 0x14A};
    uint8 value[3] = {0x00, 0xFF, 0x00};

    FOR_EACH_DIE(die)
    {
        Err_Cnt = 0;

        FOR_EACH_LOOP(i, 0, 45, 1)
        {
            FOR_EACH_LOOP(j, 0, 3, 1)
            {
                if(Param_Daisy_Chain_Check(die, Params[i], value[j], 0xFF) != 0)
                {
                    BD_Add(die, TEMP);
                    Err_Cnt ++;
                }
                if(Err_Cnt > 5) break;
            }
            if(Err_Cnt > 5) break;
        }
    }

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
