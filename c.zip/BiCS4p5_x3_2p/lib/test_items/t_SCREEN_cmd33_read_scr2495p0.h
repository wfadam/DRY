uint8 t_SCREEN_cmd33_read_scr2495p0()    //tb__437 nvcc BICS4 SCR2495P0
{

    uint8 i;
    uint16 blk;
    uint16 start_blk[3] = {MARGIN_G1_START, MARGIN_G0_START, MARGIN_G2_START};

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {0x137, BSPF_EV_MLC_SET, BSPF_EV_MLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    FOR_EACH_LOOP(i, 0, 3, 1)
    {
        FOR_EACH_LOOP(blk, start_blk[i], start_blk[i]+16, TOTAL_PLN)
        {
            MLC_Erase(blk, blk+2, MARKBB);
            MLC_Program_6EBB(blk, blk+2, MARKBB);
            MLC_AIPR_Dynamic_Read_6EBB_CMD33(blk, blk+2, MARKBB, IGN_BITS_SCR2495p0);
        }
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 4;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());

}
