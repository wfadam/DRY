uint8 t_SCREEN_ping_pong_blk_scr2061p0(void)//tb__423 nvcc SCR1016p3
{
    uint16 good_blk = 0x20;

    GBB_Check_Init(GBB_limit);

    Para_Table Para_Array[] =
    {
        {0xDE, 1, MINUS|0x1F}  //Vdd= default - 1DAC
    };

    Ping_Pong_Screen(good_blk,BIT_IGNORE_110,Para_Array,sizeof(Para_Array)/sizeof(Para_Table));

    GBB_limit.GBB_CHECK_DIE=0;
    GBB_limit.MarkBB=MARKBB;

    GBB_Check(GBB_limit); 
	
    return(PF_Check());
}