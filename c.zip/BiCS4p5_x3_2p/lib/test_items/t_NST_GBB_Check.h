uint8 t_NST_GBB_Check(void)
{
	Add_Map1_to_Map2(SUBBB, TEMP); //Move total GBB from SUBBB to TEMP

	GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = 0; 
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}