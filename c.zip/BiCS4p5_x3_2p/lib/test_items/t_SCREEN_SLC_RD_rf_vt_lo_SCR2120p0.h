uint8 t_SCREEN_SLC_RD_rf_vt_lo_SCR2120p0(void) //tb__935 nvcc SCR968.5
{
    uint8 die = 0;

    FOR_EACH_DIE(die)
    {
        if(Outgoing_RomFuse_Vt(die, 0x10, DONOT_USE_4C)!=0) // VCGR_SLCR +0.2V (10h)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
