uint8 t_Dummy_Read_SCR2123p1(void)//tb__704 nvcc
{
    uint8 loop;
    uint8 DUMMY_READ_CYCLE_NUM=10;
    uint16 DUMMY_READ_START_COL=0x2000;

    FOR_EACH_LOOP(loop, 0, DUMMY_READ_CYCLE_NUM, 1)
    {
        if(Stamp_Exist_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, (DUMMY_READ_START_COL+loop*0x10), BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
        {
            MLC_Dummy_AIPR_Read();

            Program_Stamp_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, DUMMY_READ_START_COL+loop*0x10, BYTE_8);

            if(Stamp_Exist_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, (DUMMY_READ_START_COL+loop*0x10), BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
            {
                Print_Die_Failure(0, "RD stamp");
                Mark_All_Die_Bad(TEMP);
                break;
            }
        }
        else
        {
            print(0, "Skip Lp~\n", loop);
            Dummy_Wait(WAIT_DUMMY_READ);
        }
    }

    return (PF_Check());
}
