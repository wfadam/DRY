uint8 t_SCREEN_D2_refresh_read_scr2157p0(void)//tb__424 nvcc Bics4 SCR1879p1
{
    uint8 die=0, blk_idx, group_idx;
    uint16 gb;

#ifdef DENS_256_SW
    uint16 group_blk[8] = {0x00,0x02,0x04,0x06,0x08,0x0A,0x0C,0x0E};
#endif
#ifdef DENS_512_SW 
    uint16 group_blk[16] = {0x000,0x002,0x004,0x006,0x008,0x00A,0x00C,0x00E,0x800,0x802,0x804,0x806,0x808,0x80A,0x80C,0x80E};
#endif

    Para_Table Para_Array[] =
    {
        {0x0AB, 0xE0, 0xE0},   //SET BLKNUM_RFR=111 for 128 blocks/plane setting
        {0x0AB, 0x08, 0x08},   //Enable ocs6D to enable every string have different random data in same wl.
    };

    MLC_Erase(0, TOTAL_BLK, MARKBB);

    FOR_EACH_DIE(die)
    {
        gb = Search_Pair_Blk_BBMap_by_Die(die,0x30, TOTAL_BLK, TOTAL_PLN, 2);

        if(gb != TOTAL_BLK)
        {
            SET_PARAMETERS(die, Para_Array);

            FOR_EACH_LOOP(blk_idx, 0, 4, 1)
            {
                MLC_Program_SP_6D_By_Die(die, gb+blk_idx, gb+blk_idx+1, MARKBB, PRINT_FAIL, DONOT_SET_AB);

                FOR_EACH_LOOP(group_idx, 0, (sizeof(group_blk)/sizeof(group_blk[0])),1)
                {
                    // print(0, "B@\n", group_blk[group_idx]);
                    D2_Refresh(die, group_blk[group_idx]);

                    if(MLC_Read_SP_6D_By_Die(die, gb+blk_idx, gb+blk_idx+1, MARKBB, 120, DONOT_SET_AB)!=0)
                    {
                        Print_Die_Failure_Add_BD(die, "");
                        break;
                    }
                }

                MLC_Erase_SP_By_Die(die,gb+blk_idx, MARKBB);
            }

            RESET_PARAMETERS(die, Para_Array);
        }
    }

    return(PF_Check());
}
