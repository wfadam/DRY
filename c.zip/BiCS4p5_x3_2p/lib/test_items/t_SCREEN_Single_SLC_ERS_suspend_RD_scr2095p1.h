uint8 t_SCREEN_Single_SLC_ERS_suspend_RD_scr2095p1(void) //tb_735 nvcc SCR2095p0
{
    uint8 die=0, pln=0, i;
    uint16 blk_a, blk_b,blk_c;
    uint8 Suspend_CMD[3] = {0xFA, 0xFF, 0x51};

    GBB_Check_Init(GBB_limit);

    FOR_EACH_DIE(die)
    {         
        blk_a=Search_Pair_Blk_BBMap_Erase_by_Die(die, 0x300, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,SLC_ERASE);
        blk_b=Search_Pair_Blk_BBMap_Erase_by_Die(die, blk_a+2, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,SLC_ERASE);
        blk_c=Search_Pair_Blk_BBMap_Erase_by_Die(die, blk_b+2, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,SLC_ERASE);

        if((blk_a != TOTAL_BLK) && (blk_b != TOTAL_BLK) && (blk_c !=TOTAL_BLK))
        {

            for(i = 0; i < 3; i ++)
            {
                SLC_Program_SP_6D_By_Die(die,blk_a, blk_a+2,MARKBB, PRINT_FAIL);
                SLC_Program_SP_6D_By_Die(die,blk_b, blk_b+2,MARKBB, PRINT_FAIL);
                SLC_Program_SP_6D_By_Die(die,blk_c, blk_c+2,MARKBB, PRINT_FAIL);

                FOR_EACH_PLN(pln)
                {
                    if(SLC_Erase_Suspend_SP_6D_Sample_WL(die, blk_b+pln, blk_a+pln, BIT_IGNORE_8, IGN_BITS_SLC, DLY_100, Suspend_CMD[i])!=0)  BD_Add(die, TEMP);
                    if(SLC_Erase_Suspend_SP_6D_Sample_WL(die, blk_c+pln, blk_a+pln, BIT_IGNORE_8, IGN_BITS_SLC, DLY_1000, Suspend_CMD[i])!=0) BD_Add(die, TEMP);
                }

                FOR_EACH_PLN(pln)
                {
                    if(SLC_Read_SP_6D_For_WL(die, blk_a+pln,IGN_BITS_SLC)!=0) BD_Add(die, TEMP);
                }

                SLC_Erase_by_Die(die, blk_a, blk_a+1, MARKBB);
                SLC_Erase_by_Die(die, blk_b, blk_b+1, MARKBB);
                SLC_Erase_by_Die(die, blk_c, blk_c+1, MARKBB);
            }
        }
    }

    GBB_limit.GBB_CHECK_PLN=0;
    GBB_limit.MarkBB=DONOT_MARKBB;

    GBB_Check(GBB_limit); 

    return(PF_Check());
}
