uint8 t_SCREEN_bl_leak_open_gbc_SH_scr2332p0(void)  //tb_165 nvcc SCR1924p1
{
    uint8 die, P91_Value;
    uint16 GoodBlk;

#ifdef DENS_256_SW
    P91_Value = 0x06;
#endif
#ifdef DENS_512_SW
    P91_Value = 0x0B;
#endif

    Para_Table Para_Array[]= 
    {
        {0x0AB, 0x00, 0x0F},    //ZONESTEP =0; ZONESTEP_WL=0, OCS6D_OPT = 0
        {0x103, 0x00, 0x20},    //NEG_SLC = 0
        {0x06C, 0x0A, 0x0F},    //set VBLC_PVFY_SLC to 0.5V
        {0x06B, 0x10, 0x1F},    //Set VBLC_PFYF_MLC to 0.4V
        {0x093, 0x1F, 0x1F},    //Set R5_READ_SLC or RP7 = 42.32 us(Max)
        {0x010, 0x00, 0x02},    //F_CRD_EN = disable
        {0x113, 0x00, 0x0C},    //SV_MANUAL_MLC/SV_AUTO_MLC = 0
        {0x120, 0x00, 0x30},    //F_LAY_READ_EN = disable in TSB Mode
        {0x091, P91_Value, 0x1F},    //Set R5_READ_LP or SP2 = 18us(0x06 for 256Gb), 30.8us(0x0B for 512Gb)
    };

    FOR_EACH_DIE(die)
    {
        GoodBlk = Search_Pair_Blk_BBMap_Erase_by_Die(die, TOP_BLK_EDGE, 0, 16, PAIR_4, MLC_ERASE);

        if(GoodBlk != TOTAL_BLK)
        {
            Scan_BC_To_Select_Array(die, g_Temp_BC, PREBCMASK, NOBC_PRINT);

            Bitline_Open_wo_4E(die, GoodBlk);

            SET_PARAMETERS(die, Para_Array);

            Bitline_Leakage(die);

            RESET_PARAMETERS(die, Para_Array);

            Scan_BC_To_Select_Array(die, g_Outgoing_BC, PSTBCMASK, GBC_PRINT);
        }
    }

    BC_Limit_Check(BC_LIMIT_PER_PLN, GBC_LIMIT_PER_PLN, g_Temp_BC, g_Outgoing_BC);

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
