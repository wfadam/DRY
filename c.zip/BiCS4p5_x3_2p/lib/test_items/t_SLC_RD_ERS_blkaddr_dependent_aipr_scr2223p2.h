uint8 t_SLC_RD_ERS_blkaddr_dependent_aipr_scr2223p2(void)  //tb_399 nvcc SCR2223p0
{
    uint8 Loop = 0;
    uint16 blk = 0;

    Para_Table Para_Array[] = 
    {
        {0x0AB, 0x08, 0x08}, //enable ocs6D to enable every string have different random data in same wl.
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    FOR_EACH_LOOP(Loop, 0, 0xF, 2)
    {
        FOR_EACH_LOOP(blk, Loop, TOTAL_BLK, 0x10)
        {
            SLC_AIPR_Read_6DBB(blk, blk+1, MARKBB, IGN_BITS_SLC, DONOT_SET_AB);
            SLC_Erase(blk, blk+1,MARKBB);
        }
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;
    
    return(PF_Check());
}
