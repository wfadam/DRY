uint8 t_Outgoing_Parm_Check(void)
{
    uint8 die = 0;
   
    FOR_EACH_DIE(die)
    {
        if(Parm_Check(die)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}
