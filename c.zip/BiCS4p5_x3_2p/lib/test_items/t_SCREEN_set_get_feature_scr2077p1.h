uint8 t_SCREEN_set_get_feature_scr2077p1(void) //tb_745_nvcc
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Set_Get_Feature(die,0xEF,0xEE)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

   return(PF_Check());
}
