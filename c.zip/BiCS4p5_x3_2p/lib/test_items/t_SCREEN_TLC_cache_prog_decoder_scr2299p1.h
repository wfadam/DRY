uint8 t_SCREEN_TLC_cache_prog_decoder_scr2299p1(void) //tb_787 nvcc
{
    uint8 die, DieFlag = 0;
    uint16 StartBlk, StopBlk, BlkA = TOTAL_BLK, BlkB = TOTAL_BLK;

    g_CMDB2_FLAG = CMDB2_ENABLE;

#ifdef DENS_256_SW
    StartBlk = 0x64;
    StopBlk = 0x7FF;
#endif
#ifdef DENS_512_SW
    StartBlk = 0xD4;
    StopBlk = 0xFFF;
#endif

    FOR_EACH_DIE(die)
    {
        DieFlag = 1;

        FOR_EACH_LOOP(BlkA, StartBlk, StopBlk-StartBlk, TOTAL_PLN)
        {
            BlkB = StopBlk - BlkA - 1; //BLK79A,79B for 256G; BLKF2A/F2B for 512G

            if((Is_BB(die, BlkB, MAIN) == 0) && (Is_BB(die, BlkB+1, MAIN) == 0) && (Is_BB(die, BlkA, MAIN) == 0) && (Is_BB(die, BlkA+1, MAIN) == 0))
            {
                DieFlag = 0;
                break; //Find another pair of block
            }
        }

        if(DieFlag != 0)
        {
            Print_Die_Failure_Add_BD(die, "find GB");
        }
        else
        {
            print(0, "D@ GB @, @\n", die, BlkA, BlkB);

            MLC_Erase_By_Die(die, BlkA, BlkA+1, DONOT_MARKBB);
            MLC_Erase_By_Die(die, BlkB, BlkB+1, DONOT_MARKBB);

            DieFlag |= MLC_Cache_Program_Asym_Blk_WL0(die, BlkA, BlkB+1); //BLK0x64, BLK79B
            DieFlag |= MLC_Cache_Program_Asym_Blk_WL0(die, BlkA+1, BlkB); //BLK0x65, BLK79A

            DieFlag |= MLC_Cache_Read_Asym_Blk_WL0(die, BlkA, BlkB+1, IGN_BITS_MLC*2); //Default MLC Read Ignorebit*2
            DieFlag |= MLC_Cache_Read_Asym_Blk_WL0(die, BlkA+1, BlkB, IGN_BITS_MLC*2); //Default MLC Read Ignorebit*2
            
            MLC_Erase_By_Die(die, BlkA, BlkA+1, DONOT_MARKBB);
            MLC_Erase_By_Die(die, BlkB, BlkB+1, DONOT_MARKBB);
            
            if(DieFlag)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }
    }

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
