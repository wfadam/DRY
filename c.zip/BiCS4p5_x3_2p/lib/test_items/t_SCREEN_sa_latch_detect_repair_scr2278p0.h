uint8 t_SCREEN_sa_latch_detect_repair_scr2278p0(void) //tb_205 nvcc SCR579p3
{
    uint8 die = 0, loop;
    uint8 byte0[28] = {0xAA, 0x55, 0xCC, 0x33, 0xF0, 0x0F, 0x99, 0x66, 0x00, 0xFF, 0x00, 0xFF, 0x92, 0x6D, 0xFB, 0x04, 0x94, 0x6B, 0x24, 0x92, 0xDB, 0x6D, 0x44, 0x92, 0xCA, 0x35, 0xBB, 0x6D};
    uint8 byte1[28] = {0x55, 0xAA, 0x33, 0xCC, 0x0F, 0xF0, 0x66, 0x99, 0xFF, 0x00, 0x00, 0xFF, 0x29, 0xB6, 0x04, 0xFB, 0x45, 0xBA, 0x49, 0x24, 0xB6, 0xDB, 0x49, 0x14, 0x9A, 0x65, 0xB6, 0xEB};

    Para_Table Para_Array[] = 
    {
        {0x011,  4,  PLUS|0x3F}, //SDE+4DAC
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);
    
    FOR_EACH_DIE(die)
    {
        Scan_BC_To_Select_Array(die, g_Temp_BC, PREBCMASK, NOBC_PRINT);

        FOR_EACH_LOOP(loop, 0, 20, 1)
        {
            SA_Latch_Test1(die, 28, byte0, byte1, REPAIR); // Latch Detection, repair if fail test
            SA_Latch_Test2(die, BIT_IGNORE_0, REPAIR);     //Latch check, repair if fail test
            if(SA_Latch_Test3(die, REPAIR) != PASS)        //Random Pattern Check, repair if fail test
            {
                Print_Die_Failure_Add_BD(die, "");
                break;
            }
        }

        Scan_BC_To_Select_Array(die, g_Outgoing_BC, PSTBCMASK, GBC_PRINT);
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    BC_Limit_Check(BC_LIMIT_PER_PLN, GBC_LIMIT_PER_PLN, g_Temp_BC, g_Outgoing_BC);

    ROMBLOCK_UPDATE;

    return(PF_Check());
}
