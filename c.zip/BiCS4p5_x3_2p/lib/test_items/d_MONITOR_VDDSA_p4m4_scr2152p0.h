uint8 d_MONITOR_VDDSA_p4m4_scr2152p0(void) //tb444 nvcc 2151p0
{
    uint8 i;

    Para_Table Para_Array[2][2] =
    {
        {{0x16, 4, PLUS|0x1F},{0x17, 4, PLUS|0x1F}},
        {{0x16, 4, MINUS|0x1F},{0x17, 4, MINUS|0x1F}}, 
    };

    MLC_Margin_Erase();

    for(i = 0; i < 2; i ++)
    {              
        SET_PARAMETERS_ALL_DIE(Para_Array[i]);

        Margin_Block_Check(BIT_IGNORE_110);

        RESET_PARAMETERS_ALL_DIE(Para_Array[i]);
    } 

    MLC_Margin_Erase();

    GBB_MONITOR_PRINT;
    return(PF_Monitor());
}
