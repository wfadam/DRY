uint8 t_SCREEN_blksel_ref_scr1982p0(void) //tb__474 nvcc scr471.6
{
    uint8 die;

    Para_Table Para_Array[] =
    {
        {0x119, 0x40, 0x40},       //DISABLE BBSENDIS_PE, BAD BLK SENSE CONTROL FOR PGM/ERASE
        {0x118, 0x00, 0x04},       // F_WL2WLLD_EN=0
        {0x118, 0x02, 0x02},       // F_WL2SUB_EN=1
        {0x119, 0x00, 0x0C},       // F_PPNPPE_MLC/SLC=0
        {0x117, 0x00, 0x30},       // F_PAP_ERASE=0
        {0x118, 0x10, 0x10},       // F_WLLD_N0ERA=1
        {0x04C, 0x00, 0xC0},       // F_PROGSRC_WLLD=VSS
        {0x100, 0x00, 0x01},       // F_BL_BIAS_STRPCG=VSS
        {0x0AE, 0x24, 0x3C},       // F_WLLD_IDT = 500nA
        {0x0AE, 0x01, 0x03},       // F_WLLD_ICM= 1000nA
        {0x0AE, 0xC0, 0xC0},       // F_WLLD_ICS_RANGE= 12.5nA
        {0x083, 0xF0, 0xF0},       // F_PD1_WLLD= 2571.20us
        {0x052, 0x02, 0x0F},       // INC_VPGM_WL2SUB = 0.8V
        {0x046, 0x00, PLUS|0xFF},       // VPGMU = 13V 46h[7:0]=60h
    };

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);
        BLKSEL_LI_Screen(die, DAC_RD);
        RESET_PARAMETERS(die, Para_Array);
    }

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
