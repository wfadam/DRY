uint8 d_Wait_25m()
{
    return(Wait_Start_Signal(25));
}