uint8 t_SCREEN_SRG_SLC_prg_read_scr2192p1(void)  // tb_754 nvcc Base on SCR1461.0
{
    uint8 die;
    uint16 blk_a, blk_b;

    FOR_EACH_DIE(die)
    {
        // Select 2 pairs of good blocks, start from block 0x300
        blk_a = Search_Pair_Blk_BBMap_Erase_by_Die(die, 0x300, TOTAL_BLK, TOTAL_PLN, PAIR_1, SLC_ERASE);
        blk_b = Search_Pair_Blk_BBMap_Erase_by_Die(die, blk_a + 2, TOTAL_BLK, TOTAL_PLN, PAIR_1, SLC_ERASE);

        if((blk_a != TOTAL_BLK) && (blk_b != TOTAL_BLK))
        {

            SLC_Program_SP_Scramble_By_Die(die, blk_b, blk_b + 2, MARKBB, PRINT_FAIL);
            
            
            SLC_Erase_by_Die(die, blk_a, blk_a + 2, MARKBB);

            SLC_Program_SP_6D_SRG_SLC_Read_SP_Scramble_By_Die(die, blk_a, blk_b, IGN_BITS_SLC);
            SLC_Program_SP_6D_SRG_SLC_Read_SP_Scramble_By_Die(die, blk_a + 1, blk_b + 1, IGN_BITS_SLC); 
            

            SLC_Read_SP_6D_By_Die(die, blk_a, blk_a + 2, MARKBB, IGN_BITS_SLC, 0x70, PRINT_FAIL); 
            
            SLC_Erase_by_Die(die, blk_a, blk_a + 2, MARKBB);
            SLC_Erase_by_Die(die, blk_b, blk_b + 2, MARKBB);
        }
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = 0;
    GBB_limit.MarkBB = MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}