uint8 t_SCREEN_regtrans_slc_scr2164p0_WO_TM(void)  // tb_203 nvcc Base on SCR1234.1
{
	Para_Table Para_Array[] =
    {
        {0x0DE, 4, MINUS|0x1F},  // VDD - 4DAC
    };

    SLC_Read_Latch_Corruption(IGN_BITS_SCR2164P0, Para_Array, sizeof(Para_Array) / sizeof(Para_Table));

    return(PF_Check());
}
