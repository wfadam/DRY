uint8 t_SLC_PRG_all00_2tier_scr1946p0(void)//tb__270 nvcc
{
    Para_Table Para_Array[] =
    {
    	{0x13A, 0x80, 0x80}, // Set BSCAN_2TIER_SLC, to 2-Tier
		{0x139, 0x3C, 0xFC}, // set bspf_prog_slc to 15 bits(default)
		{0x133, 0x00, 0x80}, // set ZBITSCAN_SLC = disable
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    SLC_ALL00_Program(0, TOTAL_BLK);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
