uint8 t_SCREEN_weak_pump_erase_scr1989p0(void)//tb_522 nvcc scr633p1
{  
    uint8 i;


#ifdef DENS_256_SW
    uint16 start_blk[3] = {0x3C0, 0x00, 0x3E0};
    uint16 stop_blk[3] = {0x3DF, 0x01F, 0x3FF};
#endif
#ifdef DENS_512_SW 
    uint16 start_blk[3] = {0x790, 0x00, 0x7B0};
    uint16 stop_blk[3] = {0x7AF, 0x01F, 0x7CF};
#endif

    Para_Table Para_Array[] =
    {
        {0x12F, 0x05, 0x0F}, // NLE_MLC=5
        {0x015, 0x0F, 0x0F}, // SDE_PMP_VM_RIGHT
        {0x0BD, 0x0F, 0x0F}, // SDE_PMP_UM_RIGHT
        {0x0F7, 0x0F, 0x0F}, // SDE_PMP_UM_LEFT - Pump clock for VPGM and VERA
        {0x0FD, 0x0F, 0x0F}, // SDE_PMP_VM_LEFT
        {0x117, 0x00, 0x40}, // VERA_STC_MLC
        {0x134, 0x00, 0x30}, // SKIPEVFY_MLC
        {0x0B9, 0x80, 0xC0}, // F_PMPDRREF = 1.95V
        {0x0BD, 0x80, 0x80}, // PMPCLK_X2
    };

    //PrtLog(LV_SUB_NAME, "Weak_Pump_Screen\n");
    for(i=0; i<3; i++)
    {
        MLC_Erase(start_blk[i], stop_blk[i], DONOT_MARKBB);
        MLC_Program_6DBB_WL(start_blk[i], stop_blk[i], DONOT_MARKBB,SET_AB,0,1);
    }
    SET_PARAMETERS_ALL_DIE(Para_Array);  

    SetVcc(2300, VCCQ, 0, 0); //Set VCC to 2.30V.
    Delay_uSec(10000); //1msec delya to make sure that the tester set Vcc

    for(i=0; i<3; i++)
    {
        MLC_Erase(start_blk[i], stop_blk[i], MARKBB);
    }

    SetVcc(NVCC, VCCQ, 0, 0); //Set VCC to NVCC
    Delay_uSec(10000); //1msec delya to make sure that the tester set Vcc

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    for(i=0; i<3; i++)
    {
        MLC_Erase(start_blk[i], stop_blk[i], DONOT_MARKBB);
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN=20;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 

    return(PF_Check());
}
