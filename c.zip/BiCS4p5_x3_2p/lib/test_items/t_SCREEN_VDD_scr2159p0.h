uint8 t_SCREEN_VDD_scr2159p0(void) //tb428 nvcc 661p9
{
    uint8 i;

    GBB_Check_Init(GBB_limit);

    Para_Table Para_Array[2][1] =
    {
        {{0xDE, 2, PLUS|0x1F}},
        {{0xDE, 2, MINUS|0x1F}}, 
    };

    MLC_Margin_Erase();

    for(i = 0; i < 2; i ++)
    {              
        SET_PARAMETERS_ALL_DIE(Para_Array[i]);

        Margin_Block_Check(BIT_IGNORE_150);

        RESET_PARAMETERS_ALL_DIE(Para_Array[i]);
    } 

    MLC_Margin_Erase();

    GBB_limit.GBB_CHECK_PLN=4;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 

    return(PF_Check());
}
