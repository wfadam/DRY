uint8 t_SCREEN_open_block_1WL_by16_B2_scr2014p1(void)  //tb__421 nvcc SCR2014p0
{
    int blk;
    int Loop = 0, blk_temp;
    ADR_Init(adr);
    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE=0;
    GBB_limit.MarkBB=MARKBB;

    g_CMDB2_FLAG = CMDB2_ENABLE;
    // For the GB during programming in this item, MT controlled by xml file, please align with prodcut PE before using this.

    // 1. Temp para change VDD+4DAC , Move out in case return in the middle.
    Para_Table Para_Array[] =
    {
        {0x0DE, 4, PLUS|0x1F},
        {0x06B, 1, PLUS|0x1F},
        {0x0AB, 0x08, 0x08},  //Enable ocs6D to enable every string have different random data in same wl.
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    // 2. MLC Erase ALL Blocks with status check
    print(0, "STEP2: MLC ERS\n");

    MLC_Erase_2A(0, TOTAL_BLK, MARKBB);
    FULLARRAY_BB_CHECK;
    Reset_Select_BB_Map(TEMP);

    //3. From MIN to MAX (Ascending order) ALL Blocks perform open block MLC Program - WL0. All Strings 0,1,2,3 with status check
    print(0, "STEP3: Ascending MLC PRG\n");

    FOR_EACH_LOOP(Loop, 0, 0x0F, 2)
    {
        FOR_EACH_LOOP(adr.phy.blk, Loop, TOTAL_BLK, 0x10)
        {
            // print(0," sweep up BLK@\n", adr.phy.blk);
            MLC_Program_6D_2A_1WL(adr, DONOT_SET_AB, MARKBB);
        }
    }
    GBB_Check(GBB_limit); 
    Reset_Select_BB_Map(TEMP);

    // 4. MLC Erase ALL Blocks with status check
    print(0, "STEP4: MLC Erase\n");
    MLC_Erase_2A(0, TOTAL_BLK, MARKBB);
    FULLARRAY_BB_CHECK;
    Reset_Select_BB_Map(TEMP);

    // 5. From MAX to MIN (Descending order) ALL Blocks perform open block MLC Program - WL0. All Strings 0,1,2,3 with status check
    print(0, "STEP5: Descending MLC PRG\n");

    for(Loop = 0x0E; Loop >= 0; Loop -= 2)
    {
        blk_temp = ((TOTAL_BLK&0xFFF0)|Loop);
        if(blk_temp >= TOTAL_BLK)
        {
            blk_temp = blk_temp - 0x10;
        }
        FOR_EACH_LOOP_BACK(blk,blk_temp,-1,0x10)
        {
           adr.phy.blk=blk;
           // print(0," sweep down BLK@\n", adr.phy.blk);
           MLC_Program_6D_2A_1WL(adr, DONOT_SET_AB, MARKBB);
        }
    }
    GBB_Check(GBB_limit); 
    Reset_Select_BB_Map(TEMP);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    // 6. With default VDD, read ALL Blocks for WL0, All Strings with 90bit/1K bit ignore. Read is MONITOR only.

    print(0, "STEP6: MLC RD\n");
    FOR_EACH_LOOP(adr.phy.blk,0,TOTAL_BLK,TOTAL_PLN)
    {
        MLC_Read_6D_2A_1WL(adr,SET_AB,BIT_IGNORE_90);
    }

    GBB_MONITOR_PRINT;

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
