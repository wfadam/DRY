uint8 t_SCREEN_VFOUR_p2m2_scr2154p0(void)  //tb_425 nvcc SCR1226p2
{
    uint8 loop;

    Para_Table Para_Array[2][1] =
    {
        {0x067,	2,  PLUS|0x0F}, //VFOUR+2DAC
        {0x067, 2, MINUS|0x0F}, //VFOUR-2DAC
    };

    MLC_Margin_Erase();

    FOR_EACH_LOOP(loop, 0, 2, 1)
    {
        SET_PARAMETERS_ALL_DIE(Para_Array[loop]);

        Margin_Block_Check(BIT_IGNORE_110);

        RESET_PARAMETERS_ALL_DIE(Para_Array[loop]);
    }

    MLC_Margin_Erase();

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 4;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
