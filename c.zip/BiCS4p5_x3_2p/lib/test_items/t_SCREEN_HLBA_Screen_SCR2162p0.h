uint8 t_SCREEN_HLBA_Screen_SCR2162p0(void) //tb_835 lvcc SCR1181p0
{
    Para_Table Para_Array[] =
    {
        {0x0DE, 3, MINUS|0x1F}, //Set VDD to -3DAC
    };

    TM_Entry();

    SET_PARAMETERS_ALL_DIE(Para_Array);

    HLBA_Screen();

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    TM_Exit();

    return(PF_Check());
}
