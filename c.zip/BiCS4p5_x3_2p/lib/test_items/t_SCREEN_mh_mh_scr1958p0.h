uint8 t_SCREEN_mh_mh_scr1958p0(void) // tb__493 nvcc Base on SCR1359p3
{
    uint8 die;

    Para_Table Para_Array[] =
    {
        {0x103, 0x00, 0x20},    // 103h[5]=0 F_NEG_SLC=0 disable
        {0x0AB, 0x00, 0x07},    // ABh[1:0]=0 F_ZONESTEP=0 disable //ABh[3:2]=0 F_ZONESTEP_WL=0 disable
        {0x11B, 0x00, 0x01},    // 11Bh[0]=0 F_SGD_USEL_RD=0 VSS
        {0x104, 0x80, 0x80},    // 104h[0]=0 F_SGS_OFF=1 enable
    };

    FOR_EACH_DIE(die)
    {
        // Ignore bit come from xml file, please check with PE first before implement this item.
        SET_PARAMETERS(die, Para_Array);
        MH_MH_LEAK(die, IGN_BITS_MH_MH_LEAK);
        RESET_PARAMETERS(die, Para_Array);
    }


    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
