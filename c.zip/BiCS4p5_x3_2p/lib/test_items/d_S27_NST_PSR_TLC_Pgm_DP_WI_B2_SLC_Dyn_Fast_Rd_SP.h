uint8 d_S27_NST_PSR_TLC_Pgm_DP_WI_B2_SLC_Dyn_Fast_Rd_SP(void)
{
    uint8 die=0, i=0;
    uint16 Blk_Cnt=NST_BLK_CNT, N_Times=NST_SR_N_TIMES;    //N_Times should less than 384(TOTAL_PAGE)
    uint16 Blk_Start[3]={0,         BOT_BLK_EDGE, TOP_BLK_EDGE}; 
    uint16 Blk_Stop[3] ={TOTAL_BLK, TOTAL_BLK,    0};
    ADR_Init(adr);
    NST_Buffer_Init();

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(i, 0, NST_BLK_GROUP, 1)  //middle, bottom, top blk   
        {
            NST_Blk_Search(die, Blk_Start[i], Blk_Stop[i], Blk_Cnt);

            if(Is_Bad_Die(die, TEMP)==0)
            {
                NST_SLC_Pgm(die, g_SLC_Blk, SINGLE_PLN, CMD8B_DISABLE, TOTAL_PAGE, ERS_DISABLE);  //background condition
                NST_SLCR_Shift_Trim(die, DYNRD_ENABLE);
                NST_SLC_Dyn_Shift(die, DYNRD_ENABLE);

                FOR_EACH_LOOP(adr.phy.blk, g_TLC_Blk, g_TLC_Blk + Blk_Cnt, TOTAL_PLN)
                {
                    FOR_EACH_PAGE(adr)
                    {   
                        NST_TLC_Pgm_By_Page(die, adr, CMDB2_ENABLE, DUAL_PLN);
                        NST_SLC_Rd(die, g_SLC_Blk, SINGLE_PLN, DYNRD_ENABLE, FASTRD_ENABLE, N_Times);
                        NST_Poll_Status_71(die, adr.phy.blk, 0xE0);
                    }
                }
                NST_SLC_Dyn_Shift(die, DYNRD_DISABLE);
                NST_SLCR_Shift_Trim(die, DYNRD_DISABLE);
            }
        }
    }
    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
