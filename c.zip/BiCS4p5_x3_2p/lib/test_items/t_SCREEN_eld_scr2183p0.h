uint8 t_SCREEN_eld_scr2183p0(void)  //tb__489 nvcc
{
     Para_Table Para_Array[] =
    {
        {0x002, 0x80, 0xC0}, //set F_TESTTEMP = 2'b10
        {0x00E, 0x10, 0x10}, //0E[4]=1, ELD_N="1"
        {0x00E, 0xE0, 0xE0}, //0E[7:5]=1, ELD_TIME=25us
        {0x00C, 0x30, 0x30}, //0c[5:4]=1, ELD_CRI_U=+192DAC
        {0x00E, 0x0E, 0x0E}, //0E[3:1]="111", ELD_CRI=248DAC with ELD_CRI_U="11"
        {0x0AD, 0x08, 0x38}, //F_WLLD_CC_LDCLK = 0x08(40.96us)    //Parameter address change in BiCS4.5
        {0x011,    7, PLUS|0x3F}, //SDE = Default(71.6ns) + 7DAC = 80ns
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    Erase_LD(0, TOTAL_BLK);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE=50;
    GBB_limit.MarkBB=DONOT_MARKBB;

    GBB_Check(GBB_limit); 
    
    return(PF_Check());
}
