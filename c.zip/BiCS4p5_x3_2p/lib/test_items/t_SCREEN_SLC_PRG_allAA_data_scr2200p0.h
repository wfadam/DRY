uint8 t_SCREEN_SLC_PRG_allAA_data_scr2200p0(void) //tb_272_nvcc
{
    GBB_Check_Init(GBB_limit);

    Para_Table Para_Array[] =
    {
        {NLP_SLC_ADR, NLP_SLC_SET, NLP_SLC_MASK},
        {0x133, 0x00, 0x80}, // set ZBITSCAN_SLC = disable
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    SLC_Program_Pattern_2A(ALLAA, 0, TOTAL_BLK, MARKBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_limit.GBB_CHECK_PLN=20;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 

    return(PF_Check());
}
