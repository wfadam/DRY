uint8 t_SCREEN_PSR_TLC_suites_scr2246p0(void) //tb_760 nvcc SCR1182p0
{
    uint16 blk, SLC_B1, SLC_B2, SLC_B3, TLC_B1, TLC_B2;
    uint8 i, j, FailFlag = PASS;
    uint16 Vcc[2] = {NVCC, HVCC};

    Para_Table Para_Array[4][1] =
    {
        {0xDE, 2, MINUS|0x1F}, //VDD-2DAC
        {0xDE, 2,  PLUS|0x1F}, //VDD+2DAC
        {0x11, 2, MINUS|0x3F}, //SDE-2DAC
        {0x11, 2,  PLUS|0x3F}, //SDE+2DAC
    };

    Para_Table Para_Array1[2][3] =
    {
        {{0xDB, 2,  PLUS|0x0F}, {0x16, 2,  PLUS|0x1F}, {0x17, 2,  PLUS|0x1F}}, //VDDSA/VDDSA_P0/VDDSA_P1+2DAC
        {{0xDB, 2, MINUS|0x0F}, {0x16, 2, MINUS|0x1F}, {0x17, 2, MINUS|0x1F}}, //VDDSA/VDDSA_P0/VDDSA_P1-2DAC
    };

    g_BuFF_Prt = (uint8 *)SETBUF(0); //TLC Program Buffer
    Scramble_Random_Byte(MLC_SEED, 0, (TOTAL_COL + TOTAL_PAGE * OFFSET_ALIGN));

    g_BuFF_Prt = (uint8 *)SETBUF(2); //SLC Program Buffer
    Scramble_Random_Byte(SLC_SEED, 0, (TOTAL_COL + TOTAL_PAGE * OFFSET_ALIGN));

    g_BuFF_Prt = (uint8 *)SETBUF(0);

    SLC_B1 = Search_Pair_Blk_BBMap_AllDie(PSR_BLK_START_1, PSR_BLK_END_1, TOTAL_PLN, 1);
    SLC_B2 = Search_Pair_Blk_BBMap_AllDie(PSR_BLK_START_2, PSR_BLK_END_2, TOTAL_PLN, 1);
    SLC_B3 = Search_Pair_Blk_BBMap_AllDie(PSR_BLK_START_3, PSR_BLK_END_3, TOTAL_PLN, 1);
    TLC_B1 = Search_Pair_Blk_BBMap_AllDie(PSR_BLK_START_4, PSR_BLK_END_4, TOTAL_PLN, 1);
    TLC_B2 = Search_Pair_Blk_BBMap_AllDie(PSR_BLK_START_5, TOTAL_BLK, TOTAL_PLN, 4);

    SLC_Erase(SLC_B1, SLC_B1+1, DONOT_MARKBB);
    SLC_Erase(SLC_B2, SLC_B2+1, DONOT_MARKBB);
    SLC_Erase(SLC_B3, SLC_B3+1, DONOT_MARKBB);
    MLC_Erase(TLC_B1, TLC_B1+1, DONOT_MARKBB);
    MLC_Erase(TLC_B2, TLC_B2+BLK_CNT_8, DONOT_MARKBB);

    TM_Entry();

    FOR_EACH_LOOP(i, 0, 2, 1) //VCC Set
    {
        SetVcc(Vcc[i], 0, 0, 0);

        FOR_EACH_LOOP(j, 0, 4, 1)
        {
            SET_PARAMETERS_ALL_DIE(Para_Array[j]);

            if(PSR_Screen2(SLC_B1, SLC_B2, SLC_B3, TLC_B1, TLC_B2+j*2) != 0)
            {
                FailFlag |= FAIL;
                print(0, "BLK@ PSR1 fail VCC ~ loop ~\n", TLC_B2+j*2, Vcc[i], j);
            }

            RESET_PARAMETERS_ALL_DIE(Para_Array[j]);

            SLC_Erase(SLC_B1, SLC_B1+1, DONOT_MARKBB);
            SLC_Erase(SLC_B2, SLC_B2+1, DONOT_MARKBB);
            SLC_Erase(SLC_B3, SLC_B3+1, DONOT_MARKBB);
            MLC_Erase(TLC_B1, TLC_B1+1, DONOT_MARKBB);
            MLC_Erase(TLC_B2+j*2, TLC_B2+j*2+1, DONOT_MARKBB);

            if(FailFlag) break;
        }

        if(FailFlag) break;

        FOR_EACH_LOOP(j, 0, 2, 1)
        {
            FOR_EACH_LOOP(blk, TLC_B2, TLC_B2+BLK_CNT_8, TOTAL_PLN)
            {
                SET_PARAMETERS_ALL_DIE(Para_Array1[j]);

                if(PSR_Screen2(SLC_B1, SLC_B2, SLC_B3, TLC_B1, blk) != 0)
                {
                    FailFlag |= FAIL;
                    print(0, "BLK@ PSR2 fail VCC ~ loop ~\n", blk, Vcc[i], j);
                }

                RESET_PARAMETERS_ALL_DIE(Para_Array1[j]);

                SLC_Erase(SLC_B1, SLC_B1+1, DONOT_MARKBB);
                SLC_Erase(SLC_B2, SLC_B2+1, DONOT_MARKBB);
                SLC_Erase(SLC_B3, SLC_B3+1, DONOT_MARKBB);
                MLC_Erase(TLC_B1, TLC_B1+1, DONOT_MARKBB);
                MLC_Erase(blk, blk+1, DONOT_MARKBB);

                if(FailFlag) break;
            }

            if(FailFlag) break;
        }

        if(FailFlag) break;
    }

    TM_Exit();

    return(PF_Check());
}
