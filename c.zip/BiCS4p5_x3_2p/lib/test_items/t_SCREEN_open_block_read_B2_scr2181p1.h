uint8 t_SCREEN_open_block_read_B2_scr2181p1(void)  //tb_436 nvcc SCR2181p0
{
    uint8  die;
    uint16 ref_blk[TOTAL_DIE], new_ref_blk;

    g_CMDB2_FLAG = CMDB2_ENABLE;

    ADR_Init(adr);
    // 1. Temp para change VDD+4DAC , Move out in case return in the middle.

    Para_Table Para_Array[] =
    {
        {0x0DE, 4, PLUS|0x1F},
        {0x06B, 1, PLUS|0x1F},
        {0x0B9, 0x0F, 0x0F},
        {0x0F6, 0x0F, 0x0F},                
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    // 2. MLC Erase ALL Blocks with status check
    print(0, "STEP2: MLC ERS\n");

    MLC_Erase_2A(0, TOTAL_BLK, MARKBB);
    FULLARRAY_BB_CHECK;
    Reset_Select_BB_Map(TEMP);

    // 3/4/5. Do good block search for one pair good blocks per plane (start from 4/5)

    FOR_EACH_DIE(die)
    {
        ref_blk[die]=TOTAL_BLK;

        FOR_EACH_LOOP(adr.phy.blk, 4, TOTAL_BLK, TOTAL_PLN)
        {
            MLC_Program_6D_By_Die(die, adr.phy.blk, adr.phy.blk+1, MARKBB, DONOT_PRINT);
            MLC_Read_6D_2A_By_Die(die, adr.phy.blk, adr.phy.blk+1, MARKBB, BIT_IGNORE_90, SET_AB);
            
            if((Is_BB(die, adr.phy.blk, TEMP)==0) && (Is_BB(die, adr.phy.blk+1, TEMP)==0))
            {
                ref_blk[die]=adr.phy.blk;
                break;
            }
            else
            {
                MLC_Erase_By_Die(die, adr.phy.blk, adr.phy.blk+1, DONOT_MARKBB);
            }
        }

        Reset_Select_BB_Map(TEMP);

        if(ref_blk[die]==TOTAL_BLK)
        {
            Print_Die_Failure_Add_BD(die, "find GB");
        }
        else
        {
            print(0, "DIE@ GB@\n", die, ref_blk[die]);
            // 5/6/7. Program WL0 Str0 of each potential trigger block, then read ref block
            if(Open_BLK_TLC_Read_Screen(die, ref_blk[die], BIT_IGNORE_100) != 0)
            {
                BD_Add(die, TEMP); 
            }
        }
    }

    print(0, "STEP8: MLC ERS\n");
    MLC_Erase_2A(0, TOTAL_BLK, MARKBB);
    FULLARRAY_BB_CHECK;
    Reset_Select_BB_Map(TEMP);

    //Test reference EOC blocks as triggers.
    FOR_EACH_DIE(die)
    {
        new_ref_blk = TOTAL_BLK;

        FOR_EACH_LOOP(adr.phy.blk, ref_blk[die]+0x10, TOTAL_BLK, TOTAL_PLN)
        {
            MLC_Program_6D_By_Die(die, adr.phy.blk, adr.phy.blk+1, MARKBB, DONOT_PRINT);
            MLC_Read_6D_2A_By_Die(die, adr.phy.blk, adr.phy.blk+1, MARKBB, BIT_IGNORE_90, SET_AB);

            if((Is_BB(die, adr.phy.blk, TEMP)==0) && (Is_BB(die, adr.phy.blk+1, TEMP)==0)) //New reference block outside of original and reference EOC blk.
            {
                new_ref_blk = adr.phy.blk;
                break;
            }
            else
            {
                MLC_Erase_By_Die(die, adr.phy.blk, adr.phy.blk+1, DONOT_MARKBB);
            }
        }

        Reset_Select_BB_Map(TEMP);

        if(new_ref_blk==TOTAL_BLK)
        {
            Print_Die_Failure_Add_BD(die, "find new GB");
        }
        else
        {
            print(0, "D@ New GB@\n", die, new_ref_blk);
            //we need to test reference blocks and their shared EOC blocks as triggers.  So we choose new ref_blk that are outside EOC of original ref_blk and test original ref blocks and EOC as triggers (repeating steps 4-6)
            if(Open_BLK_TLC_Read_Screen_EOC(die, ref_blk[die], new_ref_blk, 100) != 0)
            {
                BD_Add(die, TEMP);
            }
        }
    }

    print(0, "STEP9: MLC ERS\n");
    MLC_Erase_2A(0, TOTAL_BLK, MARKBB);
    FULLARRAY_BB_CHECK;
    Reset_Select_BB_Map(TEMP);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
