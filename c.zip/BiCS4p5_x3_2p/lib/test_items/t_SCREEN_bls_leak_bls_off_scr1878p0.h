uint8 t_SCREEN_bls_leak_bls_off_scr1878p0(void)//tb__168 nvcc
{
    uint8 die;
    uint16 good_blk;
    uint8 TEST1_CMD[]={0x1E};
    uint8 TEST2_CMD[]={0x1E, 0xB8};
    uint8 TEST3_CMD[]={0x1E, 0xB8};

    Para_Table Para_Array_TSB[] =
    {
        {0x103, 0x00, 0x20},        //F_NEG_SLC=0
        {0x0AB, 0x00, 0x07},        //F_ZONESTEP=0, F_ZONESTEP_WL=0
        {0x06C, 0x0A, 0x0F},         //F_VBLC_PVFY_SLC=0.5V      // CLAMP voltage
        {0x06B, 0x10, 0x1F},         //F_VBLC_PVFY_MLC =0.4V     // SEN Voltage
        {0x093, 0x1F, 0x1F},         //F_R5_READ_SLC =42.32us    // RP7 Timer
        {0x091, 0x06, 0x1F},         //F_R5_READ_LP=18us         
        {0x010, 0x00, 0x02},         //F_CRD_EN=disable
        {0x113, 0x00, 0x0c},        //SV_MANUAL_MLC/SV_AUTO_MLC=0   
        {0x120, 0x00, 0x30},        //F_LAY_READ_EN=disable in TSB mode 
    };

    Para_Table Para_Array_ABL[] =
    {
        {0x103, 0x00, 0x20},        //F_NEG_SLC=0
        {0x0AB, 0x00, 0x07},        //F_ZONESTEP=0, F_ZONESTEP_WL=0
        {0x06C, 0x0A, 0x0F},         //F_VBLC_PVFY_SLC=0.5V      // CLAMP voltage
        {0x06B, 0x10, 0x1F},         //F_VBLC_PVFY_MLC =0.4V     // SEN Voltage
        {0x093, 0x1F, 0x1F},         //F_R5_READ_SLC =42.32us    // RP7 Timer
        {0x091, 0x16, 0x1F},         //F_R5_READ_LP=16.72us      // SP2 Timer
        {0x010, 0x00, 0x02},         //F_CRD_EN=disable
        {0x113, 0x00, 0x0c},        //SV_MANUAL_MLC/SV_AUTO_MLC=0   
        {0x120, 0x10, 0x30},        //F_LAY_READ_EN=enable in ABL mode 
    };

    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_by_Die(die, 0, TOTAL_BLK, TOTAL_PLN, PAIR_1);

        if(good_blk != TOTAL_BLK)
        {

            Reset_Temp_BC_Array();
            Reset_BC(die);

            SET_PARAMETERS(die, Para_Array_TSB);
            BL_Leak_Sensing(die, good_blk, TSB_SENSE, USE_2A, ODD_ENABLE, TEST1_CMD, sizeof(TEST1_CMD)/sizeof(uint8),  BIT_IGNORE_0, IO_0);
            BL_Leak_Sensing(die, good_blk, TSB_SENSE, USE_2A, ODD_ENABLE, TEST2_CMD, sizeof(TEST2_CMD)/sizeof(uint8),  BIT_IGNORE_0, IO_1);
            RESET_PARAMETERS(die, Para_Array_TSB);

            SET_PARAMETERS(die, Para_Array_ABL);
            BL_Leak_Sensing(die, good_blk, ABL_SENSE, USE_2A, ODD_DISABLE, TEST3_CMD, sizeof(TEST3_CMD)/sizeof(uint8),  BIT_IGNORE_0, IO_2);
            RESET_PARAMETERS(die, Para_Array_ABL);

            if(BL_Leak_Result(0x06, BC_IGNORE_0)!=0)//Fail die with any COMMON BAD COL increase at Test2 AND Test3 AND (NOT Test1)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }

    }

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
