uint8 t_SCREEN_byte_skip_scr2142p1(void) //tb__212 nvcc Base on SCR2142.0
{
    uint8 die = 0;

    FOR_EACH_DIE(die)
    {
        if(Byte_Skip_Screen_BC_Data_Parity(die) != 0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());

}
