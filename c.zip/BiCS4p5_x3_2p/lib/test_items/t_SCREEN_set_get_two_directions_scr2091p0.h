uint8 t_SCREEN_set_get_two_directions_scr2091p0(void) //tb_746 nvcc SCR1289p2
{
    uint8 die;
    uint8  Default_Addr[24] = {0x02, 0x10, 0x20, 0x30, 0x80, 0x83, 0x84, 0x90, 0x91, 0xC0, 0x85, 0x86, 0x87, 0x8C, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0x9B}; //BiCS4.5 no Feature 0xF0
    uint32 Default_Value[24] = {0, 0x00000004, 0x00040000, 0, 0x00000001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    FOR_EACH_DIE(die)
    {
        if(Set_Get_Feature_Two_Direction(die, Default_Addr, Default_Value) != 0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
