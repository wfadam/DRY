uint8 t_Data_Path_Stress_SCR2122p1(void)//tb__9999 nvcc
{   
    Para_Table Para_Array[] =
    {
        {0x0DE, 0x1B, 0x1F}, //F_VDD = 2.55V Change address to B4.5
        {0x0DB, 0x0E, 0x0F}, //F_VDDA = 3.4V Change address to B4.5
        {0x016, 0x1A, 0x1F}, //F_VDDSA_PB0 = 3.4V Change address to B4.5
        {0x017, 0x1A, 0x1F}, //F_VDDSA_PB1 = 3.4V Change address to B4.5
    };

    if(Stamp_Exist_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, 0x1208, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
    {
        Data_Path_Stress_14Pat(1000, Para_Array, sizeof(Para_Array)/sizeof(Para_Table));

        Program_Stamp_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, 0x1208, BYTE_8);

        if(Stamp_Exist_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, 0x1208, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
        {
            Print_Die_Failure(0, "RD stamp");
            Mark_All_Die_Bad(TEMP);
        }	
    }
    else 
    {
        print(0, "Has Stamp,skip\n");  
        Dummy_Wait(WAIT_DATA_PATH);
    }	   

    return(PF_Check());
}
