uint8 t_MLC_RD_ERS_scr1932p0(void)//tb__394 nvcc
{
    uint16 blk = 0;

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {0x0AB, 0x08, 0x08}, //enable ocs6D to enable every string have different random data in same wl.
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    for(blk = 0; blk < TOTAL_BLK; blk+=TOTAL_PLN)
    {
        MLC_Read_6D_2A(blk, blk+1, MARKBB, IGN_BITS_MLC, DONOT_SET_AB);//0xAB set outside for TTR
        MLC_Erase(blk, blk+1, MARKBB);
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;
    
    return(PF_Check());
}
