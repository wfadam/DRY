uint8 t_SCREEN_gbc_scr2444p0(void) //tb_170 nvcc SCR2066p0
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        Scan_BC_To_Select_Array(die, g_Outgoing_BC, PSTBCMASK, GBC_PRINT);
    }

    if(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, MTST_STAMP_WL, MTST_STAMP_STR, GBC_FAIL_COL_SH, BIT_IGNORE_16, 0xAA, 16)==DONOT_EXIST)
    {
        BC_Limit_Check(BC_LIMIT_PER_PLN, GBC_LIMIT_PER_PLN_SH, g_Incoming_BC_Cnt, g_Outgoing_BC);
        
            FOR_EACH_DIE(die)
            {
                if(Is_Bad_Die(die, TEMP) != 0) // scan fail bad die from  bc_limit_check.
                {
                    Program_UR_Stamp_4C(0, MTST_UROM_BLK0, MTST_STAMP_WL, MTST_STAMP_STR, GBC_FAIL_COL_SH, PARAM_COUNT_16);

                    if(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, MTST_STAMP_WL, MTST_STAMP_STR, GBC_FAIL_COL_SH, BIT_IGNORE_16, 0xAA, 16)==DONOT_EXIST)
                    {
                        Print_Die_Failure(0,"RD stamp");
                        Mark_All_Die_Bad(TEMP);
                    }
                    break;
                }
            }
    }

    else
    {
        Mark_All_Die_Bad(TEMP);
        PrtLog(0,"Has fail stamp\n");
    }

    return(PF_Check());
}
