uint8 t_SCREEN_block_addressing_scr2048p1(void) //tb__674__ nvcc
{
    uint16 GB1, GB2, blk;
    uint8 die=0, IO_Index;
#ifdef DENS_256_SW
    uint16 IO_Mask[11] = {0x001,0x002,0x004,0x008,0x010,0x020,0x040,0x080,0x100,0x200,0x400};
    uint8 Array_size = 11;
#endif
#ifdef DENS_512_SW
    uint16 IO_Mask[12] = {0x001,0x002,0x004,0x008,0x010,0x020,0x040,0x080,0x100,0x200,0x400,0x800};
    uint8 Array_size = 12;
#endif	


    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(IO_Index,0,Array_size,1)
        {
            FOR_EACH_LOOP(blk,0,TOTAL_BLK,1)
            {
                GB1 = blk;
                GB2 = (blk^IO_Mask[IO_Index]);
                if((Is_BB(die, GB1, MAIN)==0) && (Is_BB(die, GB2, MAIN)==0))
                {
                    print(0, "D@ IO~:@ @\n", die, IO_Index, GB1, GB2);
                    SLC_Erase_SP_by_Die(die, GB1, GB1+1, DONOT_MARKBB);
                    SLC_Erase_SP_by_Die(die, GB2, GB2+1, DONOT_MARKBB);
                    if(SLC_ALL00_Program_SP_By_DIE(die, GB1, GB1+1) != 0){Print_Die_Failure_Add_BD(die, "PGM1");}
                    if(SLC_Read_Pattern_SP_By_DIE(die, GB2, GB2+1, ALLFF, 110) != 0){Print_Die_Failure_Add_BD(die, "RD1");}
                    SLC_Erase_SP_by_Die(die, GB1, GB1+1, DONOT_MARKBB);
                    if(SLC_ALL00_Program_SP_By_DIE(die, GB2, GB2+1) != 0){Print_Die_Failure_Add_BD(die, "PGM2");}
                    if(SLC_Read_Pattern_SP_By_DIE(die, GB1, GB1+1, ALLFF, 110) != 0){Print_Die_Failure_Add_BD(die, "RD2");}
                    SLC_Erase_SP_by_Die(die, GB2, GB2+1, DONOT_MARKBB);
                    break;
                }
            }	
        }
    }
    Reset_Select_BB_Map(TEMP);
    return(PF_Check());
}			
