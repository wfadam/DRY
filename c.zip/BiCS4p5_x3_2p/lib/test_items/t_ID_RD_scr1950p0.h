uint8 t_ID_RD_scr1950p0(void)//tb__124 hvcc tb__125 nvcc
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Read_ID_5bytes(die)!=PASS)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}
