uint8 t_SCREEN_bb_latch_set_vddvdda_plus2_scr2098p1(void) //tb_673_nvcc
{
    uint8 die;

     Para_Table Para_Array[] =
    {
        {0x011, 6, MINUS|0x3F},
        {0x0DE, 2, PLUS|0x1F},
        {0x0DB, 2, PLUS|0x0F},
    };
    

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);

        Reset_Swap_Bit(die);

        if(BB_LATCH_SET_SHIFT(die,0,BLK0_1)!=0)
        {
            Print_Die_Failure_Add_BD(die, "BB_LATCH_SET_SHIFT_PLUS2");
        }

        RESET_PARAMETERS(die, Para_Array);

        POR_One_Die(die);
    }

    return(PF_Check());
}
