uint8 d_S45_NST_AIPR_TLC_L_SLC(void)
{
    uint8 die=0, i=0, pln;
    uint16 Blk_Cnt=NST_BLK_CNT, blk, blk_2, blk_loop, page; 
    uint16 readtime[2]={NST_AIPR_SENSE_TIME_TLC_L, NST_AIPR_SENSE_TIME_SLC}, dly=0;
    uint16 Blk_Start[3]={0,            BOT_BLK_EDGE, TOP_BLK_EDGE}; 
    uint16 Blk_Stop[3] ={TOP_BLK_EDGE, TOTAL_BLK,    0};
    ADR_Init(adr);
    NST_Buffer_Init();

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(i, 0, NST_BLK_GROUP, 1)  //middle, bottom, top blk   
        {
            NST_Blk_Search_Group(die, Blk_Start[i], Blk_Stop[i], Blk_Cnt, i);
        }

        if(Is_Bad_Die(die, TEMP)==0)
        { 
            FOR_EACH_LOOP(i, 0, NST_BLK_GROUP, 1)  //p0-middle, p1-bottom; p0-bottom, p1-top; p0-top blk, p1-middle   
            {
                g_Print_Cnt=0;

                FOR_EACH_LOOP(blk_loop, 0, Blk_Cnt, TOTAL_PLN)
                {
                    blk   = g_TLC_Blk_G[i] + blk_loop;
                    if(i==NST_BLK_GROUP-1) blk_2 = g_SLC_Blk_G[0]  + blk_loop;
                    else                   blk_2 = g_SLC_Blk_G[i+1]+ blk_loop;

                    //print(0, "i~, blk @, blk_2 @\n", i, blk, blk_2);

                    NST_Pgm_Buf_Input(die, blk,   TLC, DUAL_PLN, 0);  //background condition
                    NST_Pgm_Buf_Input(die, blk_2, SLC, DUAL_PLN, 1);  //background condition

                    AIPR_Option_D5(die, AIPR_ENABLE);

                    CMDFxPointer(die);

                    FOR_EACH_PLN(pln)   //pln0-pln1, pln1-pln0
                    {
                        FOR_EACH_LOOP(page, 0, TOTAL_PGE, 1) 
                        {   
                            dly = page%readtime[pln];
                            adr.phy.blk=blk;
                            PAGE_TO_WLSTR(page);
                            NST_AIPR_Single_Page(die, adr, pln, LOWER, dly, CACHE_DISABLE, DYNRD_DISABLE, FASTRD_DISABLE, 0xE0);

                            adr.phy.blk=blk_2;
                            PAGE_TO_WLSTR(TOTAL_PAGE-1-page);
                            NST_AIPR_Single_Page(die, adr, (1-pln), SLC_CMD, USE_RB, CACHE_DISABLE, DYNRD_DISABLE, FASTRD_DISABLE, 0xE0);

                            adr.phy.blk=blk;
                            PAGE_TO_WLSTR(page);  
                            NST_RDCompare_Buf_Input_Dly(die, adr, pln, LOWER, dly, DYNRD_DISABLE, IGN_BITS_MLC, 0, 0xE0);  //normal read  poll E0 status

                            adr.phy.blk=blk_2;
                            PAGE_TO_WLSTR(TOTAL_PAGE-1-page);
                            NST_RDCompare_Buf_Input_Dly(die, adr, (1-pln), SLC, dly, DYNRD_DISABLE, IGN_BITS_SLC, 1, 0xE0);
                        }
                    }
                    AIPR_Option_D5(die, AIPR_DISABLE);
                }
            }
        }
    }
    GBB_MONITOR_PRINT;
    return(PF_Monitor());
}
