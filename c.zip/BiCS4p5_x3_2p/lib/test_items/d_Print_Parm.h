uint8 d_Print_Parm()
{
	if 	(g_Incoming_Para_Scan_En == 1)
	{
		Print_Param();	
	}
	else
    {
    	ERROR_FLAG=FAIL;
		print(0,"Not scan parm!\n");
    }

	return(PF_Monitor());
}
