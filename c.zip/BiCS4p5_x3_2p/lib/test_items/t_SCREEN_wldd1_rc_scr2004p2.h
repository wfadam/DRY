uint8 t_SCREEN_wldd1_rc_scr2004p2(void) //tb__533 nvcc
{
    Para_Table Para_Array[] =
    {
        {0x103, 0x00, 0x10}, // LVSTAGEFLG = Disable 
        {0x002, 0x40, 0xC0}, // F_TESTTEMP = 2'b01
        {0x00E, 0x20, 0xFF}, // F_RC_MEAS = 1/F_RC_MON = 0 (t1 Meas) 
        {0x12E, 0x20, 0x20}, // F_SDE_2X_TEST = 1(SCAN_SLOW=1)   
        {0x00A, 0x00, 0xFF}, // Upper Criteria MSB=0 & Lower Criteria MSB=0
        {0x00B, 0x0A, 0xFF}, // Lower Criteria=10.
        {0x00C, 0x50, 0xFF}, // Upper Criteria=80. 
    };
    SET_PARAMETERS_ALL_DIE(Para_Array);
    WLRC_Check_WL_Option(WLDD1, DLY_400);

    RESET_PARAMETERS_ALL_DIE(Para_Array);
    FULLARRAY_BB_CHECK;
    return(PF_Check());
}
