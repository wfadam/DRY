uint8 t_SCREEN_bl_bli_scr1874p3(void) //tb_164 nvcc SCR1874p3
{
    uint8 die;
    uint16 good_blk;
    uint8 TEST1_CMD[]={0x1E, 0xB4, 0xB8};
    uint8 TEST2_CMD[]={0x0E, 0xB4, 0xB8, 0x4E};

    Para_Table Para_Array[] =
    {
        {0x103, 0x00, 0x20},     //F_NEG_SLC=0
        {0x0AB, 0x00, 0x07},     //F_ZONESTEP=0, F_ZONESTEP_WL=0
        {0x00D, 0x08, 0x08},     // BLI_TEST =1
        {0x00C, 0x00, 0xFF},     // r10 timer = TEMPPARA9x320ns +80ns // Monitor condition - 1x320ns +80ns = 400ns
    };

    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_by_Die(die, 0, TOTAL_BLK, TOTAL_PLN, PAIR_1);

        if(good_blk != TOTAL_BLK)
        {

            Reset_Temp_BC_Array();
            Reset_BC(die);

            SET_PARAMETERS(die, Para_Array);

            BL_Leak_Sensing(die, good_blk, ABL_SENSE, USE_2A, ODD_DISABLE, TEST1_CMD, sizeof(TEST1_CMD)/sizeof(uint8),  BIT_IGNORE_1, IO_0);
            BL_Leak_Sensing(die, good_blk, ABL_SENSE, USE_2A, ODD_DISABLE, TEST2_CMD, sizeof(TEST2_CMD)/sizeof(uint8),  BIT_IGNORE_1, IO_1);

            RESET_PARAMETERS(die, Para_Array);

            if(BL_Leak_Result(0x02, BC_IGNORE_0)!=0)//0x02 means IO1 has been set only, reject the col which failed 2nd test but pass 1st test
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }
    }

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
