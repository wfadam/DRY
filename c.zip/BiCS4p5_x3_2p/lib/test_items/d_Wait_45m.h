uint8 d_Wait_45m()
{
    return(Wait_Start_Signal(45));
}