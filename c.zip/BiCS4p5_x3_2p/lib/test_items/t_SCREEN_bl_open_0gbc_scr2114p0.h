uint8 t_SCREEN_bl_open_0gbc_scr2114p0(void) //tb_173 nvcc SCR903p1
{
    uint8 die;
    uint16 Good_Blk;

    FOR_EACH_DIE(die)
    {
        Good_Blk = Search_Pair_Blk_BBMap_Erase_by_Die(die, TOP_BLK_EDGE, 0, 16, PAIR_4, MLC_ERASE);

        if(Good_Blk != TOTAL_BLK)
        {
            if(Bitline_Open_All_One_Detect(die, Good_Blk) != 0)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }
    }

    return(PF_Check());
}
