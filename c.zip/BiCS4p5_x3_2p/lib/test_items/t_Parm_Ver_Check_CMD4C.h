uint8 t_Parm_Ver_Check_CMD4C(void)
{
    if(Parm_Ver_Check_CMD4C() != 0)
    {
        Mark_All_Die_Bad(TEMP);
    }

    return(PF_Check());
}
