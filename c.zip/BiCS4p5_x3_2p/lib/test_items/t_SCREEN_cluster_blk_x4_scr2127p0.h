uint8 t_SCREEN_cluster_blk_x4_scr2127p0(void)//tb__953 nvcc SCR866p1
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Cluster_BB_Count_PHY(die, 4, CLUSTER_LIMIT_35))
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}
