uint8 d_MONITOR_vsgd_highVT_scr1995p2(void) //tb_646 nvcc SCR1848p3
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB

    Reset_All_BBlk();

    VSGS_VSGD_Detection_2A(SGD, HIGH_VT, 3000, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E);  //VCGRV = 3.0V

    GBB_MONITOR_PRINT;

    POR_CHECK_ALL_DIE;

    return(PF_Monitor());
}
