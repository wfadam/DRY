uint8 t_SCREEN_POR_margin_emulation_scr2259p0(void) //tb_238_nvcc
{
    uint8 die = 0;

    FOR_EACH_DIE(die)
    {
        if(POR_Margin_Emulation(die, 0x0A, 0x0B, 0x1A, 0x1C, CYCLE_20) != PASS) 
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }	
    
    return(PF_Check());
}
