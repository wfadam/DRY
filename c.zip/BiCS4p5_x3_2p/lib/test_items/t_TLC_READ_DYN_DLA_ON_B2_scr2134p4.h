uint8 t_TLC_READ_DYN_DLA_ON_B2_scr2134p4(void) //tb_739 nvcc
{
    uint8 die, FailFlag = PASS;
    uint16 GoodBlk;

    g_CMDB2_FLAG = CMDB2_ENABLE;

    Para_Table Para_Array[] =
    {
        {0x0AB,  0x08,   0x08},  //Enable OSC6D to enable every string have different random data in same wl.
        {0x0DE, 2, MINUS|0x1F},  //VDD-2DAC
    };

    Para_Table Para_Array1[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
    };

    GoodBlk = Search_Pair_Blk_BBMap_AllDie(0, TOTAL_BLK, TOTAL_PLN, PAIR_1);

    if(GoodBlk != TOTAL_BLK)
    {
        
        SET_PARAMETERS_ALL_DIE(Para_Array1);
        MLC_Erase(GoodBlk, GoodBlk+2, DONOT_MARKBB);
        RESET_PARAMETERS_ALL_DIE(Para_Array1);
        
        MLC_Program_6DBB(GoodBlk, GoodBlk+2, DONOT_MARKBB, SET_AB);

        FOR_EACH_DIE(die)
        {
            FailFlag = PASS;

            SET_PARAMETERS(die, Para_Array);

            FailFlag |= TLC_DLA_AIRP_Read_6DBB_SP_By_Die(die, GoodBlk, DLY_300, BIT_IGNORE_75);
            FailFlag |= TLC_DLA_AIRP_Read_6DBB_SP_By_Die(die, GoodBlk+1, DLY_300, BIT_IGNORE_75);
            FailFlag |= TLC_DLA_AIPR_Read_6DBB_By_Die(die, GoodBlk, GoodBlk+1, DLY_300, BIT_IGNORE_75);
            FailFlag |= TLC_DLA_AIPR_Read_6DBB_By_Die(die, GoodBlk+1, GoodBlk, DLY_300, BIT_IGNORE_75);
            FailFlag |= TLC_DLA_AIPR_Cache_Read_By_Die(die, GoodBlk, GoodBlk+1, DLY_300);
            FailFlag |= TLC_DLA_AIPR_DYN_Read_6DBB_By_Die(die, GoodBlk, GoodBlk+1, DLY_300, BIT_IGNORE_75);
            
            RESET_PARAMETERS(die, Para_Array);

            if(FailFlag) BD_Add(die, TEMP);
        }
    }

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
