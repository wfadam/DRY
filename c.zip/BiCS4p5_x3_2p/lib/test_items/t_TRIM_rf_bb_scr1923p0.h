uint8 t_TRIM_rf_bb_scr1923p0(void)  //tb_940_nvcc
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        Add_BB_to_REG(die);
    }

    ROMBLOCK_UPDATE;

    return(PF_Check());
}
