uint8 t_SCREEN_Combo_LD_scr2386p0(void) //tb_397 nvcc
{

    uint8 die;
    uint16 blk, i;

    uint8 p46_sgs[TOTAL_DIE], p46_sgsb[TOTAL_DIE], p46_wlld[TOTAL_DIE];

    // get the parameter addr_0x46
    FOR_EACH_DIE(die)
    {
        p46_sgs[die]  = DS_CHIP_ID_read_majority_vote(die, BLK1, 13, 2, 0x260, 0x46, 40, -50, -60);
        p46_sgsb[die] = DS_CHIP_ID_read_majority_vote(die, BLK1, 13, 2, 0x260, 0x46, 40, -20, -30);
        p46_wlld[die] = DS_CHIP_ID_read_majority_vote(die, BLK1, 13, 2, 0x260, 0x46, 40, -40, -50);
    }

#if(TOTAL_DIE > 8)
    uint16 *g_BuFF_BB = (uint16 *)SETBUF(0);
#else
    uint8 *g_BuFF_BB = (uint8 *)SETBUF(0);
#endif

    FOR_EACH_LOOP(i, 0, TOTAL_COL, 1)
    {
        *(g_BuFF_BB + i) = 0;
    }

    Reset_All_BBlk();
    Set_Datalog_Block_as_BB(); // prevent datalog block erased by below MLC_erase

    /////////////////////////////////// scr1876p1 :sgs_ld /////////////////////////////////////////////


    // clear TEMP AND SUBBB
    Reset_Select_BB_Map(TEMP);
    Reset_Select_BB_Map(SUBBB);

    Set_Reset_Param_sgs_scr2386p1(TEMP_PARM_SET, p46_sgs);
    SGS_SGD_Leakage(SGS_LEAK, DUAL_PLN);
    Set_Reset_Param_sgs_scr2386p1(TEMP_PARM_RESET, p46_sgs);

    FOR_EACH_LOOP(blk, 0, TOTAL_BLK, 1)
    {
        g_BuFF_BB[blk] = BBlk_Map_Temp[blk]; 			//Move Test1 GBB to Buf1
    }

    ///////////////////////////////////// scr2017p0 :sgsb_ld ////////////////////////////////////////////
    Reset_Select_BB_Map(TEMP);

    Set_Reset_Param_sgsb_scr2386p1(TEMP_PARM_SET, p46_sgsb);
    SGSB_LD_SIN();
    Set_Reset_Param_sgsb_scr2386p1(TEMP_PARM_RESET, p46_sgsb);

    FOR_EACH_LOOP(blk, 0, TOTAL_BLK, 1)
    {
        g_BuFF_BB[blk+TOTAL_BLK] = BBlk_Map_Temp[blk]; 	//Move Test2 GBB to Buf2
    }

    ///////////////////////////////////// scr1871p1 :wlld_wDummy ////////////////////////////////////////

    Reset_Select_BB_Map(TEMP);

    Set_Reset_Param_wlld_scr2386p1(TEMP_PARM_SET, p46_wlld);
    WL_WL_Leakage_Dummy_Read(USE_DD, EVEN_ODD_WL);
    Set_Reset_Param_wlld_scr2386p1(TEMP_PARM_RESET, p46_wlld);

    Add_Map1_to_Map2(TEMP, SUBBB); 						//Move Test3 GBB to SUBBB

    Reset_Select_BB_Map(TEMP);

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(blk, 0, TOTAL_BLK, 1)
        {
            if( Is_BB(die, blk, SUBBB) && (g_BuFF_BB[blk]&(1<<die)) || Is_BB(die, blk, SUBBB) && (g_BuFF_BB[blk+TOTAL_BLK]&(1<<die)) || (g_BuFF_BB[blk]&(1<<die)) && (g_BuFF_BB[blk+TOTAL_BLK]&(1<<die)) || Is_BB(die, blk, SUBBB) && (g_BuFF_BB[blk]&(1<<die)) && (g_BuFF_BB[blk+TOTAL_BLK]&(1<<die)) )
            {
                BB_Add(die, blk, TEMP); 				//Move common BB to TEMP and do EOC check
            }
        }
    }

    BB_Check_EOC(0, TOTAL_BLK, 4, 5, TEMP);  			//mark all block in EOC scheme as BB

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(blk, 0, TOTAL_BLK, 1)
        {
            if( Is_BB(die, blk, SUBBB) || (g_BuFF_BB[blk]&(1<<die)) || (g_BuFF_BB[blk+TOTAL_BLK]&(1<<die)) )
            {
                BB_Add(die, blk, TEMP); 				//Add uncommon BB to TEMP
            }
        }
    }

    Reset_Select_BB_Map(SUBBB);

    FULLARRAY_BB_CHECK;

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
