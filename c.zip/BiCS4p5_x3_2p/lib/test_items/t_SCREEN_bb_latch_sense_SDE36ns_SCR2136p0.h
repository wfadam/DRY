uint8 t_SCREEN_bb_latch_sense_SDE36ns_SCR2136p0() //tb672 scr900p0 nvcc
{
    uint8 die=0;

    Para_Table Para_Array[] =
    {
        {0x11, 6, MINUS|0x3F},
    };

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);
        if(BB_LATCH_Delay_Shmoo(die)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
        RESET_PARAMETERS(die, Para_Array);        
    }

    return(PF_Check());
}
