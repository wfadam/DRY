uint8 t_SCREEN_enh_apple_efr_openblk_B2_scr2303p2(void) //tb_761 nvcc SCR2303p0
{
    uint8 die, i, j;
    uint16 blk;
    uint16 start_blk[3] = {MARGIN_G1_START, MARGIN_G0_START, MARGIN_G2_START};
    uint8 rand_key[8] = {0, 4, 8, 2, 6, 10, 14, 12};

    g_CMDB2_FLAG = CMDB2_ENABLE;

    FOR_EACH_LOOP(i, 0, 3, 1)
    {
        FOR_EACH_LOOP(blk, start_blk[i], start_blk[i]+16, TOTAL_PLN)
        {
            FOR_EACH_DIE(die)
            {
                MLC_Erase_By_Die(die, blk, blk+2, DONOT_MARKBB);
                MLC_Program_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, WL0, WL1); //PGM WL0
                MLC_Read_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, WL0, WL1, BIT_IGNORE_110); //RD WL0

                POR_One_Die(die);

                MLC_Read_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, WL0, WL1, BIT_IGNORE_110); //RD WL0 again
                MLC_Program_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, WL1, WL24); //PGM WL1 ~ WL23
                MLC_Read_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, WL1, WL24, BIT_IGNORE_110); //RD WL1 ~ WL23
                MLC_Program_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, WL24, WL48); //PGM WL24 ~ WL47
                MLC_Read_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, WL47, WL24, BIT_IGNORE_110); //RD WL47 ~ WL24

                POR_One_Die(die);

                MLC_Program_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, WL48, TOTAL_WL-1); //PGM WL48 ~ WL94
                MLC_Read_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, WL0, TOTAL_WL-1, BIT_IGNORE_110); //RD WL0 ~ WL94
                MLC_Program_6D_2A_By_Die_WL(die, blk, blk+2, SET_AB, MARKBB, TOTAL_WL-1, TOTAL_WL); //PGM WL95
            }
        }

        //Random Read for 48 margin blocks
        FOR_EACH_LOOP(j, 0, 8, 1)
        {
            MLC_Read_6D_2A(start_blk[i]+rand_key[j], start_blk[i]+rand_key[j]+2, MARKBB, BIT_IGNORE_110, SET_AB); //Read block in random orders
            MLC_Erase(start_blk[i]+rand_key[j], start_blk[i]+rand_key[j]+2, DONOT_MARKBB);
        }
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN=3;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
