uint8 t_MLC_RD_dummy_scr2394p0_100Cycle(void) //tb_410 nvcc
{
    uint8 loop;

    FOR_EACH_LOOP(loop, 0, 10, 1)
    {
        if(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, EFR_RE_CYCLE_STAMP_WL, EFR_CYCLE_STAMP_STR, EFR_RE_CYCLE_STAMP_COL+loop*BYTE_8, BIT_IGNORE_10, 0xAA, BYTE_8) == DONOT_EXIST)
        {
            MLC_Dummy_Read_6E(10);

            Program_UR_Stamp_4C(0, MTST_UROM_BLK0, EFR_RE_CYCLE_STAMP_WL, EFR_CYCLE_STAMP_STR, EFR_RE_CYCLE_STAMP_COL+loop*BYTE_8, BYTE_8);

            if(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, EFR_RE_CYCLE_STAMP_WL, EFR_CYCLE_STAMP_STR, EFR_RE_CYCLE_STAMP_COL+loop*BYTE_8, BIT_IGNORE_10, 0xAA, BYTE_8) == DONOT_EXIST)
            {
                print(0, "~ cycle read stamp fail\n", loop*10);
                BD_Add(0, TEMP);
            }
        }
        else
        {
            print(0, "~ cycle stamp exists, skip\n", loop*10);
        }
    }

    return(PF_Check());
}
