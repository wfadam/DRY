uint8 t_MLC_ERS_scr1843p0(void)//tb__360-362 nvcc
{
	Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Erase(0, TOTAL_BLK, MARKBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
