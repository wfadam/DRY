uint8 t_SCREEN_tlc_combos2e_scr2220p3(void) //tb_525 nvcc
{
    Para_Table Para_Array[] =
    {   
        {0x137, 0x01, 0x07}, //BSPF_EV_SLC[2:0] = 8 bits
        {0x12F, 0x06, 0x0F}, //NLE_MLC[3:0] = 6 loops (default = 6 loops)
        {0x133, 0x00, 0x20}, //ZBITSCAN_EVFY_MLC=Disable
        {0x134, 0x00, 0x30}, //SKIPEVFY_MLC=0 loop
        {0x05A, 0x40, 0xC0}, //DVERA_MLC=0.2V 
        {0x117, 0x00, 0x04}, //All WL EVFYMLC enabled
        {0x026, 5,    PLUS|0x1F}, // VCG_ERV=+5 DAC
        {0x041, 4,    PLUS|0x7F}, // VERA_MLC=+0.8V DAC

    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Erase_SP(0, TOTAL_BLK, MARKBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 29; //If 30 or more GBB per plane, reject the die
    GBB_limit.MarkBB = MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
