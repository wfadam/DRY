uint8 t_MLC_ERS_PRG_aipr_b2_scr2230p4(void)//tb__303 hvcc SCR2230p1
{
    uint16 blk = 0;
    g_CMDB2_FLAG = CMDB2_ENABLE;

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {0x137,       BSPF_EV_MLC_SET, BSPF_EV_MLC_MASK},
        {NLP_MLC_ADR, NLP_MLC_SET, NLP_MLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    FOR_EACH_LOOP(blk, 0, TOTAL_BLK, TOTAL_PLN)
    {
        if((THROTTLE_PRODUCT == THROTTLE)&&((blk%0x80)==0))
        {
            print(0,"BLK@:", blk);
            Cool_temp(90, 1);
        }

        MLC_Erase(blk, blk+1, MARKBB);
        MLC_Program_6EBB(blk, blk+1, MARKBB);
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    g_CMDB2_FLAG = CMDB2_DISABLE;
    
    return(PF_Check());
}

