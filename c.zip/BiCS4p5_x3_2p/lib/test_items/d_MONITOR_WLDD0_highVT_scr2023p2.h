uint8 d_MONITOR_WLDD0_highVT_scr2023p2(void) //tb_652 nvcc SCR1854p2
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB

    VSGS_VSGD_Detection_2A(WLDD0, HIGH_VT, 2800, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E);  //VCGRV = 2.8V 16bit ignore/1K

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
