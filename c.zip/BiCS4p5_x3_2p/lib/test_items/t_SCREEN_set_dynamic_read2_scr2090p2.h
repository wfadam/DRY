uint8 t_SCREEN_set_dynamic_read2_scr2090p2(void) //tb_744 nvcc SCR2090p0
{
    uint8 die, FailFlag = 0;
    uint16 GoodBlk = 0;

    Para_Table Para_Array[] =
    {
        {0x116, 0x80, 0x80}, //SET 5D_EEEF_VCGSFT = 1 to enable dynamic read
    };
    
    //Double check the feature value array once try to change it.
    uint32 LP_DAC_shift[2][2] =
    {
        {0x0000004F, 0x00000000}, //Skip minus dynamics read level shift for A state.
        {0x004F0000, 0x00B00000},
    };
    uint32 MP_DAC_shift[3][2] =
    {
        {0x0000004F, 0x000000B0},
        {0x00004F00, 0x0000B000},
        {0x004F0000, 0x00B00000},
    };
    uint32 UP_DAC_shift[2][2] =
    {
        {0x00004F00, 0x0000B000},
        {0x4F000000, 0xB0000000},
    };

    uint8 LP_DAC_cnt = sizeof(LP_DAC_shift[0])/sizeof(LP_DAC_shift[0][0]);
    uint8 MP_DAC_cnt = sizeof(MP_DAC_shift[0])/sizeof(MP_DAC_shift[0][0]);
    uint8 UP_DAC_cnt = sizeof(UP_DAC_shift[0])/sizeof(UP_DAC_shift[0][0]);

    print(0,"DAC_Cnt LP ~, MP ~, UP ~\n", LP_DAC_cnt, MP_DAC_cnt,UP_DAC_cnt);

    //Search 1 pair good block
    FOR_EACH_DIE(die)
    {
        GoodBlk = Search_Pair_Blk_BBMap_by_Die(die,0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1);
        
        if(GoodBlk != TOTAL_BLK)
        {

            MLC_Erase_By_Die(die, GoodBlk, GoodBlk+1, DONOT_MARKBB);
            MLC_Program_6D_By_Die(die, GoodBlk, GoodBlk+1, DONOT_MARKBB, PRINT_FAIL);
            
            SET_PARAMETERS(die, Para_Array);

            FailFlag |= Set_Get_Feature_Dynamic_Read_2A_AIPR(die, GoodBlk, *LP_DAC_shift, LP_DAC_cnt, LOWER, 0x89, 0x85, BIT_IGNORE_10);
            FailFlag |= Set_Get_Feature_Dynamic_Read_2A_AIPR(die, GoodBlk, *MP_DAC_shift, MP_DAC_cnt, MIDDLE, 0x8A, 0x86, BIT_IGNORE_10);
            FailFlag |= Set_Get_Feature_Dynamic_Read_2A_AIPR(die, GoodBlk, *UP_DAC_shift, UP_DAC_cnt, UPPER, 0x89, 0x85, BIT_IGNORE_10);

            RESET_PARAMETERS(die, Para_Array);

            if(FailFlag != 0)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }

        FEATURE_RESET;
        NAND_RESET;
    }


    return(PF_Check());
}
