uint8 d_MONITOR_wldd1_rc_scr2234p0(void) // tb__542 nvcc
{
    uint8 die;
    ADR_Init(adr);
    adr.phy.wl = WLDD1;
    
    Para_Table Para_Array[] =
    {
        {0x103, 0x00, 0x10}, // LVSTAGEFLG = Disable 
        {0x002, 0x40, 0xC0}, // F_TESTTEMP = 2'b01
        {0x00E, 0x20, 0xFF}, // F_RC_MEAS = 1/F_RC_MON = 0 (t1 Meas) 
        {0x12E, 0x20, 0x20}, // F_SDE_2X_TEST = 1(SCAN_SLOW=1)   
        {0x00A, 0x00, 0xFF}, // Upper Criteria MSB=0 & Lower Criteria MSB=0
        {0x00B, 0x0A, 0xFF}, // Lower Criteria=10.
        {0x00C, 0x32, 0xFF}, // Upper Criteria=50. 
    };
    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);

        FOR_EACH_LOOP(adr.phy.blk,0, TOTAL_BLK, 1)
        {
            WL_RC_Check_By_Die(die,adr,DLY_400);
        }

        RESET_PARAMETERS(die, Para_Array);
    }

    GBB_MONITOR_PRINT;
    return(PF_Monitor());
}
