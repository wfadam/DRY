uint8 t_SCREEN_cluster_blk_scr2126p0(void) //tb_954 nvcc SCR867p2
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Cluster_BB_Count_PHY(die,2, CLUSTER_LIMIT_32))
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}
