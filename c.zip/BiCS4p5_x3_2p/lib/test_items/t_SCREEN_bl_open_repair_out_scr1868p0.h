uint8 t_SCREEN_bl_open_repair_out_scr1868p0(void)  //tb__171 nvcc SCR533p2
{
    uint8 die;
    uint16 Good_Blk[TOTAL_DIE];

    FOR_EACH_DIE(die)
    {
        Good_Blk[die] = Search_Pair_Blk_BBMap_Erase_by_Die(die, TOP_BLK_EDGE, 0, 16, PAIR_4, MLC_ERASE);

        if(Good_Blk[die] != TOTAL_BLK)
        {
            Scan_BC_To_Select_Array(die, g_Temp_BC, PREBCMASK, NOBC_PRINT);

            if(Is_Bad_Die(die, TEMP) == 0)
            {
                if(Bitline_Open(die, Good_Blk[die]) != 0)
                {
                    Print_Die_Failure_Add_BD(die, "");
                }
            }

            Scan_BC_To_Select_Array(die, g_Outgoing_BC, PSTBCMASK, GBC_PRINT);
        }
    }

    BC_Limit_Check(BC_LIMIT_PER_PLN, GBC_LIMIT_PER_PLN, g_Temp_BC, g_Outgoing_BC);

    ROMBLOCK_UPDATE;

    return(PF_Check());
}
