uint8 t_SCREEN_xdl_reset_param_mismatch_scr2131p1(void)//tb__201 nvcc BICS4 SCR926p1
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(XDL_Reset_Param_Mismatch(die)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}
