uint8 t_AllG_Fast_Cycling_SCR1931p1(void)//tb__9999 nvcc
{
    uint8 loop;
    uint16 stamp_location=0;

    Para_Table Para_Array[] =
    {
        {0x002, 0xC0, 0xC0}, // F_TESTTEMP= 2'b11
        {0x02D, 0x50, 0xFF}, // Set G state verify level to 5V.
        {0x136, 0x00, 0x80}, //Smart PCV disable       //Address change in BiCS4.5
        {0x0A6, 0x00, 0x20}, //F_STB_RR_SCAN disable    //New parameter in BiCS4.5
        {0x00E, 0x08, 0x68}, //F_PROG_AUTO_PAGEINC=1, F_API_XDL_DATA=0    
    };

    FOR_EACH_LOOP(loop, 0, ALLG_CYCLE_NUM, 1)
    {
        if(loop<=28)    stamp_location=0x1000+loop*0x10;
        else            stamp_location=0x1300+(loop-29)*0x10;
        if(Stamp_Exist_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, stamp_location, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
        {
            ALLG_Fast_Cycle_Erase_Pgm(0x0C, Para_Array,sizeof(Para_Array)/sizeof(Para_Table));

            Program_Stamp_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, stamp_location, BYTE_8);
        
            if(Stamp_Exist_In_Range(DIE0, MTST_UROM_BLK0, WL2, WL3, STR0, STR1, stamp_location, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
            {
                Print_Die_Failure(0, "Read stamp");
                Mark_All_Die_Bad(TEMP);
                break;
            }
        }
        else
        {
            print(0, "Skip Lp~\n", loop);
            Dummy_Wait(WAIT_ALLG);
        }
    }

    return(PF_Check());
}
