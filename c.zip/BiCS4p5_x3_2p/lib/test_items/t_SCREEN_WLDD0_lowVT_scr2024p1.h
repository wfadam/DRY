uint8 t_SCREEN_WLDD0_lowVT_scr2024p1(void) //tb__680 nvcc
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB

    VSGS_VSGD_Detection_2A(WLDD0, LOW_VT, 400, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E);  //VCGRV = 0.4V 16bit ignore/1K

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
