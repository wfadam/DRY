uint8 t_SCREEN_vsgd_highVT_scr1848p4(void) //tb_625 nvcc SCR1848p4
{

    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB

    VSGS_VSGD_Detection_2A(SGD, HIGH_VT, 3200, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E);  //VCGRV = 3.2V

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
