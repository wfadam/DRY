uint8 d_SLC_PRG_Stamp_FH_scr1953p0(void)  //tb_814_nvcc
{
    if(Read_UR_Stamp_4C(0x00, MTST_UROM_BLK0, MTST_STAMP_WL, MTST_STAMP_STR, PASS_STAMP_COL, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST) // location maybe conflict with CFH
    {
        Program_Stamp_In_Range(0x00, MTST_UROM_BLK0, MTST_STAMP_WL,MTST_STAMP_WL+1,MTST_STAMP_STR,MTST_STAMP_STR+1,PASS_STAMP_COL, BYTE_8);
    }
    else
    {
        print(0, "Has Stamp,Skip\n");
    }

    return(PF_Monitor());
}