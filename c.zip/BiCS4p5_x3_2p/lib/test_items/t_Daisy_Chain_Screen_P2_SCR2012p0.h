uint8 t_Daisy_Chain_Screen_P2_SCR2012p0(void)//tb__733 nvcc Base on SCR2012.0
{
    uint8 die = 0;
    uint8 i = 0, j = 0;
    uint8 Err_Cnt = 0;
    uint8 Params[5] = { 0x10, 0x11, 0x20, 0x21, 0xF0};
    uint8 Value[5][3] = {{0x00,0x0F,0x00},{0x00,0xFF,0x00},{0x00,0xCF,0x00},{0x00,0xFF,0x00},{0x10,0xEF,0x10}};
    uint8 mask[5] = { 0x0F, 0xFF, 0xCF, 0xFF, 0xFF};
    FOR_EACH_DIE(die)
    {
        Err_Cnt = 0;
        FOR_EACH_LOOP(i, 0, 5, 1)
        {
            FOR_EACH_LOOP(j, 0, 3, 1)
            {
                if(Param_Daisy_Chain_Check(die, Params[i], Value[i][j], mask[i]) != 0)
                {

                    BD_Add(die, TEMP);
                    Err_Cnt ++;
                    if(Err_Cnt == 1)
                    {
                        Print_Die_Failure(die, "");
                    }
                }

                if(Err_Cnt > 5) break;
            }
            if(Err_Cnt > 5) break;
        }
    }

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
