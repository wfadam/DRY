uint8 t_SLC_RD_stamp_FH_scr1954p0(void)  //tb_813_nvcc
{
    if(Stamp_Exist_In_Range(0x00, MTST_UROM_BLK0, MTST_STAMP_WL, MTST_STAMP_WL+1, MTST_STAMP_STR, MTST_STAMP_STR+1, PASS_STAMP_COL, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST) // location maybe conflict with CFH
    {
        print(0,"no stamp"); 
        Mark_All_Die_Bad(TEMP);
    }
    return(PF_Check());
}