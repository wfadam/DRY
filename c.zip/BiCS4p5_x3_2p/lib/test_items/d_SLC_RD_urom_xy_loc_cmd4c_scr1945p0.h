uint8 d_SLC_RD_urom_xy_loc_cmd4c_scr1945p0(void)//tb__120 nvcc
{
    Read_XY_1copy();
    
    return(PF_Monitor());
}
