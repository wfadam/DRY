uint8 t_Read_ID_RE_WE_Check() //tb__196 nvcc
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Read_ID_RE_WE_Check(die)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}
