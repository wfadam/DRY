uint8 t_SCREEN_VDD_b2_scr2159p1(void) //tb428 nvcc SCR2159p0
{
    uint8 i;
    g_CMDB2_FLAG = CMDB2_ENABLE;

    GBB_Check_Init(GBB_limit);

    Para_Table Para_Array[2][1] =
    {
        {{0xDE, 2, PLUS|0x1F}},
        {{0xDE, 2, MINUS|0x1F}}, 
    };

    MLC_Margin_Erase();

    for(i = 0; i < 2; i ++)
    {              
        SET_PARAMETERS_ALL_DIE(Para_Array[i]);

        Margin_Block_Check(BIT_IGNORE_150);

        RESET_PARAMETERS_ALL_DIE(Para_Array[i]);
    } 

    MLC_Margin_Erase();

    GBB_limit.GBB_CHECK_PLN=4;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
