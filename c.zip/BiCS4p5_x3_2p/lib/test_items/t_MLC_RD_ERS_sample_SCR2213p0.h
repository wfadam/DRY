uint8 t_MLC_RD_ERS_sample_SCR2213p0(void) // tb_396 hvcc
{
    GBB_Check_Init(GBB_limit);

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Read_6D_2A(MLC_EP_G0_START, MLC_EP_G0_END,MARKBB,IGN_BITS_MLC_SCR2213,SET_AB);
    MLC_Erase_2A(MLC_EP_G0_START, MLC_EP_G0_END,MARKBB);

  
    MLC_Read_6D_2A(MLC_EP_G1_START, MLC_EP_G1_END,MARKBB,IGN_BITS_MLC_SCR2213,SET_AB);
    MLC_Erase_2A(MLC_EP_G1_START, MLC_EP_G1_END,MARKBB);

   
    MLC_Read_6D_2A(MLC_EP_G2_START, MLC_EP_G2_END,MARKBB,IGN_BITS_MLC_SCR2213,SET_AB); 
    MLC_Erase_2A(MLC_EP_G2_START, MLC_EP_G2_END,MARKBB);


    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_limit.GBB_CHECK_PLN=4;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 

    return(PF_Check());
}