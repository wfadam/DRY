uint8 d_S57_NST_SLC_Dyn_SLC_Cache_RD_DP(void)
{
    uint8 die, i;
    uint16 Blk_Cnt = NST_BLK_CNT, blk, blk_2, blk_loop;
    uint16 Blk_Start[3] = {0,         BOT_BLK_EDGE,  TOP_BLK_EDGE}; //Middle, Bottom, Top Blk
    uint16 Blk_Stop[3]  = {TOP_BLK_EDGE, TOTAL_BLK,  0};

    ADR_Init(adr);
    NST_Buffer_Init();

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(i, 0, NST_BLK_GROUP, 1) //Blk Loop
        {
            NST_Blk_Search_Group(die, Blk_Start[i], Blk_Stop[i], Blk_Cnt, i);
        }

        if(Is_Bad_Die(die, TEMP) == 0)
        {
            FOR_EACH_LOOP(i, 0, NST_BLK_GROUP, 1) //Middle, Bottom, Top BLK
            {
                g_Print_Cnt = 0;

                FOR_EACH_LOOP(blk_loop, 0, Blk_Cnt, TOTAL_PLN)
                {
                    blk = g_SLC_Blk_G[i] + blk_loop;
                    blk_2 = g_SLC_Blk_2_G[i] + blk_loop;

                    NST_Pgm_Buf_Input(die, blk,   SLC, DUAL_PLN, BUF0);  //Background Condition
                    NST_Pgm_Buf_Input(die, blk_2, SLC, DUAL_PLN, BUF1);  //Background Condition

                    NST_SLCR_Shift_Trim(die, DYNRD_ENABLE);
                    NST_SLC_Dyn_Shift(die, DYNRD_ENABLE);

                    CMDFxPointer(die);

                    FOR_EACH_PAGE(adr)
                    {
                        adr.phy.blk = blk;
                        NST_Read_Single_Page(die, adr,               SLC_CMD, 0x30, DYNRD_ENABLE, DLARD_DISABLE, FASTRD_DISABLE, 0xE0);
                        NST_Read_Single_Page(die, Adr_Blk_Add1(adr), SLC_CMD, 0x31, DYNRD_ENABLE, DLARD_DISABLE, FASTRD_DISABLE, DONOT_CHECK);
                        NST_RDCompare_Buf_Input(die, adr, PLN_0, SLC, DYNRD_ENABLE, IGN_BITS_SLC, BUF0);

                        adr.phy.blk = blk_2;
                        NST_Read_Single_Page(die, adr,               SLC_CMD, 0x32, DYNRD_DISABLE, DLARD_DISABLE, FASTRD_DISABLE, DONOT_CHECK);
                        NST_Read_Single_Page(die, Adr_Blk_Add1(adr), SLC_CMD, 0x31, DYNRD_DISABLE, DLARD_DISABLE, FASTRD_DISABLE, DONOT_CHECK);

                        adr.phy.blk = blk;
                        NST_RDCompare_Buf_Input(die, adr, PLN_1, SLC, DYNRD_ENABLE, IGN_BITS_SLC, BUF0);

                        CMD_WRB(0x3F, RB_READ); //Exit Cache Read

                        adr.phy.blk = blk_2;
                        NST_RDCompare_Buf_Input(die, adr, PLN_0, SLC, DYNRD_DISABLE, IGN_BITS_SLC, BUF1);
                        NST_RDCompare_Buf_Input(die, adr, PLN_1, SLC, DYNRD_DISABLE, IGN_BITS_SLC, BUF1);
                    }

                    NST_SLCR_Shift_Trim(die, DYNRD_DISABLE);
                    NST_SLC_Dyn_Shift(die, DYNRD_DISABLE);
                }
            }
        }
    }

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
