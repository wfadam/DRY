uint8 t_SLC_RD_stamp_fixcol_SH_scr2173p0(void)//tb__817 nvcc
{
    uint8 FailFlag = 0;
    uint16 col_shift=0x480;
    uint16 sh_stamp_col=0x08*TOTAL_DIE;

    if(Read_UR_Stamp_4C(0x00, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR, sh_stamp_col, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
    {
        if(Read_UR_Stamp_4C(0x00, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR+1, sh_stamp_col+col_shift, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
        {
            if(Read_UR_Stamp_4C(0x00, MTST_UROM_BLK0, SH_STAMP_WL+1, SH_STAMP_STR, sh_stamp_col+col_shift*2, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
            {
                if(Read_UR_Stamp_4C(0x00, MTST_UROM_BLK0, SH_STAMP_WL+1, SH_STAMP_STR+1, sh_stamp_col+col_shift*3, BIT_IGNORE_10, 0xAA, BYTE_8)==DONOT_EXIST)
                {
                    Print_Die_Failure(0, "");
                    FailFlag|=1;
                }
            }
        }
    }

    return(FailFlag);//reject if no stamp, no need to check fail die number.
}
