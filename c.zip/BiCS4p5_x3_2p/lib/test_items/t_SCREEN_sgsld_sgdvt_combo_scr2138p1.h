uint8 t_SCREEN_sgsld_sgdvt_combo_scr2138p1(void) //tb_642 nvcc SCR2138p0
{
    uint8 die;
    uint16 blk, i;

    #if(TOTAL_DIE > 8)
        uint16 *g_BuFF_BB = (uint16 *)SETBUF(0);
    #else
        uint8 *g_BuFF_BB = (uint8 *)SETBUF(0);
    #endif

    Para_Table Para_Array[] =
    {
        {0x002, 0x40, 0xC0},  //F_TESTTEMP=1
        {0x118, 0x20, 0x20},  // F_WLLD_WAY=1 HALF WLS
        {0x118, 0x04, 0x04},  // F_WL2WLLD_EN=1
        {0x118, 0x00, 0x02},  // F_WL2SUB_EN=0
        {0x119, 0x00, 0x0C},  // F_PPNPPE_MLC/SLC=0
        {0x117, 0x00, 0x30},  // F_PAP_ERASE=0
        {0x118, 0x10, 0x10},  // F_WLLD_N0ERA=1 
        {0x04C, 0x00, 0xC0},  // F_PROGSRC_WLLD=0(VSS)
        {0x100, 0x00, 0x01},  // F_BL_BIAS_STRPCG=0
        {0x052, 0x00, 0xF0},  // F_INC_VPGM_WL2WL=0
        {0x00C, 0x02, 0x02},  // WLLD_OPT = 1
        {0x046, 0x24, 0xFF},  // F_VPGMU = 7V   
        {0x083, 0x60, 0xF0},  // F_PD1_WLLD= 1096.64us
        {0x00C, 0x40, 0x40},  // F_SGSB_SGLD_SGLI = 1
        {0x118, 0x08, 0x08},  // F_WLLD_EN = 1 ENABLE
        {0x043, 0xE0, 0xE0},  // F_VISO1 = VSS
        {0x084, 0xE0, 0xE0},  // F_PR8 = 4.56us
        {0x0DF, 0x60, 0x60},  // F_WL2WL_REFTAIL_BOOST = x10
        {0x0AD, 0x00, 0xC0},  // F_WLLD_HIGH_CUR = 2uA
        {0x0AD, 0x00, 0x38},  // F_WLLD_CC_LDCLK = 0 disable
        {0x0AE, 0x03, 0x03},  // F_WLLD_ICM= 2000nA
        {0x0AE, 0xC0, 0xC0},  // F_WLLD_ICS_RANGE= 12.5nA
        {0x0AE, 0x24, 0x3C},  // F_WLLD_IDT = 500nA
        {0x011, 7,    PLUS|0x3F}, //SDE = default(71.6ns) + 7DAC = 80ns
    };

    FOR_EACH_LOOP(i, 0, TOTAL_COL, 1)
    {
        *(g_BuFF_BB + i) = 0;
    }

    Reset_All_BBlk();
    Set_Datalog_Block_as_BB(); // prevent datalog block erased by below MLC_erase
    Reset_Select_BB_Map(TEMP);
    Reset_Select_BB_Map(SUBBB);

    SET_PARAMETERS_ALL_DIE(Para_Array);

    SGS_SGD_Leakage(SGS_LEAK, DUAL_PLN);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FOR_EACH_LOOP(blk, 0, TOTAL_BLK, 1)
    {
        g_BuFF_BB[blk] = BBlk_Map_Temp[blk]; //Move Test1 GBB to Buf1
    }

    MLC_Erase(0, TOTAL_BLK, DONOT_MARKBB);
    Reset_Select_BB_Map(TEMP);
    VSGS_VSGD_Detection_2A(SGD, HIGH_VT, 4000, MARKBB, MLC_STATUS, BIT_IGNORE_16, DONOT_SET_9E);  //VCGRV = 4.0V 16Ignorebits/1K

    FOR_EACH_LOOP(blk, 0, TOTAL_BLK, 1)
    {
        g_BuFF_BB[blk+TOTAL_BLK] = BBlk_Map_Temp[blk]; //Move Test2 GBB to Buf2
    }

    Reset_Select_BB_Map(TEMP);
    VSGS_VSGD_Detection_2A(SGD, LOW_VT, 2300, MARKBB, MLC_STATUS, BIT_IGNORE_16, DONOT_SET_9E); //VCGRV = 2.3V 16Ignorebits/1K

    Add_Map1_to_Map2(TEMP, SUBBB); //Move Test3 GBB to SUBBB

    Reset_Select_BB_Map(TEMP);

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(blk, 0, TOTAL_BLK, 1)
        {
            if(((g_BuFF_BB[blk]&(1<<die))&&(g_BuFF_BB[blk+TOTAL_BLK]&(1<<die))) || ((g_BuFF_BB[blk]&(1<<die))&&Is_BB(die, blk, SUBBB)))
            {
                BB_Add(die, blk, TEMP); //Move common BB to TEMP and do EOC check
            }
        }
    }

    BB_Check_EOC(0, TOTAL_BLK, 4, 5, TEMP);

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(blk, 0, TOTAL_BLK, 1)
        {   
            if( ((g_BuFF_BB[blk]&(1<<die)) && ((g_BuFF_BB[blk+TOTAL_BLK]&(1<<die)) == 0) && (Is_BB(die, blk, SUBBB) == 0))  //BB in T1 not in T2,T3
             || (((g_BuFF_BB[blk]&(1<<die)) == 0) && (g_BuFF_BB[blk+TOTAL_BLK]&(1<<die)))                                   //BB in T2 not in T1
             || (((g_BuFF_BB[blk]&(1<<die)) == 0) && Is_BB(die, blk, SUBBB)))                                               //BB in T3 not in T1
            {
                BB_Add(die, blk, TEMP); //Add uncommon BB to TEMP
            }
        }
    }

    Reset_Select_BB_Map(SUBBB);

    FULLARRAY_BB_CHECK;

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
