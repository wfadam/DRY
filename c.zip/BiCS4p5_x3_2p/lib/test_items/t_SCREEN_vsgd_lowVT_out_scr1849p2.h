uint8 t_SCREEN_vsgd_lowVT_out_scr1849p2(void) //tb_638 nvcc SCR537p5
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB

    VSGS_VSGD_Detection_2A(SGD, LOW_VT, 2300, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E); //VCGRV = 2.3V

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}

