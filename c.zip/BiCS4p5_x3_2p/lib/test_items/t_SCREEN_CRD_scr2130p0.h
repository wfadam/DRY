uint8 t_SCREEN_CRD_scr2130p0(void)//tb__210 nvcc
{
    uint8 die;
    uint16 source_block;

    FOR_EACH_DIE(die)
    {
        source_block = Search_Pair_Blk_BBMap_Erase_by_Die(die, 0, TOTAL_BLK, TOTAL_PLN, PAIR_1, MLC_ERASE);

        if(source_block != TOTAL_BLK)
        {
            if(CRD_Screen(die, source_block)!=0)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }
    }

    return(PF_Check());
}
