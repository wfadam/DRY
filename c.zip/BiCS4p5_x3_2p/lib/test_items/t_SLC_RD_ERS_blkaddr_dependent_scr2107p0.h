uint8 t_SLC_RD_ERS_blkaddr_dependent_scr2107p0()   //tb_393 nvcc SCR1186p2
{
    SLC_Read_Erase(IGN_BITS_SLC);
    
    FULLARRAY_BB_CHECK;
    return(PF_Check());
}
