uint8 t_SCREEN_TLC_Cache_Read_SCR10605p0(void) //tb_848 nvcc scr2363p1
{
    uint8 die;
    uint16 good_blk;


    Para_Table Para_Array[] =
    {
        {0xDE,    3, MINUS|0x1F},  //Set VDD-3DC
       
    };

    TM_Entry();

    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_Erase_by_Die(die, 0x100, TOTAL_BLK, TOTAL_PLN, PAIR_2,MLC_ERASE);
        if(good_blk != TOTAL_BLK)
        {
            MLC_Program_Scramble_By_Die(die, good_blk, good_blk + 4, MARKBB, PRINT_FAIL);
            SET_PARAMETERS(die, Para_Array);
            TLC_Cache_Read_CMD3C(die, good_blk, good_blk + 4);
            MLC_Erase_By_Die(die, good_blk, good_blk + 4, DONOT_MARKBB);
            RESET_PARAMETERS(die, Para_Array);
        }
    } 

    TM_Exit();

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN=1;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);


    return(PF_Check());
}
