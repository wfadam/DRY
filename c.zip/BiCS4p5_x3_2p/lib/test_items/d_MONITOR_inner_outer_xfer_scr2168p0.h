uint8 d_MONITOR_inner_outer_xfer_scr2168p0(void) //tb__676 nvcc base on BIC4 1058p0
{
    BB_Print_Per_Category(MAIN, 0, TOTAL_BLK);

    return(PF_Monitor());
}