uint8 t_SCREEN_SDE_scr2129p0(void) //tb_432 nvcc SCR660p4
{
    uint8 loop;

    Para_Table Para_Array[2][1] =
    {
        {0x011,	1,  PLUS|0x3F}, //SDE+1DAC
        {0x011, 1, MINUS|0x3F}, //SDE-1DAC
    };

    MLC_Margin_Erase();

    FOR_EACH_LOOP(loop, 0, 2, 1)
    {
        SET_PARAMETERS_ALL_DIE(Para_Array[loop]);

        Margin_Block_Check(BIT_IGNORE_110);

        RESET_PARAMETERS_ALL_DIE(Para_Array[loop]);
    }

    MLC_Margin_Erase();

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 4;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
