uint8 d_Preheat()
{
	uint16 blk;

	MLC_Erase(0x100, 0x300, DONOT_MARKBB);
	for(blk=0x100; blk<0x300; blk+=0x10)
	{
		print(0,"BLK@-", blk);
		if(Reach_Temp(83)==1)
		{
			// print(0,"Temperature reach ~ at BLK@\n",80,blk);
			break;
		}
		MLC_Program_6D_2A(blk, blk+0x10, DONOT_MARKBB, SET_AB);
	}
	print(0,"\n");

	MLC_Erase(0x100, blk, DONOT_MARKBB);

	return(PF_Monitor());
}