uint8 t_DS_Parm_Restore(void)
{
    uint8 die = 0;

    FOR_EACH_DIE(die)
    {
        if(DS_Parm_Condition_Check(die))
        {
            if(Restore_DS_Param_Parity(die, DS_BACKUP_BLK, DS_BACKUP_WL, DS_BACKUP_STR) != 0)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }
        else
        {
            print(0, "D@ Skip\n", die);
        }
    }

    ROMBLOCK_UPDATE;

    FOR_EACH_DIE(die)
    {
        Parm_Scan(die);
    }

    Print_Param();

    return(PF_Check());
}
