uint8 t_SCREEN_cmd80_xdlreset_vdd_scr1844p0() //tb__193 nvcc SCR884.3
{
    uint8 die;

    Para_Table Para_Array[] =
    {
        {0x0DE, 2, PLUS|0x1F},
    };

    Para_Table Para_Array_1[] =
    {
        {0x0DE, 2, MINUS|0x1F},
    };
    FOR_EACH_DIE(die)
    {
        POR_From_RF(die, 0, DONOT_USE_4C);
        SET_PARAMETERS(die, Para_Array);
        if(XDL_CMD80_Reset(die) != 0)
        {
            Print_Die_Failure_Add_BD(die, "VDD+");
        } 
        RESET_PARAMETERS(die, Para_Array);
       
        SET_PARAMETERS(die, Para_Array_1);
        if(XDL_CMD80_Reset(die) != 0)
        {
            Print_Die_Failure_Add_BD(die, "VDD-");
        } 
        RESET_PARAMETERS(die, Para_Array_1);

        POR_From_RF(die, 0, USE_4C);
    }

    return(PF_Check());
}
