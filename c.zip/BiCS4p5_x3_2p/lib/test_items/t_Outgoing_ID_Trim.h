uint8 t_Outgoing_ID_Trim()
{
    uint8 die;

    g_Update_Para_Array_En = 1; //enable parameter array update

    FOR_EACH_DIE(die)
    {
        Set_ID(die);
        Outgoing_ID_Trim(die);
        _CMD(0x9E);
        ChipPointer(0);
        REG_SA_Parity_BC_Fill_AA(die);
        Set_ID(die);
        Erase_Romblock(die);//Monitor according to SCR
        if(Program_Romblock(die)!=0) Print_Die_Failure(die, "Program Romblock");
    }

    g_Update_Para_Array_En = 0; //disable parameter array update

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
