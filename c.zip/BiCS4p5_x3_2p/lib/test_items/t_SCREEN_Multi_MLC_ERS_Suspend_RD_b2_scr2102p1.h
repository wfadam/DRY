uint8 t_SCREEN_Multi_MLC_ERS_Suspend_RD_b2_scr2102p1(void) //tb_736 nvcc SCR2102p0
{
    uint8 die=0, i=0;
    uint16 blk_a, blk_b,blk_c;
    uint8 Suspend_CMD[3] = {0xFA, 0xFF, 0x51};

    g_CMDB2_FLAG = CMDB2_ENABLE;

    GBB_Check_Init(GBB_limit);

    FOR_EACH_DIE(die)
    {
        blk_a=Search_Pair_Blk_BBMap_Erase_by_Die(die, 0x300, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,MLC_ERASE);
        blk_b=Search_Pair_Blk_BBMap_Erase_by_Die(die, blk_a+2, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,MLC_ERASE);
        blk_c=Search_Pair_Blk_BBMap_Erase_by_Die(die, blk_b+2, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,MLC_ERASE);

        if((blk_a != TOTAL_BLK) && (blk_b != TOTAL_BLK) && (blk_c != TOTAL_BLK))
        {
            for(i = 0; i < 3; i ++)
            {
                MLC_Program_6D_By_Die(die, blk_a, blk_a+2, MARKBB, PRINT_FAIL);
                MLC_Program_6D_By_Die(die, blk_b, blk_b+2, MARKBB, PRINT_FAIL);
                MLC_Program_6D_By_Die(die, blk_c, blk_c+2, MARKBB, PRINT_FAIL);
                
                //MLC Erase blk_a&blk_a+1
                if(MLC_Erase_Suspend_6D_Sample_WL(die, blk_b, blk_a, BIT_IGNORE_32, IGN_BITS_MLC, DLY_100, Suspend_CMD[i])!=0)  BD_Add(die, TEMP);
                if(MLC_Erase_Suspend_6D_Sample_WL(die, blk_c, blk_a, BIT_IGNORE_32, IGN_BITS_MLC, DLY_1000, Suspend_CMD[i])!=0)  BD_Add(die, TEMP);

                if(MLC_Read_6D_By_Die_Sample_WL(die, blk_a, IGN_BITS_MLC)!=0)  BD_Add(die, TEMP);

                MLC_Erase_By_Die(die, blk_a, blk_a+2, MARKBB);
                MLC_Erase_By_Die(die, blk_b, blk_b+2, MARKBB);
                MLC_Erase_By_Die(die, blk_c, blk_c+2, MARKBB);
            }
        }
    }

    GBB_limit.GBB_CHECK_PLN=0;
    GBB_limit.MarkBB=DONOT_MARKBB;

    GBB_Check(GBB_limit); 

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
