uint8 t_SCREEN_ers_background_scr2067p0(void)//tb__738 nvcc
{
    uint8 die;
    uint16 good_blk;

    if(TOTAL_DIE>1)
    {
        good_blk = Search_Pair_Blk_BBMap_AllDie(0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1);

        if(good_blk != TOTAL_BLK)
        {

            FOR_EACH_DIE(die)
            {
                if(Erase_Background_Screen(die, good_blk)!=0)
                {
                    Print_Die_Failure_Add_BD(die, "");
                }
            }
        }
    }

    else
    {
        print(0, "Skip 1D\n");
    }

    return(PF_Check());
}
