uint8 t_SLC_RD_ff_data_scr2094p0(void)//tb__391 nvcc
{
    SLC_Read_Pattern_2A(0, TOTAL_BLK, ALLFF, IGN_BITS_SLC_ALLFF);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
