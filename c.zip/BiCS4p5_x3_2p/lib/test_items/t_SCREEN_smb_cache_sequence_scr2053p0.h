uint8 t_SCREEN_smb_cache_sequence_scr2053p0(void) //tb__202 nvcc BICS4 SCR1088p2
{
    uint8 die = 0;

    FOR_EACH_DIE(die)
    {
        if(SMB_Cache_Seq(die)!= 0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}

