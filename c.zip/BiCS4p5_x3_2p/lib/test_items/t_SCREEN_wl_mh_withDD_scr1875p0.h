uint8 t_SCREEN_wl_mh_withDD_scr1875p0(void)  // tb__479 nvcc based on BICS4 SCR1034p3
{
    Para_Table Para_Array[] =
    {
        {0x002, 0x40, 0xC0}, //F_TESTTEMP=1
        {0x00D, 0x00, 0x80}, //F_VPGM2VDD_STRPCG_EN=0
        {0x00C, 0x30, 0x30}, //F_WLDL_WLLD=1,F_WLDU_WLLDL=1 Bias of Dummy WL near the joints  --BiCS4.5 no change
        {0x118, 0x00, 0x04}, // F_WL2WLLD_EN=0
        {0x118, 0x02, 0x02}, // F_WL2SUB_EN=1
        {0x119, 0x00, 0x0C}, // F_PPNPPE_MLC/SLC=0
        {0x117, 0x00, 0x30}, // F_PAP_ERASE=0
        {0x118, 0x10, 0x10}, // F_WLLD_N0ERA=1
        {0x04C, 0x00, 0xC0}, // F_PROGSRC_WLLD=VSS
        {0x100, 0x00, 0x01}, // F_BL_BIAS_STRPCG=VSS
        {0x118, 0x00, 0x20}, // F_WLLD_WAY=0 All WL
        {0x0AE, 0x24, 0x3C}, // F_WLLD_IDT= 500nA
        {0x0AE, 0x01, 0x03}, // F_WLLD_ICM= 1000nA
        {0x0AE, 0xC0, 0xC0}, // F_WLLD_ICS_RANGE= 12.5nA
        {0x083, 0xC0, 0xF0}, // F_PD1_WLLD= 2079.68us
        {0x12B, 0x40, 0x40}, // F_WLDSEL_WLLD=1//Dummy WL select for WL2WL leak detect
        {0x0B8, 0x00, 0xF0}, // F_VSGDPCH = 3.0V
        {0x046, 0x24, 0xFF}, // F_VPGMU = 7V
        {0x052, 0x02, 0x0F}, // F_INC_VPGM_WL2SUB = 0.8V Default is always 0.8V however S0E has different voltage level in DS. So, making this value as universal.
        {0x011, 7,    PLUS|0x3F}, //BiCS4.5 changed default SDE to 71.6 from 70.4, reducing DAC from 8 to 7
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    WL_Dummy_Read(USE_DD);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
