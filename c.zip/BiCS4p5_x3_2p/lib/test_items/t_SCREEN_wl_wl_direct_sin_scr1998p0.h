uint8 t_SCREEN_wl_wl_direct_sin_scr1998p0(void) // tb_475 nvcc Base on SCR1290.2
{
    uint8 die;

    Para_Table Para_Array[] =
    {
        {0x118, 0x08, 0x08}, // F_WLLD_EN=1
        {0x118, 0x04, 0x04}, // F_WL2WLLD_EN=1
        {0x118, 0x00, 0x02}, // F_WL2SUB_EN=0
        {0x119, 0x00, 0x0C}, // F_PPNPPE_MLC/SLC=0
        {0x117, 0x00, 0x30}, // F_PAP_ERASE=0
        {0x118, 0x10, 0x10}, // F_WLLD_N0ERA=1
        {0x04C, 0xC0, 0xC0}, // F_PROGSRC_WLLD=VDDSA
        {0x100, 0x01, 0x01}, // F_BL_BIAS_STRPCG=VDDSA
        {0x118, 0x20, 0x20}, // F_WLLD_WAY=1 Half WL
        {0x0AE, 0x24, 0x3C}, // F_WLLD_IDT= 500nA
        {0x0AE, 0x01, 0x03}, // F_WLLD_ICM= 1000nA
        {0x0AE, 0xC0, 0xC0}, // F_WLLD_ICS_RANGE= 12.5nA
        {0x083, 0xF0, 0xF0}, // F_PD1_WLLD= 2571.20us
        {0x12C, 0x00, 0x18}, // F_HR_EN & F_HR_EN_ERASE = disable
        {0x011, 7,    PLUS|0x3F}, // SDE= default(71.6ns) + 7DAC = 80ns  
        {0x046, 10,   MINUS|0xFF}, // VPGMU=Default - 1V =~ 12V
    };

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);
        WL_WL_Leak_WO_Dummy_CG_Pattern(die);
        RESET_PARAMETERS(die, Para_Array);
    }

    FULLARRAY_BB_CHECK;
    return(PF_Check());
}
