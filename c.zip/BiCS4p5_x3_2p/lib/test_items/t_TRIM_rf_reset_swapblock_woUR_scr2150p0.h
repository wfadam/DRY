uint8 t_TRIM_rf_reset_swapblock_woUR_scr2150p0(void)//tb__930 nvcc Base on SCR1737.0
{	
    uint8 die, pln, repair_value[2]={0,0};

    FOR_EACH_DIE(die)
    {
        FOR_EACH_PLN(pln) 
        {
            repair_value[pln] = Check_UR_Repair_Blk(die, pln);
        }

        Reset_Swap_Bit(die);

        FOR_EACH_PLN(pln)
        {
            if(repair_value[pln]!=0)
            {
                if(Swap_UR(die, pln)!=PASS)
                {
                    Print_Die_Failure_Add_BD(die, "Swap");
                }
                if(Check_UR_Repair_Blk(die,pln)!=repair_value[pln])
                {
                    Print_Die_Failure_Add_BD(die, "RD Value");
                }
            }
        }
    }

    ROMBLOCK_UPDATE;

    return(PF_Check());
}
