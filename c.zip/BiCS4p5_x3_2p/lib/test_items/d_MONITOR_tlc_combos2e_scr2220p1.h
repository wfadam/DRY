uint8 d_MONITOR_tlc_combos2e_scr2220p1(void) //tb_525_nvcc SCR2220p0
{
    Para_Table Para_Array[] =
    {   
        {0x137, 0x02, 0x07}, //BSPF_EV_SLC[2:0] = 16 bits
        {0x12F, 0x06, 0x0F}, //NLE_MLC[3:0] = 6 loops (default = 6 loops)
        {0x133, 0x00, 0x20}, //ZBITSCAN_EVFY_MLC=Disable
        {0x134, 0x00, 0x30}, //SKIPEVFY_MLC=0 loop
        {0x05A, 0x40, 0xC0}, //DVERA_MLC=0.2V 
        {0x026, 2,    MINUS|0x1F}, //VCG_ERV=-2 DAC
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Erase_SP(0,TOTAL_BLK,MARKBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
