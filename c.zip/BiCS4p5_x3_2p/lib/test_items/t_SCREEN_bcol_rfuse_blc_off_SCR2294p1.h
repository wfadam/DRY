uint8 t_SCREEN_bcol_rfuse_blc_off_SCR2294p1(void) //tb_175_nvcc
{
    uint8 die = 0;

    FOR_EACH_DIE(die)
    {
        if(BCOL_Romfuse_BLC_Off(die, BIT_IGNORE_8)!= 0) 
        {	
            Print_Die_Failure_Add_BD(die, "");
        }
    }	
    
     return(PF_Check());
}
