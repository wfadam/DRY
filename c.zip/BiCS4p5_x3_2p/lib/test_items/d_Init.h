uint8 d_Init(void)
{
    g_Update_Para_Array_En = 0;
    g_Incoming_Para_Scan_En = 0;
    Current_Die=0xFF;
    g_BuFF_Prt = (uint8 *)SETBUF(0);

    Reset_Select_BB_Map(MAIN);
    Reset_Select_BB_Map(TEMP);
    Reset_Temp_BC_Array();
    Reset_Die_Map(MAIN);
    Reset_Die_Map(TEMP);


    Print_Init_Info();

    Product_Init();

    return(PF_Monitor());
}
