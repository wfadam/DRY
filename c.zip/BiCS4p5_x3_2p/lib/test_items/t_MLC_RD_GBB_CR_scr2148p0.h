uint8 t_MLC_RD_GBB_CR_scr2148p0(void)  // tb_409 nvcc
{
    MLC_Read_6D(0, TOTAL_BLK, MARKBB, IGN_BITS_SCR2148P0, SET_AB);

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = GBB_LIMIT_SCR2148P0; 
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
