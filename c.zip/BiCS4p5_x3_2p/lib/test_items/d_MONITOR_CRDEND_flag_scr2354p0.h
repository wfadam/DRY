uint8 d_MONITOR_CRDEND_flag_scr2354p0(void) //tb_217 nvcc
{
    uint8 die, loop, vdd_shift = 4;
    uint16 Mask[2] = {PLUS, MINUS}; //VDD+/-4DAC

    FOR_EACH_LOOP(loop, 0, 2, 1)
    {
        FOR_EACH_DIE(die)
        {
            CRD_Flag_Check(die, vdd_shift, Mask[loop]);
        }
    }

    POR_CHECK_ALL_DIE;

    return(PF_Monitor());
}
