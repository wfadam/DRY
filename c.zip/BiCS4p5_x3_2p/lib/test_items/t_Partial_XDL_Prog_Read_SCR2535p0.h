uint8 t_Partial_XDL_Prog_Read_SCR2535p0() //tb_833 nvcc SCR997p0
{
    uint8 i = 0, die;
 
    Para_Table Para_Array[2][1]=
    {
        {{0x0DE, 4, PLUS|0x1F}}, 
        {{0x0DE, 4, MINUS|0x1F}},
    };

    TM_Entry();

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(i, 0, 2, 1) // loop for 2 parameter condition
        {
            SET_PARAMETERS(die, Para_Array[i]);

            if(Partial_XDL_Prog_Read(die, BIT_IGNORE_2)) Print_Die_Failure_Add_BD(die, "");

            RESET_PARAMETERS(die, Para_Array[i]);
        }
    }

    TM_Exit();

    return(PF_Check());
}