uint8 t_SCREEN_sgsb_lowVT_scr1853p2(void) //tb_628 nvcc SCR1087p2
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB
    
    VSGS_VSGD_Detection_2A(SGSB, LOW_VT, 500, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E); //VCGRV = 0.5V

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
