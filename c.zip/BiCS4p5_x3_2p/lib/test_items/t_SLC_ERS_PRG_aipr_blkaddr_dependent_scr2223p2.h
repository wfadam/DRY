uint8 t_SLC_ERS_PRG_aipr_blkaddr_dependent_scr2223p2(void) //tb_275 nvcc SCR2223p0
{
    uint8 Loop = 0;
    uint16 blk = 0;

    Para_Table Para_Array[] = 
    {
        {0x0AB, 0x08, 0x08}, //enable ocs6D to enable every string have different random data in same wl.
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    FOR_EACH_LOOP(Loop, 0, 0xF, 2)
    {
        SLC_Erase(Loop, Loop+1,MARKBB);
        SLC_Program_6DBB(Loop, Loop+1, MARKBB, DONOT_SET_AB);

        FOR_EACH_LOOP(blk, Loop+0x10, TOTAL_BLK, 0x10)
        {
            if((THROTTLE_PRODUCT == THROTTLE)&&((blk-Loop)%0x400==0))
            {
                print(0,"B@:", blk);
                Cool_temp(90, 1);
            }

            SLC_Erase(blk, blk+1,MARKBB);
            SLC_Program_6DBB(blk, blk+1, MARKBB, DONOT_SET_AB);
            SLC_AIPR_Read_6DBB(blk-0x10, blk-0x0F, MARKBB, IGN_BITS_SLC, DONOT_SET_AB);
        }
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN=25;
    GBB_limit.MarkBB=MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
