uint8 t_MLC_RD_ERS_aipr_AllDies_scr2224p4(void) //tb_398 nvcc SCR2224p2
{
    uint16 blk = 0;

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {0x137,       BSPF_EV_MLC_SET, BSPF_EV_MLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    FOR_EACH_LOOP(blk, 0, TOTAL_BLK, TOTAL_PLN)
    {
        MLC_AIPR_Read_6EBB(blk, blk+1, MARKBB, IGN_BITS_MLC);
        MLC_Erase(blk, blk+1, MARKBB);
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;
    
    return(PF_Check());
}

