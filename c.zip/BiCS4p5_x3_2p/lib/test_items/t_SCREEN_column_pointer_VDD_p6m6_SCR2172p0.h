uint8 t_SCREEN_column_pointer_VDD_p6m6_SCR2172p0(void)  //tb214 scr1148p1 nvcc
{
    uint8 i,die;
    char *latch_name[2] = {"Column_Pointer_VDD_MINUS6", "Column_Pointer_VDD_PLUS6"};
    Para_Table Para_Array[2][1]=
    {
        {{0x0DE, 6, MINUS|0x1F}},
        {{0x0DE, 6, PLUS|0x1F}},                                       
    };

    FOR_EACH_LOOP(i,0,2,1)
    {
        FOR_EACH_DIE(die)
        {
            POR_From_RF(die, 0, DONOT_USE_4C);
            SET_PARAMETERS(die, Para_Array[i]);         

            if(Column_Pointer_Random(die)!=0)
            {
                Print_Die_Failure_Add_BD(die, latch_name[i]);
            }

            RESET_PARAMETERS(die, Para_Array[i]);
            POR_From_RF(die, 0, USE_4C);
        }
    }
    return(PF_Check());
}
