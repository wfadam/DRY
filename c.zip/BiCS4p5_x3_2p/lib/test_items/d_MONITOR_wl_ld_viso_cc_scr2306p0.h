uint8 d_MONITOR_wl_ld_viso_cc_scr2306p0(void) //tb_497 nvcc SCR1887p2
{
    uint8 die, Org_41, Param_Flag;
    int value=0;
    uint16 majority_outgoing = 0x100;
    Majority_Vote vote_array_temp;

    Para_Table Para_Array[] =
    {
        {0x041, 0x00, 0x7F},
        {0x002, 0x40, 0xC0}, // F_TESTTEMP=1
        {0x00C, 0x80, 0x80}, // F_WLDL_VISO=1
        {0x118, 0x08, 0x08}, // F_WLLD_EN=1
        {0x119, 0x00, 0x0C}, // F_PPNPPE_MLC/SLC=0
        {0x117, 0x00, 0x30}, // F_PAP_ERASE=0
        {0x118, 0x10, 0x10}, // F_WLLD_N0ERA=1
        {0x12F, 0x01, 0x0F}, // F_NLE_MLC=1 (Erase loop max. for MLC)
        {0x12F, 0x10, 0xF0}, // F_NLE_SLC=1 (Erase loop max. for MLC)
        {0x0AD, 0x28, 0x38}, // F_WLLD_CC_LDCLK=665.36us (LD_CLK timing during WLLD Clock Count mode)
        {0x0AE, 0x20, 0x3C}, // F_WLLD_IDT= 250nA
        {0x0AE, 0x03, 0x03}, // F_WLLD_ICM= 2000nA
        {0x0AE, 0x00, 0xC0}, // F_WLLD_ICS_RANGE= 50nA
        {0x12C, 0x00, 0x08}, // F_HR_EN=0 //Disable auto H-IVR
        {0x12C, 0x00, 0x10}, // F_HR_EN_ERASE=0 //Disable auto H-IVR
        {0x011,    7, PLUS|0x3F}, // SDE Address  0x11[5:0] =70ns Default and +8DAC (decimal) = 80ns
    };

    FOR_EACH_DIE(die)
    {        
        Org_41 = Get_Param(die, 0x41);
        value = Org_41;

        vote_array_temp = Read_DS_and_Majority_Vote(die, 1, 13, 2, 0x266);
        Param_Flag = 0;

        if(vote_array_temp.win_flag && (vote_array_temp.vote_cnt >= 2))
        {
            majority_outgoing = vote_array_temp.vote_value;
            if((majority_outgoing >= (Org_41 - 40)) && (majority_outgoing <= (Org_41 + 40)))
            {
                value = majority_outgoing+15;
                Param_Flag = 1;
            }
        }
        
        if(Param_Flag == 0)
        {
            value = Org_41 - 13;
        }
        
        if(value >= 0)
        {
            Para_Array[0].value = value;
        }
        else
        {
            Para_Array[0].value = 0;
            print(0, "D@ P41 is-, set 0\n", die);
        }
        
        SET_PARAMETERS(die, Para_Array);
    }

    WL_Dummy_Read(DONOT_USE_DD);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
