uint8 d_SLC_PRG_stamp_SH_scr2169p0(void) //tb_816 nvcc SCR542p6
{
    uint16 col_shift = 0x480;
    uint8 sh_stamp_col = 0x08*TOTAL_DIE, copy;

    if(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR, sh_stamp_col, BIT_IGNORE_10, 0xAA, BYTE_8) == DONOT_EXIST)
    {
        FOR_EACH_LOOP(copy, 0, 16, 1) //Each page has 16 copies every 0x480 shift
        {
            Program_Stamp_In_Range(0, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_WL+1, SH_STAMP_STR, SH_STAMP_STR+1, sh_stamp_col+col_shift*copy, BYTE_8);
        }
    }
    else
    {
        print(0, "Has Stamp,Skip\n");
    }

    return(PF_Monitor());
}
