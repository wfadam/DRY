uint8 t_SCREEN_xdl_cmd32_cmdca_scr2119p0(void)//tb__200 nvcc Bics4-SCR875p1
{
    uint8 die=0;
    uint16 good_blk = 0;

    FOR_EACH_DIE(die)
    {
       good_blk = Search_Pair_Blk_BBMap_Erase_by_Die(die,0,TOTAL_BLK,TOTAL_PLN,PAIR_1,SLC_ERASE);
       if(good_blk != TOTAL_BLK)
       {
           SLC_Program_CMD2A_String0(die, good_blk, good_blk+TOTAL_PLN);
           if(Data_Latch_CMD32(die, good_blk)!=0)
           {
               Print_Die_Failure_Add_BD(die, "");
           }
           
           SLC_Erase_by_Die(die, good_blk, good_blk+1, DONOT_MARKBB);
       }
    }

    return(PF_Check());
}
