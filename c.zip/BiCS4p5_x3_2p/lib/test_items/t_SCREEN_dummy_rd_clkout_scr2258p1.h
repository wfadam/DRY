uint8 t_SCREEN_dummy_rd_clkout_scr2258p1()    //tb__215 nvcc BICS4 SCR2086p1
{

    uint8 die=0, pln=0;
    uint16 good_blk=0;

    Para_Table Para_Array[] =
    {
        {0xDE, 7, MINUS|0x1F},//VDD -7DAC
    };


    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_by_Die(die, 0x20, TOTAL_BLK, TOTAL_PLN, PAIR_1);

        if(good_blk != TOTAL_BLK)
        {

            SLC_Erase_2A_by_Die(die, good_blk, good_blk+1, DONOT_MARKBB);
            SLC_Program_Scramble_By_Die(die, good_blk, good_blk+1, DONOT_MARKBB, PRINT_FAIL);

            SET_PARAMETERS(die, Para_Array);

            FOR_EACH_PLN(pln)
            {
                if(SLC_Read_SP_Scramble_By_Die_DLY40ms(die,good_blk+pln)!=0)
                {
                    Print_Die_Failure_Add_BD(die, "");
                }
            }

            RESET_PARAMETERS(die, Para_Array);
        }
    }

    return(PF_Check());

}
