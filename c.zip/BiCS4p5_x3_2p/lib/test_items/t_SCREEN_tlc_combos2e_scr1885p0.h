uint8 t_SCREEN_tlc_combos2e_scr1885p0(void) //tb_520_nvcc scr908p6
{   
    Para_Table Para_Array[] =
    {   
        {0x137, 0x04, 0x07}, //BSPF_EV_MLC[2:0] = 32(h04) bits
        {0x12F, 0x04, 0x0F}, //NLE_MLC[3:0] = 4(h05) loops (default = 10 loops

    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Erase_SP(0,TOTAL_BLK,MARKBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}