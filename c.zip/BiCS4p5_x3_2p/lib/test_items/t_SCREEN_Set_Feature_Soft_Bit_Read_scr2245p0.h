uint8 t_SCREEN_Set_Feature_Soft_Bit_Read_scr2245p0(void) //tb_753 nvcc SCR1505p0
{
    uint8 FailFlag = 0, die;
    uint16 GoodBlk;

//CC: Double check the feature value array when you try to change it.

//SBR-DAC: 92/93 -> -1000mV (B0)
//Shift SBR-DAC:        B0 ->A,     B1->C,      B2->E,      B3->G
    uint32 SBR_92[4] = {0x000000B0, 0x0000B000, 0x00B00000, 0xB0000000};
//Shift SBR-DAC:        B0 ->B,     B1 ->D,     B2 ->F
    uint32 SBR_93[3] = {0x000000B0, 0x0000B000, 0x00B00000};

//SBR+DAC: 94/95 -> +1000mV (50)
//Shift SBR+DAC:        B0 ->A,     B1->C,      B2->E,      B3->G
    uint32 SBR_94[4] = {0x00000050, 0x00005000, 0x00500000, 0x50000000};
//Shift SBR+DAC:        B0 ->B,     B1 ->D,     B2 ->F
    uint32 SBR_95[3] = {0x00000050, 0x00005000, 0x00500000};

    uint8 SBR_ACEG_Status[4][7] =
    {
//       A     B     C     D     E     F     G
        {0xE1, 0xE0, 0xE0, 0xE0, 0xE0, 0xE0, 0xE0}, //A
        {0xE0, 0xE0, 0xE1, 0xE0, 0xE0, 0xE0, 0xE0}, //C
        {0xE0, 0xE0, 0xE0, 0xE0, 0xE1, 0xE0, 0xE0}, //E
        {0xE0, 0xE0, 0xE0, 0xE0, 0xE0, 0xE0, 0xE1}, //G
    };
    uint8 SBR_BDF_Status[3][7] =
    {
//       A     B     C     D     E     F     G
        {0xE0, 0xE1, 0xE0, 0xE0, 0xE0, 0xE0, 0xE0}, //B
        {0xE0, 0xE0, 0xE0, 0xE1, 0xE0, 0xE0, 0xE0}, //D
        {0xE0, 0xE0, 0xE0, 0xE0, 0xE0, 0xE1, 0xE0}, //F
    };

    uint8 SBR_92_cnt = sizeof(SBR_92)/sizeof(SBR_92[0]);
    uint8 SBR_93_cnt = sizeof(SBR_93)/sizeof(SBR_93[0]);
    uint8 SBR_94_cnt = sizeof(SBR_94)/sizeof(SBR_94[0]);
    uint8 SBR_95_cnt = sizeof(SBR_95)/sizeof(SBR_95[0]);

    //Search 1 pair of good block
    GoodBlk = Search_Pair_Blk_BBMap_AllDie(0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1);

    if(GoodBlk != TOTAL_BLK)
    {
        
        MLC_Erase(GoodBlk, GoodBlk+1, DONOT_MARKBB);
        MLC_Program_6D_2A(GoodBlk, GoodBlk+1, DONOT_MARKBB, SET_AB);

        FOR_EACH_DIE(die)
        {
            FailFlag |= Set_Get_Feature_Single_State_SBR_Read(die, GoodBlk, SBR_92, SBR_92_cnt, 0x92, *SBR_ACEG_Status);
            FailFlag |= Set_Get_Feature_Single_State_SBR_Read(die, GoodBlk, SBR_93, SBR_93_cnt, 0x93, *SBR_BDF_Status);
            FailFlag |= Set_Get_Feature_Single_State_SBR_Read(die, GoodBlk, SBR_94, SBR_94_cnt, 0x94, *SBR_ACEG_Status);
            FailFlag |= Set_Get_Feature_Single_State_SBR_Read(die, GoodBlk, SBR_95, SBR_95_cnt, 0x95, *SBR_BDF_Status);

            if(FailFlag != 0)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }
    }

    return(PF_Check());
}
