uint8 t_SCREEN_SLC_Cache_Program_Minus2_SCR10590p0() //tb__842 nvcc SCR983.2
{
    uint8 die;
    uint16 gb;

    Para_Table Para_Array[] =
    {
        {0xDE,    2, MINUS|0x1F},  //Set VDD-2DAC 
    };

    TM_Entry();

    FOR_EACH_DIE(die)
    {
    
        gb = Search_Pair_Blk_BBMap_Erase_by_Die(die, 0, TOTAL_BLK, TOTAL_PLN, PAIR_4 ,SLC_ERASE);

        if(gb != TOTAL_BLK)
        {
            SET_PARAMETERS(die, Para_Array);
            SLC_Cache_Program_Scramble_By_Die(die, gb, gb+8);
            SLC_Read_Scramble_By_Die(die, gb, gb+8, IGN_BITS_SLC);
            RESET_PARAMETERS(die, Para_Array);
        }
    }

    TM_Exit();

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN=0;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 
    
    return(PF_Check());
}
