uint8 t_MLC_ERS_PRG_sample_SCR2208p1(void) // tb_302 lvcc
{
    GBB_Check_Init(GBB_limit);

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {NLP_MLC_ADR, NLP_MLC_SET, NLP_MLC_MASK},
        //{0x133,0x00,0x1F},//CHECK fail condition;
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Erase_2A(MLC_EP_G0_START, MLC_EP_G0_END,MARKBB);
    MLC_B2_Program_6D_2A(MLC_EP_G0_START, MLC_EP_G0_END,MARKBB, SET_AB);

    MLC_Erase_2A(MLC_EP_G1_START, MLC_EP_G1_END,MARKBB);
    MLC_B2_Program_6D_2A(MLC_EP_G1_START, MLC_EP_G1_END,MARKBB, SET_AB);

    MLC_Erase_2A(MLC_EP_G2_START, MLC_EP_G2_END,MARKBB);
    MLC_B2_Program_6D_2A(MLC_EP_G2_START, MLC_EP_G2_END,MARKBB, SET_AB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_limit.GBB_CHECK_PLN=4;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 

    return(PF_Check());
}