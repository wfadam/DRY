uint8 d_MONITOR_SLC_RD_rf_vt_Upper_scr2156p0(void) //tb_939 nvcc SCR1190p1
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Romblock_Vt_Upper_Tail(die, 0xC0, 0x01, BIT_IGNORE_16) != PASS) //Criteria: 5.6V, 16bits/K
        {
            Print_Die_Failure(die, "");
        }
    }

    return(PF_Monitor());
}
