uint8 t_MLC_ERS_PRG_efr_scr2393p0_100Cycle(void) //tb_320 nvcc
{
    uint8 loop = 0, cycle;

    g_CMDB2_FLAG = CMDB2_ENABLE;

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {NLP_MLC_ADR, NLP_MLC_SET, NLP_MLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    FOR_EACH_LOOP(loop, 0, 10, 1)
    {
        print(0, "Cycle ~\n", loop*10); //Every 10 cycle program the EP stamp and print GBB.

        if(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, EFR_CYCLE_STAMP_WL, EFR_CYCLE_STAMP_STR, EFR_EP_CYCLE_STAMP_COL+loop*BYTE_8, BIT_IGNORE_10, 0xAA, BYTE_8) == DONOT_EXIST)
        {
            FOR_EACH_LOOP(cycle, 0, 10, 1)
            {
                MLC_Erase(0, TOTAL_BLK, MARKBB);
                MLC_Program_6E_2A(0, TOTAL_BLK, MARKBB);
            }

            GBB_MONITOR_PRINT;
            Reset_Select_BB_Map(TEMP);

            Program_UR_Stamp_4C(0, MTST_UROM_BLK0, EFR_CYCLE_STAMP_WL, EFR_CYCLE_STAMP_STR, EFR_EP_CYCLE_STAMP_COL+loop*BYTE_8, BYTE_8);

            if(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, EFR_CYCLE_STAMP_WL, EFR_CYCLE_STAMP_STR, EFR_EP_CYCLE_STAMP_COL+loop*BYTE_8, BIT_IGNORE_10, 0xAA, BYTE_8) == DONOT_EXIST)
            {
                Print_Die_Failure_Add_BD(0, "Read stamp");
            }
        }
        else
        {
            print(0, "Stamp exists, skip\n");
        }

        CST_Data_Log_Update();
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);
 
    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
