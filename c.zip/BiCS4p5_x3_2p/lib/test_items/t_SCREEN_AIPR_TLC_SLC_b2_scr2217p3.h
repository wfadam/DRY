uint8 t_SCREEN_AIPR_TLC_SLC_b2_scr2217p3(void)  // tb_752 nvcc SCR2217p2
{
    uint8 die;
    g_CMDB2_FLAG = CMDB2_ENABLE;

    FOR_EACH_DIE(die)
    {
        TLC_SLC_AIPR_Read_Sample_BLK_WL_STR_Delay(die, BIT_IGNORE_16, IGN_BITS_TLC_SCR2217P2);  // Bit ignore: SLC can be hard coded(according to SCR)
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 4;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    g_CMDB2_FLAG = CMDB2_DISABLE;
    
    return(PF_Check());
}
