uint8 t_SCREEN_sgd_leak_cc_scr1983p2(void) //tb_483 nvcc Base on SCR1131.6
{
    Para_Table Para_Array[] =
    {
        {0x002, 0x40, 0xC0},  //F_TESTTEMP=2'b01
        {0x00C, 0x02, 0x02},  //WL_WL leakage=0 and SGS/SGSB leakage=1
        {0x0B8, 0x00, 0xF0},  //F_VSGDPCH=3.0 to avoid disturb on SGD (SGD Spike Countermeasure)  
        {0x118, 0x00, 0x02},  // WL2SUBLD_EN    118[1] WL2SUBLD_EN => Disable
        {0x118, 0x04, 0x04},  // WL2WLLD_EN     118[2] WL2WLLD_EN => Enable
        {0x118, 0x08, 0x08},  // WLLD_EN        118[3] WLLD_EN => Enable
        {0x118, 0x10, 0x10},  // WLLD_NOERA     118[4] WLLD_NOERA => Enable to not perform Erase after WLLD 
        {0x118, 0x20, 0x20},  // WLLD_WAY       118[5] Auto WL2WL stress mode half WLs stress control: Half Wls
        {0x118, 0x00, 0xC0},  // WLLD_CC_CSTEP  118[7:6] VPGM level during WLLD Clock Count mode (0: direct from VPGM)
        {0x117, 0x00, 0x30},  // PAP_ERASE      117[5:4] To check WL#/Str3 if block is Partially Programmed  for normal block -> 0: disable, 1: Wl64, 2:WL80, 3:WL95 
        {0x119, 0x00, 0x04},  // PPNPPE_MLC 119[2] Pre program befor Erase(MLC) 0:disable 1:Enable 
        {0x119, 0x00, 0x08},  // PPEPPN_SLC 119[3] Pre program befor Erase(SLC) 0:disable 1:Enable
        {0x0AD, 0x38, 0x38},  // WLLD_CC_LDCLK      AD[5:3] if PVLD_PARAM =0 WLLD_CC_LDCLK => 2621.44us; LD_CLK timing during WLLD Clock Count Mode, this should be set to not zero value 
        {0x084, 0xE0, 0xE0},  // WL Equalization(PR8)   84[7:5]   if TM_HALF_RR_PR == 0: PR8=9.04 us(Max). BICS4.5 removed TM_HALF_RR_PR so without clock overload value is 4.56us
        {0x083, 0x60, 0xF0},  //  F_PD1_WLLD          83[7:4]PD1_WLLD => 1096.64usec (PD1 timing during WLLD, this parameter setting is to minimize the WL-RC effect on program cells)
        {0x0AE, 0x00, 0x03},  // WLLD_ICM          AE[1:0] WLLD Common Mode Current =500nA
        {0x0AE, 0x10, 0x3C},  // WLLD_IDT          AE[5:2] WLLD Detect Mode Current =125nA
        {0x0AE, 0xC0, 0xC0},  // WLLD_ICS_RANGE    AE[7:6] WLLD ICS step option=     12.5nA (default)  
        {0x0AD, 0x00, 0xC0},  //  WLLD_HIGH_CUR    AD[7:6] High Current Detection for WLLD = 2uA, this is used for unselected blocks as a countermeasure for 1st Read Issue
        {0x043, 0xE0, 0xE0},  // VISO1 voltage to VSS (disabled)              73[7:5] Set to VSS(111)
        {0x0DF, 0x60, 0x60},  // WL2WL/SGLD RETAIL BOOST to stablize REFDAC DF[6:5] Set to 11 (x10)
        {0x04C, 0x00, 0xC0},  //  F_PROGSRC_WLLD                    49[7:6] Set to VSS CELSRC voltage during WLLD     
        {0x052, 0x00, 0xF0},  // INC_VPGM_WL2WL     52[7:4] Adjust VPGM DAC i.e., DAC shift from Trimmed VPGM =0.0V 
        {0x100, 0x00, 0x01},  //  BL_BIAS_STRPCG    100[0]  BL bias for Leakage Detection, Set to VSS 0:VSS and 1:VDDSA
        {0x104, 0x80, 0x80},  //  SGS_OFF       104[7]  SGS/SGSB=VSS fix (uncomment this parameter for SGD LD only; for SGS LD comment this out)
        {0x105, 0x80, 0x80},  //  SGSB_OFF      105[7]   [test] SGSB =VSS fix 0: disable and 1: enable
 //To make PR8 CLK => 9.04
        {0x00F, 0x10, 0x10},  //F_TMOL_EN=1'b1
        {0x006, 0x07, 0xFF},  //Overload CLK8
        {0x007, 0x11, 0xFF},  //Overload PR_CLK
        {0x008, 0x71, 0xFF},
        {0x009, 0x00, 0xFF},
        {0x00A, 0x00, 0x01},

        {0x046, 0x24, 0xFF},   //VPGMU=7V 46h[7:0]=24h
        {0x011, 7,    PLUS|0x3F}, //SDE = default(71.6ns) + 7DAC = 80ns
    };

    Reset_All_BBlk();

    SET_PARAMETERS_ALL_DIE(Para_Array);

    SGS_SGD_Leakage(SGD_LEAK, SINGLE_PLN);
    BB_Check_EOC(0, TOTAL_BLK, 3, 4, TEMP);

    FULLARRAY_BB_CHECK;

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
