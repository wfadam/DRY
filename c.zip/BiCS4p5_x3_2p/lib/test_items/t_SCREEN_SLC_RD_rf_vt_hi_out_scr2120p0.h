uint8 t_SCREEN_SLC_RD_rf_vt_hi_out_scr2120p0(void) //tb__938 nvcc SCR968.5
{
    uint8 die = 0;

    FOR_EACH_DIE(die)
    {
        if(Outgoing_RomFuse_Vt(die, 0x80, DONOT_USE_4C)!=0) // VCGR_SLCR -1.6V (80h)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
