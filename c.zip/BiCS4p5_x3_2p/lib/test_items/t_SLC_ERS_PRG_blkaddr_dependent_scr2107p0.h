uint8 t_SLC_ERS_PRG_blkaddr_dependent_scr2107p0()   //tb_271 nvcc SCR1186p2
{

    SLC_Erase_Program(THROTTLE_PRODUCT);
    
    FULLARRAY_BB_CHECK;
    return(PF_Check());
}