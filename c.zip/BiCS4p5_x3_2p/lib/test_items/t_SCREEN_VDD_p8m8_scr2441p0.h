uint8 t_SCREEN_VDD_p8m8_scr2441p0(void) //tb_442 nvcc
{
    uint8 loop;

    Para_Table Para_Array[2][1] =
    {
        {0x0DE,	8,  PLUS|0x1F}, //VDD+8DAC
        {0x0DE, 8, MINUS|0x1F}, //VDD-8DAC
    };

    MLC_Margin_Erase();

    FOR_EACH_LOOP(loop, 0, 2, 1)
    {
        SET_PARAMETERS_ALL_DIE(Para_Array[loop]);

        Margin_Block_Check(BIT_IGNORE_150);

        RESET_PARAMETERS_ALL_DIE(Para_Array[loop]);
    }

    MLC_Margin_Erase();

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 4;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
