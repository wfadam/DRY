uint8 t_SCREEN_wl_li_ld_scr1997p1(void) //tb_481 nvcc SCR1384p3
{
    Para_Table Para_Array[] =
    {
        {0x0B8, 0x00, 0xF0},  //  VSGDPCH = 3.0V
        {0x0C2, 0x20, 0xF0},  //  Unselcted WL Voltage (VPASS2 Generator)
        {0x12B, 0x00, 0x40},  //  WLDD1/DU/DL/DS1 = WLLD_USEL
        {0x100, 0x00, 0x01},  //  BL_BIAS_STRPCG = "BL=VSS"
        {0x04C, 0x00, 0xC0},  //  PROGSRC_WLLD = VSS
        {0x104, 0x80, 0x80},  //  SGS_OFF = 1(SGS = VSS fix)
        {0x105, 0x80, 0x80},  //  SGSB_OFF = 1(SGSB = VSS fix)
        {0x083, 0xF0, 0xF0},  //  PD1_WLLD = 2571.2us(max) @ SDE=80ns
        {0x0AD, 0x00, 0x38},  //  WLLD_CC_LDCLK = Clock Count Mode Disable
        {0x0AE, 0x24, 0x3C},  //  WLLD_IDT 0x24=500nA, 0x2C=1000nA, 0x30 = 1250nA, 0x34 =1500nA, 0x38=1750nA , 0x3C =2000nA
        {0x0AE, 0x01, 0x03},  //  WLLD_ICM = 1000nA 2,3
        {0x0AE, 0xC0, 0xC0},  //  WLLD_ICS_RANGE = 12.5nA 1,2,3
        {0x118, 0x00, 0x04},  //  WL2WLLD_EN = Disable
        {0x118, 0x02, 0x02},  //  WL2SUB_EN = Enable
        {0x12B, 0x00, 0x80},  //  F_WLD_WL2SUB= Disable
        {0x052, 0x00, 0x0F},  //  INC_VPGM_WL2SUB = 0.0 V
        {0x118, 0x08, 0x08},  //  WLLD_EN = Enable
        {0x118, 0x10, 0x10},  //  WLLD_NOERA = No Erase
        {0x117, 0x00, 0x30},  //  PAP_ERASE = disable
        {0x119, 0x00, 0x08},  //  PPNPPE_SLC = Disable
        {0x119, 0x00, 0x04},  //  PPNPPE_MLC = Disable
        {0x118, 0x20, 0x20},  //  WLLD_WAY = 1 (Half WLs)
        {0x084, 0xE0, 0xE0},  //  PR8 = 4.56us(max) @ SDE=80ns
        {0x0DF, 0x60, 0x60},  //  WL2WL_REFTAIL_BOOST = "x10" to stabilize REFDAC
        {0x002, 0x40, 0xC0},  //  F_TESTTEMP = 2`b01
        {0x00F, 0x10, 0x10},  //  F_TMOL_EN = 1`b1
        {0x006, 0x07, 0xFF},  //  Overload CLK8
        {0x007, 0x11, 0xFF},  //  Overload PR_CLK
        {0x008, 0x71, 0xFF},  // DAC = 00 00 71 H
        {0x009, 0x00, 0xFF},
        {0x00A, 0x00, 0x01},  //Need to double confirm that //TODO
        {0x011, 7,    PLUS|0x3F},  // SDE Address  0x11[5:0] =70ns Default and +7DAC (decimal) = 80ns
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    WL_WL_Leakage_Dummy_Read(DONOT_USE_DD, DONOT_EVEN_ODD_WL);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
