uint8 t_SCREEN_Latch_Corruption_Screen_TLC_Read_SCR10670p0(void)//tb_858 nvcc SCR1232p4
{
    Para_Table Para_Array[] =
    {
        {0x0DE, 4, MINUS|0x1F},  // VDD - 4DAC
    };

    TM_Entry();

    TLC_Read_Latch_Corruption(BIT_IGNORE_1, Para_Array, sizeof(Para_Array) / sizeof(Para_Table));

    TM_Exit();

    return(PF_Check());   
}
