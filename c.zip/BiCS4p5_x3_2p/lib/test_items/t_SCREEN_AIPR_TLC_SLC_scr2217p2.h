uint8 t_SCREEN_AIPR_TLC_SLC_scr2217p2(void)  // tb_752 nvcc SCR-1540.3
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        TLC_SLC_AIPR_Read_Sample_BLK_WL_STR_Delay(die, BIT_IGNORE_16, IGN_BITS_TLC_SCR2217P2);  // Bit ignore: SLC can be hard coded(according to SCR)
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 4;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
