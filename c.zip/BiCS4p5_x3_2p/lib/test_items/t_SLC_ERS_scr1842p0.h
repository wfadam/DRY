uint8 t_SLC_ERS_scr1842p0(void)//tb__330-335 nvcc
{
    Para_Table Para_Array[] =
    {
        {NLE_SLC_ADR, NLE_SLC_SET, NLE_SLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    SLC_Erase(0, TOTAL_BLK, MARKBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
