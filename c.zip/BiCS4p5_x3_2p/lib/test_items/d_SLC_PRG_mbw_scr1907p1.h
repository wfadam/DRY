uint8 d_SLC_PRG_mbw_scr1907p1(void)  //tb__250-259 tb__280-289 nvcc
{
    FLASH_WRITE;

    return(PF_Monitor());
}
