uint8 t_SCREEN_TLC_RD_cache_cmd2b_scr2160p1_WO_TM(void)  // tb_782 nvcc Base on SCR1004.0
{
    //SCR requirement: if possible, do the screen in toggle mode
    uint8 die;
    uint16 good_blk;
   
    Para_Table Para_Array[] =
    {
        {0x11,    2,  PLUS|0x3F},  //Set SDE+2DAC
        {0xDE,    4, MINUS|0x1F},  //Set VDD-4DAC
    };

    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_by_Die(die, 0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1);
        if(good_blk != TOTAL_BLK)
        {

			MLC_Erase_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);

			SET_PARAMETERS(die, Para_Array);

			MLC_Program_Scramble_By_Die(die, good_blk, good_blk + 2, MARKBB, PRINT_FAIL);
			MLC_Cache_Read_2B_Scramble_By_Die_100bytes_WO_TM(die, good_blk, good_blk + 2, BIT_IGNORE_10);

			RESET_PARAMETERS(die, Para_Array);
        }
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = 0;
    GBB_limit.MarkBB = MARKBB;
    GBB_Check(GBB_limit);
		
    return(PF_Check());
}
