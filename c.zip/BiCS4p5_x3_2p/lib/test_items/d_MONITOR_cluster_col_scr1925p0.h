uint8 d_MONITOR_cluster_col_scr1925p0(void)  // tb__169 nvcc Base on BICS3 d_Cluster_Column_Screen
{
    uint8 die, pln, BC_Count = 0;
    uint16 *P_Buff_BC = (uint16 *)g_Temp_Col;
    uint16 col, i;

    FOR_EACH_DIE(die)
    {
        FOR_EACH_PLN(pln)
        {
            BC_Count = 0;
            FOR_EACH_LOOP(i, 0, BC_LIMIT_PER_PLN * 4, 1)
            {
                *(P_Buff_BC + i) = 0xFFFF;
            }

            Sub_Read_BC_Info(die, pln);
          
            // //save bad column addr to BC_MAP
            FOR_EACH_LOOP(col, 0, TOTAL_COL, 1)
            {
                if((*(g_BuFF_Prt + col) & 0x01) && (BC_Count < (BC_LIMIT_PER_PLN * 2)))
                {
                    P_Buff_BC[BC_Count] = col;
                    BC_Count++;
                }
            }
            
            Cluster_BC_Count(die, pln, P_Buff_BC, BC_Count);
        }
    }

    return(PF_Monitor());
}
