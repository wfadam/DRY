uint8 t_SLC_RD_00_data_scr1947p0(void)//tb__392 nvcc
{
    SLC_Read_Pattern_2A(0, TOTAL_BLK, ALL00, IGN_BITS_SLC_ALL00);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
