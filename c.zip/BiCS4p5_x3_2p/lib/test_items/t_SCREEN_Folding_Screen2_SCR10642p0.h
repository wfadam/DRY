uint8 t_SCREEN_Folding_Screen2_SCR10642p0(void)  // tb_856 nvcc base on SCR818.3
{
    uint16 slc_source_block_list[3];
    uint16 mlc_source_block;
    uint8 i,die;

    FOR_EACH_DIE(die)
    {
        //Search 3 pair of SLC source blocks and 1 pair of MLC 
        slc_source_block_list[0] = Search_Pair_Blk_BBMap_by_Die(die, 0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1);
        slc_source_block_list[1] = Search_Pair_Blk_BBMap_by_Die(die, slc_source_block_list[0] + 2, TOTAL_BLK, TOTAL_PLN, PAIR_1);
        slc_source_block_list[2] = Search_Pair_Blk_BBMap_by_Die(die, slc_source_block_list[1] + 2, TOTAL_BLK, TOTAL_PLN, PAIR_1);
        mlc_source_block = Search_Pair_Blk_BBMap_by_Die(die, slc_source_block_list[2] + 2, TOTAL_BLK, TOTAL_PLN, PAIR_1);

        if((slc_source_block_list[0] != TOTAL_BLK) && (slc_source_block_list[1] != TOTAL_BLK) && (slc_source_block_list[2] != TOTAL_BLK) && (mlc_source_block != TOTAL_BLK))
        {
            // from SCR script---Multi Plane Testing: Multiplane is done using non-2A command option to closely follow system implementation. Only good block search uses CMD 2A.
            FOR_EACH_LOOP(i, 0, 3, 1)
            {
                SLC_EPR_Scramble_By_Die(die, slc_source_block_list[i], slc_source_block_list[i] + 2, MARKBB, IGN_BITS_SLC);
            }
            MLC_Erase_By_Die(die, mlc_source_block, mlc_source_block + 2, MARKBB);
            
            // Folding
            Folding2_MLC_Program_By_Die(die, slc_source_block_list, mlc_source_block);
            Folding2_MLC_Read_By_Die(die, slc_source_block_list, mlc_source_block, IGN_BITS_SCR10642p0);

            FOR_EACH_LOOP(i, 0, 3, 1)
            {
                SLC_Erase_by_Die(die, slc_source_block_list[i], slc_source_block_list[i] + 2, MARKBB);
            }
            MLC_Erase_By_Die(die, mlc_source_block, mlc_source_block + 2, MARKBB);
        }
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = 0;
    GBB_limit.MarkBB=MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
