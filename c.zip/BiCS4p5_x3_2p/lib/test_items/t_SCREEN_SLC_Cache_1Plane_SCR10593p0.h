uint8 t_SCREEN_SLC_Cache_1Plane_SCR10593p0()//tb__843 nvcc SCR1000.0
{
    uint8 die;
    uint16 gb;

    Para_Table Para_Array[] =
    {
        {NLP_SLC_ADR, NLP_SLC_SET, NLP_SLC_MASK},
        {0xDE,    4, PLUS|0x1F},  //Set VDD+4DAC
        {0x16,    2, PLUS|0x1F},  //Set VDDSA+2DAC
        {0x17,    2, PLUS|0x1F},
    };

    TM_Entry();

    FOR_EACH_DIE(die)
    {
    
        gb = Search_Pair_Blk_BBMap_Erase_by_Die(die, 0, TOTAL_BLK, TOTAL_PLN, PAIR_1 ,SLC_ERASE);

        if(gb != TOTAL_BLK)
        {
            SET_PARAMETERS(die, Para_Array);

            SLC_Cache_Program_Scramble_SP_By_Die(die,gb,gb+2);
            SLC_Cache_Read_Scramble_Sample_Page_By_Die(die,gb,gb+2);

            RESET_PARAMETERS(die, Para_Array);
        }
    }

    TM_Exit();


    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN=0;
    GBB_limit.MarkBB=DONOT_MARKBB;
    GBB_Check(GBB_limit); 
    
    return(PF_Check());
}
