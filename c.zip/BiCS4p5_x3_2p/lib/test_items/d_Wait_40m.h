uint8 d_Wait_40m()
{
    return(Wait_Start_Signal(40));
}