uint8 t_SCREEN_column_pointer_SCR2163p0(void)//tb_213_nvcc
{   
    uint8 die = 0;
    
    FOR_EACH_DIE(die)
    {
        if(Column_pointer(die) != 0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }
    return(PF_Check());
}
