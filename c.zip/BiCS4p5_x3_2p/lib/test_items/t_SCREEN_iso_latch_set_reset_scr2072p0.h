uint8 t_SCREEN_iso_latch_set_reset_scr2072p0(void)//tb__211 nvcc 955p1
{
    uint8 die, FailFlag = 0;

    Para_Table Para_Array[] =
    {
        {0x010, 0x00, 0x02},
        {0x113, 0x00, 0x08},
        {0x113, 0x00, 0x04},  
        {0x111, 0x00, 0x10},    
    };

    FOR_EACH_DIE(die)
    {
        Scan_BC_To_Select_Array(die, g_Temp_BC, PREBCMASK, NOBC_PRINT);

        SET_PARAMETERS(die, Para_Array);

        FailFlag|= iso_Latch_Set(die);
        FailFlag|= iso_Latch_Reset_Set_BC(die);
        FailFlag|= iso_Latch_Set(die);

        RESET_PARAMETERS(die, Para_Array);

        POR_One_Die(die);

        if(FailFlag==0)//pass set and reset, mark BC in Reset screen.
        {
            if(Add_BC_To_REG_4C(die, PSTBCMASK)) 
            {
                Print_Die_Failure_Add_BD(die, "");
            }

            Reset_Temp_BC_Array_w_Bitmask(PSTBCMASK, 0);
            Reset_Temp_BC_Array_w_Bitmask(PSTBCMASK, 1);

            Scan_BC_To_Select_Array(die, g_Outgoing_BC, PSTBCMASK, GBC_PRINT);
        }
        else BD_Add(die, TEMP);
    }


    BC_Limit_Check(BC_LIMIT_PER_PLN, GBC_LIMIT_PER_PLN, g_Temp_BC, g_Outgoing_BC);

    ROMBLOCK_UPDATE;

    return(PF_Check());
}
