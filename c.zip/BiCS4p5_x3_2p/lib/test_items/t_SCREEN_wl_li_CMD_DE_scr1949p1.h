uint8 t_SCREEN_wl_li_CMD_DE_scr1949p1(void) //tb_480 nvcc SCR1404p7
{
    uint8 die, Org_P46, Param_Flag;
    uint16 majority_outgoing = 0x100;
    int value = 0;

    Majority_Vote vote_array_temp;

    Para_Table Para_Array[] =
    {
        {0x046, 0x00, 0xFF}, //  VPGMU = vote value from userrom
        {0x0B8, 0x00, 0xF0},  //  VSGDPCH = 3.0V
        {0x0C2, 0x20, 0xF0},  //  Unselcted WL Voltage (VPASS2 Generator)
        {0x12B, 0x00, 0x40},  //  WLDD1/DU/DL/DS1 = WLLD_USEL
        {0x100, 0x00, 0x01},  //  BL_BIAS_STRPCG = "BL=VSS"
        {0x04C, 0x00, 0xC0},  //  PROGSRC_WLLD = VSS
        {0x104, 0x80, 0x80},  //  SGS_OFF = 1(SGS = VSS fix)
        {0x105, 0x80, 0x80},  //  SGSB_OFF = 1(SGSB = VSS fix)
        {0x083, 0xF0, 0xF0},  //  PD1_WLLD = 2571.2us(max) @ SDE=80ns
        {0x0AE, 0x2C, 0x3C},  //  WLLD_IDT 0x24=500nA, 0x2C=1000nA, 0x30 = 1250nA, 0x34 =1500nA, 0x38=1750nA , 0x3C =2000nA
        {0x0AE, 0x01, 0x03},  //  WLLD_ICM = 1000nA 2,3
        {0x0AE, 0xC0, 0xC0},  //  WLLD_ICS_RANGE = 12.5nA 1,2,3
        {0x118, 0x00, 0x04},  //  WL2WLLD_EN = Disable
        {0x118, 0x02, 0x02},  //  WL2SUB_EN = Enable
        {0x12B, 0x00, 0x80},  //  F_WLD_WL2SUB= Disable
        {0x052, 0x00, 0x0F},  //  INC_VPGM_WL2SUB = 0.0 V
        {0x118, 0x08, 0x08},  //  WLLD_EN = Enable
        {0x118, 0x10, 0x10},  //  WLLD_NOERA = No Erase
        {0x117, 0x00, 0x30},  //  PAP_ERASE = disable
        {0x119, 0x00, 0x08},  //  PPNPPE_SLC = Disable
        {0x119, 0x00, 0x04},  //  PPNPPE_MLC = Disable
        {0x118, 0x20, 0x20},  //  WLLD_WAY = 1 (Half WLs)
        {0x084, 0xE0, 0xE0},  //  PR8 = 4.56us(max) @ SDE=80ns
        {0x0DF, 0x60, 0x60},  //  WL2WL_REFTAIL_BOOST = "x10" to stabilize REFDAC
        {0x12C, 0x00, 0x08},  //  F_HR_EN = Disable
        {0x12C, 0x00, 0x10},  //  F_HR_EN_ERASE = Disable
        {0x002, 0x40, 0xC0},  //  F_TESTTEMP = 2`b01
        {0x00F, 0x10, 0x10},  //  F_TMOL_EN = 1`b1
        {0x006, 0x07, 0xFF},  //  Overload CLK8
        {0x007, 0x11, 0xFF},  //  Overload PR_CLK
        {0x008, 0x71, 0xFF},  // DAC = 00 00 71 H
        {0x009, 0x00, 0xFF},
        {0x00A, 0x00, 0x01},  //Need to double confirm that //TODO
        {0x011, 7,    PLUS|0x3F},  // SDE Address  0x11[5:0] =70ns Default and +7DAC (decimal) = 80ns
    };

    FOR_EACH_DIE(die)
    {
        Org_P46 = Get_Param(die, 0x46);
        value = Org_P46;
        Param_Flag = 0;

        vote_array_temp = Read_DS_and_Majority_Vote(die, 1, 13, 2, 0x260);

        if(vote_array_temp.win_flag && (vote_array_temp.vote_cnt >= 2))
        {
            majority_outgoing = vote_array_temp.vote_value;

            if((majority_outgoing >= (Org_P46 - 20)) && (majority_outgoing <= (Org_P46 + 20)))
            {
                value = majority_outgoing - 40;
                Param_Flag = 1;
            }
        }

        if(Param_Flag == 0)  value = Org_P46 - 50;

        if(value >= 0)
        {
            Para_Array[0].value = value;
        }
        else
        {
            Para_Array[0].value = 0;
            print(0, "D@ P46 -, set 0\n", die);
        }

        SET_PARAMETERS(die, Para_Array);
    }

    WL_MH1_Leakage_CMDDE_Dummy_Read(DONOT_USE_DD);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}

