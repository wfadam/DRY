uint8 t_SCREEN_sgsb_leak_directSIN_scr2017p0(void) //tb_487 nvcc SCR696p8
{

    Para_Table Para_Array[] =
    {
        {0x002, 0x40, 0xC0}, //F_TESTTEMP = 1
        {0x00C, 0x02, 0x02}, //TEMPPARA9[1] = 1 WLLD_OPT = 1
        {0x00C, 0x00, 0x40}, //TEMPPARA9[6] = 1 SGSB_SGLD_LI = 0 (VPGMU)/1(Viso)
        {0x118, 0x20, 0x20}, //F_WLLD_WAY = 1 HALF WLS
        {0x118, 0x04, 0x04}, //F_WL2WLLD_EN = 1
        {0x118, 0x00, 0x02}, //F_WL2SUB_EN = 0
        {0x119, 0x00, 0x0C}, //F_PPNPPE_MLC/SLC = 0
        {0x117, 0x00, 0x30}, //F_PAP_ERASE = 0
        {0x118, 0x10, 0x10}, //F_WLLD_NOERA = 1
        {0x04C, 0x00, 0xC0}, //F_PROGSRC_WLLD = 0 (VSS)
        {0x100, 0x00, 0x01}, //F_BL_BIAS_STRPCG = 0
        {0x052, 0x00, 0xF0}, //F_INC_VPGM_WL2WL = 0 default value
        {0x083, 0x60, 0xF0}, //F_PD1_WLLD = 1096.64us
        {0x118, 0x08, 0x08}, //F_WLLD_EN = 1 ENABLE
        {0x043, 0xE0, 0xE0}, //VISO1 = VSS
        {0x084, 0xE0, 0xE0}, //F_PR8 = 4.56us
        {0x0DF, 0x60, 0x60}, //F_WL2WL_REFTAIL_BOOST = x10
        {0x0AD, 0x00, 0xC0}, //F_WLLD_HIGH_CUR =2uA
        {0x0AD, 0x00, 0x38}, //F_WLLD_CC_LDCLK = 0 disable
        {0x0AE, 0x20, 0x3C}, //F_WLLD_IDT = 250nA
        {0x0AE, 0x03, 0x03}, //F_WLLD_ICM = 2000nA
        {0x0AE, 0x00, 0xC0}, //F_WLLD_ICS_RANGE = 50nA
        {0x00F, 0x10, 0x10}, //F_TMOL_EN = 1`b1
        {0x006, 0x07, 0xFF}, //Overload CLK8
        {0x007, 0x11, 0xFF}, //Overload PR_CLK
        {0x008, 0x71, 0xFF}, //Set temppara5[7:0] to 71h, DAC = 00 00 71 H
        {0x009, 0x00, 0xFF}, //Set temppara6[7:0] to 00
        {0x00A, 0x00, 0x03}, //Set temppara7[1:0] to 0
        {0x011,    7, PLUS|0x3F}, //SDE = Default(71.6ns) + 7DAC = 80ns
        {0x046,   30, MINUS|0xFF}, //VPGMU = Default - 3V = ~ 10V
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);
    
    SGSB_LD_SIN();
    
    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
