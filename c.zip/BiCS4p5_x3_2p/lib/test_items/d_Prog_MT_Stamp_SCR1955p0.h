uint8 d_Prog_MT_Stamp_SCR1955p0(void)  // tb_815_nvcc
{
  
    Program_UR_Stamp_4C(0x00, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR, PASS_STAMP_COL, Para_Array, PARAM_COUNT_16);
    Program_UR_Stamp_4C(0x00, MTST_UROM_BLK0, SH_STAMP_WL, SH_STAMP_STR+1, PASS_STAMP_COL, Para_Array, PARAM_COUNT_16);      
    // Program_UR_Stamp_4C(0x00, MTST_UROM_BLK0, MTST_STAMP_WL+1, MTST_STAMP_STR, PASS_STAMP_COL, Para_Array, PARAM_COUNT_8);
    // Program_Pass_Stamp(0x00, MTST_UROM_BLK0, MTST_STAMP_WL+1, MTST_STAMP_STR+1, PASS_STAMP_COL, Para_Array, PARAM_COUNT_8);
    

    return(PF_Monitor());
}