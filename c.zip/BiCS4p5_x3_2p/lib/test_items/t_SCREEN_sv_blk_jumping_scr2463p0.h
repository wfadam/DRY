uint8 t_SCREEN_sv_blk_jumping_scr2463p0(void) //tb_831 nvcc SCR2428p0
{
    uint8 die, wl;
    uint16 blk_A, blk_B;

    g_CMDB2_FLAG = CMDB2_ENABLE;

    Para_Table Para_Array[] =
    {
        {0x057, 0x70, 0xF0}, //changing SV_VPGM_MLC (Addr 0x57h, IO[7:4]) set 0x70h is 1.4V
    };

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);

        blk_A = Search_Pair_Blk_BBMap_Erase_by_Die(die, 0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1, MLC_ERASE);
        blk_B = Search_Pair_Blk_BBMap_Erase_by_Die(die, blk_A+2, TOTAL_BLK, TOTAL_PLN, PAIR_1, MLC_ERASE);

        if((blk_A != TOTAL_BLK) && (blk_B != TOTAL_BLK))
        {
            FOR_EACH_LOOP(wl, 0, TOTAL_WL, 48)
            {
                MLC_Program_6D_2A_By_Die_WL_String(die, blk_A, blk_A+1, wl+47, STR0, SET_AB, DONOT_MARKBB); //Tier 1:   a. Program Blk A and A+1 on WL47/ST0 (trigger WL)
                                                                                                            //          b. Program Blk B and B+1 on WL0/ST1 (victim WL)
                MLC_Program_6D_2A_By_Die_WL_String(die, blk_B, blk_B+1, wl, STR1, SET_AB, DONOT_MARKBB);    //Tier 2:   a. Program Blk A and A+1 on WL95/ST0 (trigger WL)
                                                                                                            //          b. Program Blk B and B+1 on WL48/ST1 (victim WL)
            }

            FOR_EACH_LOOP(wl, 0, TOTAL_WL, 48)
            {
                MLC_Read_6D_2A_By_Die_WL_String(die, blk_B, blk_B+1, SET_AB, MARKBB, wl, STR1, IGN_BITS_SCR2463p0); //Read/detection blk B, WL0/STR1 and WL48/STR1
            }

            MLC_Erase_By_Die(die, blk_A, blk_A+1, DONOT_MARKBB);
            MLC_Erase_By_Die(die, blk_B, blk_B+1, DONOT_MARKBB);
        }

        RESET_PARAMETERS(die, Para_Array);
    }

    g_CMDB2_FLAG = CMDB2_DISABLE;

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 0;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
