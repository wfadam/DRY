uint8 t_SCREEN_dyn_read_linearity_scr2362p0(void)  // tb_762 nvcc
{
    uint8 die;
    uint16 good_blk;

    Para_Table Para_Array[] = 
    {
        {0x116, 0x80, 0x80}, // F_5D_EEEF_VCGSFT = 1
    };

    FOR_EACH_DIE(die)
    {
        // Search 1 pair good blk
        good_blk = Search_Pair_Blk_BBMap_by_Die(die, 0, TOTAL_BLK, TOTAL_PLN, PAIR_1);
        if(good_blk != TOTAL_BLK)
        {

            // SLC erase, SLC program, SLC dynamic_read
            SLC_Erase_by_Die(die, good_blk, good_blk + 2, DONOT_MARKBB); // need to confirm with PE about reject criteria
            SLC_Program_Scramble_WL0_STR0_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB); // need to confirm with PE about reject criteria
            SET_PARAMETERS(die, Para_Array);
            if(SLC_Dynamic_Read_DAC_Linearity_1page_AIPR(die, good_blk, good_blk + 1, BIT_IGNORE_10000, DLY_0))
            {
                Print_Die_Failure_Add_BD(die, "SLC");
            }

            // MLC erase, MLC program, MLC dynamic read
            MLC_Erase_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);
            MLC_Program_Scramble_WL0_STR0_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);
            if(MLC_Dynamic_Read_DAC_Linearity_1page_AIPR(die, good_blk, good_blk + 1, BIT_IGNORE_10000, DLY_0))
            {
                Print_Die_Failure_Add_BD(die, "MLC");
            }
            MLC_Erase_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);
            RESET_PARAMETERS(die, Para_Array);

            FEATURE_RESET;
            _RUN();
        }
    }

    return(PF_Check());
}
