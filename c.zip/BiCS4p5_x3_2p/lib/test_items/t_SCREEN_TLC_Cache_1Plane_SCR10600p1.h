uint8 t_SCREEN_TLC_Cache_1Plane_SCR10600p1(void) //tb_847 nvcc SCR1005p3
{
    uint8 die;
    uint16 GoodBlk;

    g_CMDB2_FLAG = CMDB2_ENABLE;

    Para_Table Para_Array[] =
    {
        {NLP_MLC_ADR, NLP_MLC_SET, NLP_MLC_MASK}, //MLC PGM GB per product
        {0x0DE, 4, PLUS|0x1F}, //VDD+4DAC
        {0x016, 2, PLUS|0x1F}, //VDDSA_PB0+2DAC
        {0x017, 2, PLUS|0x1F}, //VDDSA_PB1+2DAC
    };

    TM_Entry();

    FOR_EACH_DIE(die)
    {
        GoodBlk = Search_Pair_Blk_BBMap_by_Die(die, 0x100, TOTAL_BLK, TOTAL_PLN, PAIR_10);

        if(GoodBlk != TOTAL_BLK)
        {
            MLC_Erase_By_Die(die, GoodBlk, GoodBlk+20, MARKBB);

            SET_PARAMETERS(die, Para_Array);

            TLC_Cache_Program_SP_Scramble_By_Die(die, GoodBlk, GoodBlk+20);
            TLC_Cache_Read_SP_Sample_Page_By_Die(die, GoodBlk, GoodBlk+20, STR2);

            RESET_PARAMETERS(die, Para_Array);
        }
    }

    TM_Exit();

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = 3;
    GBB_limit.MarkBB = MARKBB;
    GBB_Check(GBB_limit);

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
