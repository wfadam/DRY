uint8 t_SCREEN_cluster_blk_x16_scr2128p0(void)//tb__952 nvcc SCR865p1
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(Cluster_BB_Count_PHY(die, 16, CLUSTER_LIMIT_20))
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Check());
}
