uint8 t_SCREEN_wl_wl_ref_scr2011p1(void) //tb__473 nvcc Base on SCR952.5
{
    uint8 die;

    Para_Table Para_Array[] =
    {
        {0x002, 0xC0, 0xC0}, //F_TESTTEMP=3 
        {0x00D, 0x80, 0xFF}, //F_VPGM2VDD_STRPCG_EN=1 , for VPGM-VDD stripe
        {0x118, 0x04, 0x04}, //F_WL2WLLD_EN=1
        {0x118, 0x00, 0x02}, //F_WL2SUB_EN=0
        {0x119, 0x00, 0x0C}, //F_PPNPPE_MLC/SLC=0
        {0x117, 0x00, 0x30}, //F_PAP_ERASE=0
        {0x118, 0x10, 0x10}, //F_WLLD_N0ERA=1
        {0x04C, 0x00, 0xC0}, //F_PROGSRC_WLLD=VSS
        {0x100, 0x01, 0x01}, //F_BL_BIAS_STRPCG=VDDSA
        {0x118, 0x20, 0x20}, //F_WLLD_WAY=1 HALF WLS
        {0x0AE, 0x24, 0x3C}, //F_WLLD_IDT= 500nA
        {0x0AE, 0x01, 0x03}, //F_WLLD_ICM= 1000nA
        {0x0AE, 0xC0, 0xC0}, //F_WLLD_ICS_RANGE= 12.5nA
        {0x083, 0xC0, 0xF0}, //F_PD1_WLLD= 2079.68us
        {0x0C3, 0x00, 0xF0}, //F_VSG_PROG set to 3.0V   
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    FOR_EACH_DIE(die)
    {
        if(WL_WL_REF_Dummy_Read(die, 0x14, 0xFA)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    return(PF_Check());
}
