uint8 t_SLC_PRG_urom_inand_id_scr2366p0(void) //tb_138 nvcc
{
    uint8 str, die = 0; //Only do FIM0 DIE0
    
    Para_Table Para_Array[] =
    {
        {0x139, 0x04, 0xFC}, //Set BSPF_PROG_SLC to 4 bits
        {0x111, 0x00, 0x10}, //SV_VPGM_HALF = disable
        {0x061, 0x38, 0x38}, //INC_VPASS_SLC = 2.8V
        {0x13A, 0x00, 0x80}, //BSCAN_2TIER_SLC = All-tier
    };

    Sel_CE_FIM_by_Die(die);

    FOR_EACH_STR(str)
    {
        if(Read_UR_Stamp_4C(die, MTST_UROM_BLK0, WL10, str, 0x00, BIT_IGNORE_10, 0xFF, 16) == EXIST) //if there is no backup copy, do the INAND UID program and read check
        {
            print(0, "STR@ INAND UID Program\n", str);

            POR_Check_No_4C(die);

            SET_PARAMETERS(die, Para_Array);
            Program_INAND_UID(die, MTST_UROM_BLK0, str);
            RESET_PARAMETERS(die, Para_Array);

            if(Read_INAND_UID(die, MTST_UROM_BLK0, str) == FAIL) //if fail read UID info, reject
            {
                Mark_All_Die_Bad(TEMP);
                print(0, "DIE@ STR@ fail read INAND UID\n", die, str);
            }

            POR_One_Die(die);

            break;            
        }
        else if(str == 3) //if all strings have backup copies, only print failure
        {
            // Mark_All_Die_Bad(TEMP);
            Print_Die_Failure(die, "find available location");
        }
    }

    return(PF_Check());
}
