uint8 t_SCREEN_AIPR_TLC_TLC_scr2216p2(void)  // tb_748 nvcc 
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        TLC_TLC_AIPR_Read_Sample_BLK_WL_STR_Delay(die, IGN_BITS_SCR2216P2);
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 4;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
