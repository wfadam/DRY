uint8 t_SLC_ERS_PRG_aipr_blkaddr_dependent_scr2223p0()  // tb__275 nvcc SCR1186p4
{
	GBB_Check_Init(GBB_limit);
	uint8 Loop = 0;
    uint16 blk = 0;
    
    FOR_EACH_LOOP(Loop,0,0xF,2)
    {
        FOR_EACH_LOOP(blk, Loop, TOTAL_BLK, 0x10)
        {
            if((THROTTLE_PRODUCT == THROTTLE)&&((blk-Loop)%0x400==0))
            {
                print(0,"B@:", blk);
                Cool_temp(90, 1);
            }

            SLC_Erase(blk, blk+1,MARKBB);
            SLC_Program(blk, blk+1,MARKBB);
        }
    }
	// SLC_Erase_Program(THROTTLE_PRODUCT);
    
    GBB_limit.GBB_CHECK_PLN=25;
    GBB_limit.MarkBB=MARKBB;
    GBB_Check(GBB_limit);
    
    return(PF_Check());
}
