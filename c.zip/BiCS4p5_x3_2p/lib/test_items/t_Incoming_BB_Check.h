uint8 t_Incoming_BB_Check(void)
{
    uint8 die;

    Reset_Select_BB_Map(MAIN);
    Reset_Select_BB_Map(TEMP);

    FOR_EACH_DIE(die)
    {
        Scan_BB_To_Select_Map(die, TEMP);
    }

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
