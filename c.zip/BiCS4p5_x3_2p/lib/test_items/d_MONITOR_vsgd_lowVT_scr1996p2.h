uint8 d_MONITOR_vsgd_lowVT_scr1996p2(void) //tb_647 nvcc SCR1849p2
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB

    VSGS_VSGD_Detection_2A(SGD, LOW_VT, 2400, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E); //VCGRV = 2.4V

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
