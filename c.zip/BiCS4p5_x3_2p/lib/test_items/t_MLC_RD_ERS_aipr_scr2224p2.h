uint8 t_MLC_RD_ERS_aipr_scr2224p2(void)//tb__398 nvcc
{
    uint16 blk = 0;

    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {0x137,       BSPF_EV_MLC_SET, BSPF_EV_MLC_MASK},
        {0x0AB, 0x08, 0x08}, //enable ocs6D to enable every string have different random data in same wl.
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    for(blk = 0; blk < TOTAL_BLK; blk+=TOTAL_PLN)
    {
        // FOR_EACH_DIE(die)
        {
            MLC_AIPR_Read_6DBB(blk, blk+1, MARKBB, IGN_BITS_MLC, DONOT_SET_AB);//0xAB set outside for TTR
        }
        MLC_Erase(blk, blk+1, MARKBB);
    }

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    FULLARRAY_BB_CHECK;
    
    return(PF_Check());
}
