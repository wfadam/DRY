uint8 t_SCREEN_sgs_leak_scr1876p1(void)//tb__484 nvcc Base on SCR570.4
{
    Para_Table Para_Array[] =
    {
        {0x002, 0x40, 0xC0},  //F_TESTTEMP=1
        {0x118, 0x20, 0x20},  // F_WLLD_WAY=1 HALF WLS
        {0x118, 0x04, 0x04},  // F_WL2WLLD_EN=1
        {0x118, 0x00, 0x02},  // F_WL2SUB_EN=0
        {0x119, 0x00, 0x0C},  // F_PPNPPE_MLC/SLC=0
        {0x117, 0x00, 0x30},  // F_PAP_ERASE=0
        {0x118, 0x10, 0x10},  // F_WLLD_N0ERA=1 
        {0x04C, 0x00, 0xC0},  // F_PROGSRC_WLLD=0(VSS)
        {0x100, 0x00, 0x01},  // F_BL_BIAS_STRPCG=0
        {0x052, 0x00, 0xF0},  // F_INC_VPGM_WL2WL=0
        {0x00C, 0x02, 0x02},  // WLLD_OPT = 1
        {0x046, 0x24, 0xFF},  // F_VPGMU = 7V   
        {0x083, 0x60, 0xF0},  // F_PD1_WLLD= 1096.64us
        {0x00C, 0x40, 0x40},  // F_SGSB_SGLD_SGLI = 1
        {0x118, 0x08, 0x08},  // F_WLLD_EN = 1 ENABLE
        {0x043, 0xE0, 0xE0},  // F_VISO1 = VSS
        {0x084, 0xE0, 0xE0},  // F_PR8 = 4.56us
        {0x0DF, 0x60, 0x60},  // F_WL2WL_REFTAIL_BOOST = x10
        {0x0AD, 0x00, 0xC0},  // F_WLLD_HIGH_CUR = 2uA
        {0x0AD, 0x00, 0x38},  // F_WLLD_CC_LDCLK = 0 disable
        {0x0AE, 0x03, 0x03},  // F_WLLD_ICM= 2000nA
        {0x0AE, 0xC0, 0xC0},  // F_WLLD_ICS_RANGE= 12.5nA
        {0x0AE, 0x24, 0x3C},  // F_WLLD_IDT = 500nA
        {0x011, 7,    PLUS|0x3F}, //SDE = default(71.6ns) + 7DAC = 80ns
    };

    Reset_All_BBlk();

    SET_PARAMETERS_ALL_DIE(Para_Array);
    
    SGS_SGD_Leakage(SGS_LEAK, DUAL_PLN);

    FULLARRAY_BB_CHECK;

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
