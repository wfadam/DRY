uint8 t_SCREEN_din_dout_0gbc_scr2144p1(void)//tb_190_nvcc SCR2144p0
{
    uint8 die=0;

    FOR_EACH_DIE(die)
    {
        Scan_BC_To_Select_Array(die, g_Temp_BC, PREBCMASK, NOBC_PRINT);

        if(XDL_din_dout(die)!=0)
        {
            Print_Die_Failure_Add_BD(die, "");
        }

        Scan_BC_To_Select_Array(die, g_Outgoing_BC, PSTBCMASK, GBC_PRINT);
    }

    BC_Limit_Check(BC_LIMIT_PER_PLN, 0, g_Temp_BC, g_Outgoing_BC);

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
