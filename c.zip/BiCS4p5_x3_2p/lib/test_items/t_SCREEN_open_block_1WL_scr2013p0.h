uint8 t_SCREEN_open_block_1WL_scr2013p0(void)  //tb_422_nvcc
{
    int blk;
    ADR_Init(adr);
    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE=0;
    GBB_limit.MarkBB=MARKBB;

    // For the GB during programming in this item, MT controlled by xml file, please align with prodcut PE before using this.

    // 1. Temp para change VDD+4DAC , Move out in case return in the middle.
    Para_Table Para_Array[] =
    {
        {0x0DE, 4, PLUS|0x1F},
        {0x0AB, 0x08, 0x08},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    // 2. MLC Erase ALL Blocks with status check
    print(0, "STEP2: MLC ERS\n");
    MLC_Erase_2A(0, TOTAL_BLK, MARKBB);
    FULLARRAY_BB_CHECK;
    Reset_Select_BB_Map(TEMP);


    //3. From MIN to MAX (Ascending order) ALL Blocks perform open block MLC Program - WL0 and WL1. All Strings 0,1,2,3 with status check
    print(0, "STEP3:Ascending MLC PRG\n");
    FOR_EACH_LOOP(adr.phy.blk, 0, TOTAL_BLK, TOTAL_PLN)
    {
        MLC_Program_6D_2A_1WL(adr, DONOT_SET_AB, MARKBB);
    }
    
    GBB_Check(GBB_limit); 
    Reset_Select_BB_Map(TEMP);


    // 4. MLC Erase ALL Blocks with status check
    print(0, "STEP4: MLC ERS\n");
    MLC_Erase_2A(0, TOTAL_BLK, MARKBB);
    FULLARRAY_BB_CHECK;
    Reset_Select_BB_Map(TEMP);


    //5. From MAX to MIN (Descending order) ALL Blocks perform open block MLC Program - WL0 and WL1. All Strings 0,1,2,3 with status check
    print(0, "STEP5: Descending MLC Prog\n");
    FOR_EACH_LOOP_BACK(blk,TOTAL_BLK-2,-1,TOTAL_PLN)
    {
       adr.phy.blk=blk;
       MLC_Program_6D_2A_1WL(adr, DONOT_SET_AB, MARKBB);
    }
    GBB_Check(GBB_limit); 
    Reset_Select_BB_Map(TEMP);
    
    RESET_PARAMETERS_ALL_DIE(Para_Array);

    // 6. With default VDD, read ALL Blocks for WL0/WL1, All Strings with 90bit/1K bit ignore. Read is MONITOR only.
    print(0, "STEP6: MLC RD\n");
    FOR_EACH_LOOP(adr.phy.blk,0,TOTAL_BLK,TOTAL_PLN)
    {
        MLC_Read_6D_2A_1WL(adr,SET_AB,BIT_IGNORE_90);
    }
    GBB_MONITOR_PRINT;
    return(PF_Check());
}
