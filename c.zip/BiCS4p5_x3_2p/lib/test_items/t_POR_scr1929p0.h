uint8 t_POR_scr1929p0(void)//tb220-233 nvcc
{
    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
