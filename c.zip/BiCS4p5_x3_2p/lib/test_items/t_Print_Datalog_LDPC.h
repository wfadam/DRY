uint8 t_Print_Datalog_LDPC()
{
   
    Print_Datalog_LDPC();

    if(g_CST_BINCODE==0x1000)    Mark_All_Die_Bad(TEMP);

	return(PF_Check());
}
