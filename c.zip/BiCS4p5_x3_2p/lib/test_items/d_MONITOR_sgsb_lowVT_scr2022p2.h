uint8 d_MONITOR_sgsb_lowVT_scr2022p2(void) //tb_651 nvcc SCR1853p2
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB
    
    VSGS_VSGD_Detection_2A(SGSB, LOW_VT, 700, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E); //VCGRV = 0.7V

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
