uint8 d_MONITOR_mh_open_scr2221p0_1Bit(void)  //tb_495 nvcc Base on SCR1882.1
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        MH_Open(die, BIT_IGNORE_1);
    }

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}
