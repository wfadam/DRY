uint8 t_SCREEN_TLC_cache_prog_80_11_delay_scr2182p0(void)  // tb_781 hvcc Base on SCR1609.1
{
    uint8 die;
    uint16 good_blk;

    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_by_Die(die, 0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1);
        if(good_blk != TOTAL_BLK)
        {
            MLC_Erase_By_Die(die, good_blk, good_blk + 2, DONOT_MARKBB);

            if(TLC_Cache_Program_MP_Scramble_1K_By_Die_Check80(die, good_blk) != PASS)
            {
                Print_Die_Failure_Add_BD(die, "");
            }
        }
    }       

    return(PF_Check());
}
