uint8 t_SCREEN_Latch_Corruption_Screen_TLC_Read_B2_SCR10670p1(void)//tb_858 nvcc SCR10670p0
{
    Para_Table Para_Array[] =
    {
        {0x0DE, 4, MINUS|0x1F},  // VDD - 4DAC
    };

    g_CMDB2_FLAG = CMDB2_ENABLE;

    TM_Entry();

    TLC_Read_Latch_Corruption(BIT_IGNORE_1, Para_Array, sizeof(Para_Array) / sizeof(Para_Table));

    TM_Exit();

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());   
}
