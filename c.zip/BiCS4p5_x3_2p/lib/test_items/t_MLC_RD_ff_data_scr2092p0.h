uint8 t_MLC_RD_ff_data_scr2092p0(void)//tb__390 nvcc
{
    MLC_Read_Pattern_2A(0, TOTAL_BLK, ALLFF, IGN_BITS_MLC_ALLFF);

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
