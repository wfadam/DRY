uint8 d_MONITER_WLDU_highVT_scr2104p0(void)//tb__656 nvcc
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB


    VSGS_VSGD_Detection_2A(WLDU, HIGH_VT, 3000, MARKBB, MLC_STATUS, BIT_IGNORE_16,SET_9E);  //VCGRV = 3.0V 16BITS/1K

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}