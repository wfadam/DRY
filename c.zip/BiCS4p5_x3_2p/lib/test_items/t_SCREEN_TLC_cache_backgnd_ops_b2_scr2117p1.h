uint8 t_SCREEN_TLC_cache_backgnd_ops_b2_scr2117p1(void) //tb_783 nvcc
{
    g_CMDB2_FLAG = CMDB2_ENABLE;
    // This TB use 2 buffer
    TM_Entry();

    Cache_Background_Screen();

    TM_Exit();

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
