uint8 t_SCREEN_WLDD1_highVT_scr1855p1(void)//tb__636 nvcc
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB

    VSGS_VSGD_Detection_2A(WLDD1, HIGH_VT, 3000, MARKBB, MLC_STATUS, BIT_IGNORE_8,SET_9E);  //VCGRV = 3.0V 8 bit ignore/1K

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
