uint8 t_SCREEN_TLC_Normal_Read_CMD2B_B2_SCR10592p1(void) //tb_845 nvcc SCR1004p0
{
    uint8 die;
    uint16 good_blk;

    g_CMDB2_FLAG = CMDB2_ENABLE;

    Para_Table Para_Array[] =
    {
        {0x11,    2,  PLUS|0x3F},  //Set SDE+2DAC
        {0xDE,    4, MINUS|0x1F},  //Set VDD-4DAC
    };

    TM_Entry();

    FOR_EACH_DIE(die)
    {
        good_blk = Search_Pair_Blk_BBMap_Erase_by_Die(die, 0x100, TOTAL_BLK, TOTAL_PLN, PAIR_1,MLC_ERASE);
        if(good_blk != TOTAL_BLK)
        {
            SET_PARAMETERS(die, Para_Array);
            MLC_Program_Scramble_By_Die(die, good_blk, good_blk + 2, MARKBB, PRINT_FAIL);
            TLC_Normal_Read_2B_Scramble_By_Die_100bytes(die, good_blk, good_blk + 2,BIT_IGNORE_10);

            RESET_PARAMETERS(die, Para_Array);
        }
    } 

    TM_Exit();

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_DIE = 0;
    GBB_limit.MarkBB = MARKBB;
    GBB_Check(GBB_limit);

    g_CMDB2_FLAG = CMDB2_DISABLE;

    return(PF_Check());
}
