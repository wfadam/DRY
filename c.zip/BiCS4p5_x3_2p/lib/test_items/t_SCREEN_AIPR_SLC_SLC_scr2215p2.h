uint8 t_SCREEN_AIPR_SLC_SLC_scr2215p2(void)  //tb_747 nvcc
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        SLC_SLC_AIPR_Read_Sample_BLK_WL_STR_Delay(die, IGN_BITS_SCR2215P2);
    }

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 4;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
