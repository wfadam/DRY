uint8 d_SLC_RD_PRG_rfcopy_outgoing_scr1941p0(void)  //tb_131_nvcc
{
    uint8 die;
    Para_Table Para_Array[] =
    {
        {0x139, 0x04, 0xFC},  // set BSPF_PROG_SLC to 4 bits 
        {0x111, 0x00, 0x10},  // SV_VPGM_HALF = disable
        {0x0A7, 0x01, 0x01},  // UROM_CRD_DIS = CRD disable
        {0x061, 0x38, 0x38},  // INC_VPASS_SLC = 2.8V
        {0x13A, 0x00, 0x80},  // BSCAN_2TIER_SLC = All-Tier
    };

    FOR_EACH_DIE(die)
    {
        if(Read_UR_Stamp_4C(die,MTST_UROM_BLK0,WL20,STR0,0x00,BIT_IGNORE_10,0xFF,16)==EXIST) //If there is no backup
        {
            ChipPointer_CMD2A(die);
            XDL_SET_ONE;
            _CMD(0x2C);
            NAND_RESET;

            REG_SA(die,DATA_PARITY);
            SET_PARAMETERS(die, Para_Array);
            Program_UR_4C(die, MTST_UROM_BLK0, WL20,STR0,0x00);
            Program_UR_4C(die, MTST_UROM_BLK0, WL21,STR0,0x00);
            Program_UR_4C(die, MTST_UROM_BLK0, WL20,STR1,0x00);
            Program_UR_4C(die, MTST_UROM_BLK0, WL21,STR1,0x00);
            RESET_PARAMETERS(die, Para_Array);
                // print(0, "Backup page address Die:@, BLK:@, WL:@&@, STR:@&@\n", die, MTST_UROM_BLK, INCOMING_BACKUP_WL, INCOMING_BACKUP_WL+1, INCOMING_BACKUP_STR, INCOMING_BACKUP_STR+1);
        }
        else
        {
            print(0, "D@ Skip\n", die);
        }    
    }

    return(PF_Monitor());
}