uint8 t_MLC_ERS_reset_bb_scr1951p0() //tb364 nvcc scr591p0 
{
    Reset_All_BBlk();
    Set_Datalog_Block_as_BB();
    MLC_Erase(0, TOTAL_BLK, DONOT_MARKBB);
    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
