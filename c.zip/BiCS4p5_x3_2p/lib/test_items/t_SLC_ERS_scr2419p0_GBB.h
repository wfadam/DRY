uint8 t_SLC_ERS_scr2419p0_GBB(void) //tb_331, tb333 nvcc SCR1842p0
{
    Para_Table Para_Array[] =
    {
        {NLE_SLC_ADR, NLE_SLC_SET, NLE_SLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    SLC_Erase(0, TOTAL_BLK, MARKBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN=6;
    GBB_limit.MarkBB=MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
