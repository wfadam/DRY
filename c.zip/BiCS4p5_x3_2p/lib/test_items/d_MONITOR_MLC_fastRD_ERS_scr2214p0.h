uint8 d_MONITOR_MLC_fastRD_ERS_scr2214p0(void) // tb_397 lvcc
{
    Para_Table Para_Array[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {0x0AB, 0x08, 0x08},   //Enable ocs6D to enable every string have different random data in same wl.
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Fast_Read_6D_2A(MLC_EP_G0_START, MLC_EP_G0_END,MARKBB,IGN_BITS_MLC,DONOT_SET_AB);
    MLC_Erase_2A(MLC_EP_G0_START, MLC_EP_G0_END,MARKBB);
  
    MLC_Fast_Read_6D_2A(MLC_EP_G1_START, MLC_EP_G1_END,MARKBB,IGN_BITS_MLC,DONOT_SET_AB);
    MLC_Erase_2A(MLC_EP_G1_START, MLC_EP_G1_END,MARKBB);

    MLC_Fast_Read_6D_2A(MLC_EP_G2_START, MLC_EP_G2_END,MARKBB,IGN_BITS_MLC,DONOT_SET_AB); 
    MLC_Erase_2A(MLC_EP_G2_START, MLC_EP_G2_END,MARKBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    GBB_MONITOR_PRINT;

    return(PF_Monitor());
}