uint8 t_TRIM_rf_swapblock_INAND_scr2175p0(void) //tb__932 nvcc
{
    uint8 die = 0;
    
    Sel_CE_FIM_by_Die(die);
    
    if(Swap_Blk0_Blk1(die) != 0)
    {
        Print_Die_Failure_Add_BD(die, "Swap");
    }
    if(Check_Blk0_Blk1(die)!=0)
    {
        Print_Die_Failure_Add_BD(die, "Detect");
    }
    if(Erase_Blk0_Blk1(die)!=0) //Make sure outgoing Blk0 blk1 is good for next flash write.
    {
        Print_Die_Failure_Add_BD(die, "Ers");
    }

    ROMBLOCK_UPDATE;

    return(PF_Check());
}
