uint8 d_MONITOR_GBB_Outgoing_Chk_SCR2481p0(void) //tb_957 nvcc
{
    uint8 die;

    ADR_Init(adr);
    adr.phy.blk = MTST_UROM_BLK0;
    adr.phy.wl = INCOMING_BACKUP_WL;
    adr.phy.str = INCOMING_BACKUP_STR;

    Reset_Select_BB_Map(TEMP);

    FOR_EACH_DIE(die)
    {
        Scan_BB_From_Backup(die, adr, TEMP);

        if(GBB_Check_Inv(die, 0, TOTAL_BLK, MTST_GBB_LIMIT) != PASS)
        {
            Print_Die_Failure_Add_BD(die, "");
        }
    }

    return(PF_Monitor());
}
