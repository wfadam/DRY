uint8 t_MLC_RD_dummy_scr2394p0(void) //tb_410 nvcc
{
    if(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, EFR_RE_CYCLE_STAMP_WL, EFR_CYCLE_STAMP_STR, EFR_RE_CYCLE_STAMP_COL+BYTE_8, BIT_IGNORE_10, 0xAA, BYTE_8) == DONOT_EXIST)
    {
        MLC_Dummy_Read_6E(1);

        Program_UR_Stamp_4C(0, MTST_UROM_BLK0, EFR_RE_CYCLE_STAMP_WL, EFR_CYCLE_STAMP_STR, EFR_RE_CYCLE_STAMP_COL+BYTE_8, BYTE_8);

        if(Read_UR_Stamp_4C(0, MTST_UROM_BLK0, EFR_RE_CYCLE_STAMP_WL, EFR_CYCLE_STAMP_STR, EFR_RE_CYCLE_STAMP_COL+BYTE_8, BIT_IGNORE_10, 0xAA, BYTE_8) == DONOT_EXIST)
        {
            Print_Die_Failure_Add_BD(0, "Read stamp");
        }
    }
    else
    {
        print(0, "Stamp exists, skip\n");
    }

    return(PF_Check());
}
