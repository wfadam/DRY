uint8 d_SLC_PRG_flash_write_scr1957p0(void)  // tb_260 nvcc Base on SCR605.4
{
    Para_Table Para_Array[] =
    {
        {0x046, PARA_P46_SCR1957p0, PLUS|0xFF},   // Adjusting VPGMU
        {0x113, 0x00, 0x08},  // F_SV_MANUAL_MLC=0
        {0x113, 0x00, 0x04},  // F_SV_AUTO_MLC=0 
        {0x111, 0x00, 0x10},  // F_SV_VPGM_HALF=0
        {0x112, 0x00, 0x01},  // F_QPWEN=0
        {0x112, 0x00, 0x02},  // F_FQPW=0
        {0x136, 0x00, 0x04},  // F_QPWEN_SV=0 
        {0x114, 0x00, 0x80},  // F_PREPVFY=0 
        {0x127, 0x00, 0x02},  // F_SGS_WLLD_MPRO=VSGS
        {0x072, 0xE0, 0xE0},  // F_P5TOP7_VPGM_CTRL=0
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);

    Flash_Write(0, TOTAL_BLK, DELAY_TIME_SCR1957p0);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    return(PF_Monitor());
}
