uint8 t_SCREEN_svfy_blk_jump_scr2524p0(void)   //tb__791 nvcc scr2524p0
{
    uint8 wl, die;
    uint16 blk_a, blk_b;
    GBB_Check_Init(GBB_limit);

    Para_Table Para_Array[] =
    {
        {0x057, 0x70, 0xF0},       // changing SV_VPGM_MLC (Addr 0x57h, IO[7:4]) set 0x70h or 1.4V
    };

    FOR_EACH_DIE(die)
    {
        SET_PARAMETERS(die, Para_Array);

        blk_a=Search_Pair_Blk_BBMap_Erase_by_Die(die, 0,       TOTAL_BLK, TOTAL_PLN, PAIR_1, MLC_ERASE);
        blk_b=Search_Pair_Blk_BBMap_Erase_by_Die(die, blk_a+2, TOTAL_BLK, TOTAL_PLN, PAIR_1, MLC_ERASE);

        if((blk_a != TOTAL_BLK) && (blk_b != TOTAL_BLK))
        {
            for(wl = 0; wl <= 95; wl += 48)
            {            
            	MLC_Program_6D_2A_By_Die_WL_String(die, blk_a, blk_a+1, wl+47, STR0, SET_AB, DONOT_MARKBB);  // Tier 1: a. Blk A/A+1: Program on WL47/ST0 (trigger WL)                                                                                      //         b. Blk B/B+1: Program on WL0/ST1 (victim WL)
            	MLC_Program_6D_2A_By_Die_WL_String(die, blk_b, blk_b+1, wl,    STR1, SET_AB, DONOT_MARKBB);  // Tier 2: a. Blk A/A+1: Program on WL95/ST0 (trigger WL)                                                                                          //         b. Blk B/B+1: Program on WL48/ST1 (victim WL)
            }

            for(wl = 0; wl <= 95; wl += 48)
            {
                MLC_Read_6D_2A_By_Die_WL_String(die, blk_b, blk_b+1, SET_AB, MARKBB, wl, STR1, IGN_BIT_SCR2524p0); //Read/dectection blk B, WL0/ST1 and WL48/ST1
            }

            MLC_Erase_By_Die(die, blk_a, blk_a+2, DONOT_MARKBB);
            MLC_Erase_By_Die(die, blk_b, blk_b+2, DONOT_MARKBB);
        }

        RESET_PARAMETERS(die, Para_Array);
    }

    GBB_limit.GBB_CHECK_PLN = 0;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());
}
