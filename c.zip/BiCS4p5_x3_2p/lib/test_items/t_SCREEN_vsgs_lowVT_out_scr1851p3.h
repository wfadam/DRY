uint8 t_SCREEN_vsgs_lowVT_out_scr1851p3(void) //tb_640 nvcc SCR901p4
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB

    VSGS_VSGD_Detection_2A(SGS, LOW_VT, 1600, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E); //VCGRV = 1.6V

    FULLARRAY_BB_CHECK;

    return(PF_Check());
}
