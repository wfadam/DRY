uint8 d_Wait_5m()
{
    return(Wait_Start_Signal(5));
}