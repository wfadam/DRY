uint8 t_Erase_Data_Log_Block(void)
{
    uint8 FailFlag=0;

    if(Decode_data_log_block()!=CST_DATLOG_BLOCK_INVALID)
    {
        FailFlag |= Erase_Block_for_CST_Log();
    }
    else
    {
        print(0, "Log Blk not Exist\n");
    }

    return(FailFlag);
}
