uint8 t_SCREEN_vsgd_highVT_scr1848p2(void) //tb_625 nvcc
{
    //WL Address 0 -> WLDS0; 1 -> WLDS1; 2 -> WLDD0; 3 -> WLDD1; 4 -> SGS; 5 -> SGD; 6 -> WLDL; 7 -> WLDU; 8 -> SGSB

    Reset_All_BBlk();

    VSGS_VSGD_Detection_2A(SGD, HIGH_VT, 3200, MARKBB, MLC_STATUS, BIT_IGNORE_16, SET_9E);  //VCGRV = 3.2V

    BB_Check_EOC(0, TOTAL_BLK, 4, 5, TEMP);

    FULLARRAY_BB_CHECK;

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
