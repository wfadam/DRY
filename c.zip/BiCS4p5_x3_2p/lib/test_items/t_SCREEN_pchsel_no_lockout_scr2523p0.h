uint8 t_SCREEN_pchsel_no_lockout_scr2523p0(void)  //tb__792 nvcc scr2523p0
{
    Para_Table Para_Array[] =
    {
        {0x111, 0x00, 0x60}, //PCHSEL (Addr 0x111h, IO[6:5]) set from default 11 LOCKOUT to 00 NO LOCKOUT
    };

    Para_Table Para_Array2[] =
    {
        {NLE_MLC_ADR, NLE_MLC_SET, NLE_MLC_MASK},
        {NLP_MLC_ADR, NLP_MLC_SET, NLP_MLC_MASK},
    };

    SET_PARAMETERS_ALL_DIE(Para_Array);
    SET_PARAMETERS_ALL_DIE(Para_Array2);

    MLC_Erase_2A(MLC_EP_G0_START, MLC_EP_G0_END, MARKBB);
    MLC_Erase_2A(MLC_EP_G1_START, MLC_EP_G1_END, MARKBB);
    MLC_Erase_2A(MLC_EP_G2_START, MLC_EP_G2_END, MARKBB);

    MLC_Program_6D_2A(MLC_EP_G0_START, MLC_EP_G0_END, MARKBB, SET_AB);
    MLC_Program_6D_2A(MLC_EP_G1_START, MLC_EP_G1_END, MARKBB, SET_AB);
    MLC_Program_6D_2A(MLC_EP_G2_START, MLC_EP_G2_END, MARKBB, SET_AB);

    RESET_PARAMETERS_ALL_DIE(Para_Array);

    MLC_Read_6D_2A(MLC_RE_G0_START, MLC_RE_G0_END, MARKBB, IGN_BIT_SCR2523p0, SET_AB);
    MLC_Read_6D_2A(MLC_RE_G1_START, MLC_RE_G1_END, MARKBB, IGN_BIT_SCR2523p0, SET_AB);
    MLC_Read_6D_2A(MLC_RE_G2_START, MLC_RE_G2_END, MARKBB, IGN_BIT_SCR2523p0, SET_AB);

    MLC_Erase_2A(MLC_RE_G0_START, MLC_RE_G0_END, MARKBB);
    MLC_Erase_2A(MLC_RE_G1_START, MLC_RE_G1_END, MARKBB);
    MLC_Erase_2A(MLC_RE_G2_START, MLC_RE_G2_END, MARKBB);

    RESET_PARAMETERS_ALL_DIE(Para_Array2);

    GBB_Check_Init(GBB_limit);
    GBB_limit.GBB_CHECK_PLN = 3;
    GBB_limit.MarkBB = DONOT_MARKBB;
    GBB_Check(GBB_limit);

    return(PF_Check());

}
