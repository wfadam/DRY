uint8 d_S35_NST_ProgCache_SLC_DP_PPP_SLC_SP_PPP(void)
{
    uint8 die=0, i=0;
    uint16 Blk_Cnt=NST_BLK_CNT, blk, blk_2, blk_loop;    
    uint16 Blk_Start[3]={0,         BOT_BLK_EDGE, TOP_BLK_EDGE}; 
    uint16 Blk_Stop[3] ={TOTAL_BLK, TOTAL_BLK,    0};
    ADR_Init(adr);
    NST_Buffer_PPP_Init();

    FOR_EACH_DIE(die)
    {
        FOR_EACH_LOOP(i, 0, NST_BLK_GROUP, 1)  //middle, bottom, top blk   
        {
            NST_Blk_Search(die, Blk_Start[i], Blk_Stop[i], Blk_Cnt);

            if(Is_Bad_Die(die, TEMP)==0)
            {    
                FOR_EACH_LOOP(blk_loop, 0, Blk_Cnt, TOTAL_PLN)
                {
                    blk   = g_SLC_Blk + blk_loop;
                    blk_2 = g_SLC_Blk_2+blk_loop;
                    
                    FOR_EACH_PAGE(adr)
                    {        
                        adr.phy.blk=blk;
                        NST_SLC_Cache_Pgm_By_Page(die, adr, DUAL_PLN, PPP_YES);
                      
                        adr.phy.blk=blk_2;
                        NST_SLC_Cache_Pgm_By_Page(die, adr, SINGLE_PLN, PPP_YES);

                        NST_Poll_Status_72(die, blk, 0xE0);

                    }
                }
            }
        }
    }
    GBB_MONITOR_PRINT;
    return(PF_Monitor());
}
