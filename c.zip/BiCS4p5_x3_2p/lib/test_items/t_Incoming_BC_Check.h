uint8 t_Incoming_BC_Check(void)
{
    uint8 die, pln;

    FOR_EACH_DIE(die)
    {
        Scan_BC_To_Select_Array(die, g_Incoming_BC_Cnt, PREBCMASK, BC_PRINT);
    }

    FOR_EACH_DIE(die)
    {
    	FOR_EACH_PLN(pln)
    	{
    		g_Outgoing_BC[die][pln] = g_Incoming_BC_Cnt[die][pln];
    	}
    }
    BC_Limit_Check(BC_LIMIT_PER_PLN, DONOT_CHECK,  g_Incoming_BC_Cnt, g_Incoming_BC_Cnt);

    return(PF_Check());
}
