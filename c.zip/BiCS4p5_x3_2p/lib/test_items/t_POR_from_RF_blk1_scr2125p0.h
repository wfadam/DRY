uint8 t_POR_from_RF_blk1_scr2125p0(void)//tb__236/TB__237 nvcc
{
    uint8 die;

    FOR_EACH_DIE(die)
    {
        if(POR_From_RF(die, 1, USE_4C)!=0)
        {
            Print_Die_Failure_Add_BD(die, "POR RF1");
        }
    }

    POR_CHECK_ALL_DIE;

    return(PF_Check());
}
