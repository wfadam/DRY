/*******************************************************************************
    File name   : Macro.h
    Description : To define value for all memory config
    Device      : BiCS4 X3 256Gb\512Gb
*******************************************************************************/

#define LIB_REVISION                       29

#define PRODUCT_STR                        "NONE"

#if defined DENS_256_SW
    #include "Macro_256Gb.h"
    const uint8 g_DENSITY = 0;
#elif defined DENS_512_SW
    #include "Macro_512Gb.h"
    const uint8 g_DENSITY = 1;
#endif

//=========================================================================
//NFIM
//=========================================================================
#ifdef NFIM_1_SW
    #define TOTAL_FIM                       0x1
    #ifndef ALLFIMMASK
        #define ALLFIMMASK                  0x1
    #endif
#endif

#ifdef NFIM_2_SW
    #define TOTAL_FIM                       0x2
    #ifndef ALLFIMMASK
        #define ALLFIMMASK                  0x3
    #endif
#endif

#ifdef NFIM_4_SW
    #define TOTAL_FIM                       0x4
    #ifndef ALLFIMMASK
        #define ALLFIMMASK                  0xF
    #endif
#endif

#ifdef NFIM_8_SW
    #define TOTAL_FIM                       0x8
    #ifndef ALLFIMMASK
        #define ALLFIMMASK                  0xFF
    #endif
#endif

#ifdef CV2
    #ifndef TIMING_DQSQ
        #define TIMING_DQSQ                 700
    #endif

    uint16 g_tDQSQ = TIMING_DQSQ;               //For REV22
    const uint8 g_ALLFIMMASK = ALLFIMMASK;      //For REV21
    const uint8 g_TOTAL_USED_FIM = TOTAL_FIM;   //For REV20
#endif

//=========================================================================
//NCE
//=========================================================================
#ifdef NCE_1_SW
    #define TOTAL_CE_PER_FIM                0x1
#endif

#ifdef NCE_2_SW
    #define TOTAL_CE_PER_FIM                0x2
#endif

#ifdef NCE_4_SW
    #define TOTAL_CE_PER_FIM                0x4
#endif

//=========================================================================
//NDIE
//=========================================================================
#define DIECONF_ADR                         0x020
#define DEVCODE_ADR                         0x0FE
#define READ_ID7                            0x98  //TOSHIBA

#ifdef NDIE_1_SW
    #define TOTAL_DIE_PER_CE                1
    #define READ_ID1                        0x45
    #define READ_ID2                        DEVCODE
    #define READ_ID3                        0x98
    #define READ_ID4                        0xB3
    #define READ_ID5                        0xF6
    // #define READ_ID6                        TECH_CODE
#endif

#ifdef NDIE_2_SW
    #define TOTAL_DIE_PER_CE                2
    #define READ_ID1                        0x45
    #define READ_ID2                        DEVCODE
    #define READ_ID3                        0x99
    #define READ_ID4                        0xB3
    #define READ_ID5                        0xFA
    // #define READ_ID6                        TECH_CODE
#endif

#ifdef NDIE_4_SW
    #define TOTAL_DIE_PER_CE                4
    #define READ_ID1                        0x45
    #define READ_ID2                        DEVCODE
    #define READ_ID3                        0x9A
    #define READ_ID4                        0xB3
    #define READ_ID5                        0xFE
    // #define READ_ID6                        TECH_CODE
#endif

#ifdef NDIE_8_SW
    #define TOTAL_DIE_PER_CE                8
    #define READ_ID1                        0x45
    #define READ_ID2                        DEVCODE
    #define READ_ID3                        0x9B
    #define READ_ID4                        0xB3
    #define READ_ID5                        0xFE
    // #define READ_ID6                        TECH_CODE
#endif

//=========================================================================
//1pass or 2pass
//=========================================================================
// #ifdef ONE_PASS_SW
//     #define ONE_PASS_ENABLE                 TRUE
// #else
//     #define ONE_PASS_ENABLE                 FALSE
// #endif

// #ifdef TWO_PASS_SW
//     #define TWO_PASS_ENABLE                 TRUE
// #else
//     #define TWO_PASS_ENABLE                 FALSE
// #endif

//=========================================================================
//Total die and ce
//=========================================================================
#define TOTAL_CE                            (TOTAL_CE_PER_FIM * TOTAL_FIM)

#ifndef TOTAL_DIE //allow to define TOTAL_DIE in local folder
    #define TOTAL_DIE                       (TOTAL_DIE_PER_CE * TOTAL_CE)
#endif
//=========================================================================
//DS parameter version Defines
// //=========================================================================
// #define DS_PARM_VER1                        0x302E3130  //0.10
// #define DS_PARM_VER2                        0x302E3230  //0.20
// #define DS_PARM_VER3                        0x302E3330  //0.30
// #define DS_PARM_VER4                        0x302E3331  //0.30
// #define DS_PARM_VER5                        0x312E3035  //1.05
// #define DS_PARM_VER6                        0x312E3037  //1.07
// #define DS_PARM_VER7                        0x322E3030  //2.00
// #define DS_PARM_VER8                        0x322E3130  //2.10
// #define DS_PARM_VER9                        0x322E3430  //2.40
// #define DS_PARM_VERA                        0x322E3230  //2.20
// #define DS_PARM_VERB                        0x342E3030  //4.00
// #define DS_PARM_VERC                        0x342E3230  //4.20
// #define DS_PARM_VERD                        0x322E3630  //2.60
// #define DS_PARM_VER430                      0x342E3330  //4.30
// #define DS_PARM_VER440                      0x342E3430  //4.40
#define DS_PARM_VER160                      0x312E3630  //1.60
#define DS_PARM_VER150                      0x312E3530  //1.50
#define DS_PARM_VER171                      0x312E3731  //1.71
#define DS_PARM_VER173                      0x312E3733  //1.73
#define DS_PARM_VER181                      0x312E3831  //1.81

//=========================================================================
//General defines for BiCS4 Ex3 256Gb/512Gb 2P
//=========================================================================
#define TOTAL_COL                           18560  //(16384(main) + 1952(ECC) + 220(CRD) + 2(Dummy) + 2(Flag)) = 0x4880
#define TOTAL_COL_NO_CRD                    18336  //(16384(main) + 1952(ECC)
#define TOTAL_USED_COL                      16384  //(16384(main)
#define TOTAL_PGE                           384     //(96(WLs) * 4(strings)) = 384
#define TOTAL_WL                            96      //96(WLs)
#define TOTAL_STR                           4
#define TOTAL_PLN                           2       //2 physical planes
#define TOTAL_PAGE                          (TOTAL_WL*TOTAL_STR)
#define TOTAL_PREFIX                        3       //TLC
#define FMU_SIZE                            0x11E0
   

// #define BC_START_COL                        0x000
// #define BC_STOP_COL                         0x7FF

#define TOTAL_USED_PARA                     0x140   //except temporary parameters and spare parameters
#define TOTAL_TEMP_PARA                     0x010   //0x00-0x0F
#define TOTAL_PARA                          0x150

#define BYTE_PER_COPY                       0x1000
#define BYTE_PER_PARM                       2
#define NUM_OF_COPY                         4
#define PARM_START_COL                      0xC20   //?
#define PARM_END_COL                        0xE9F   //?

// #define VDDSA                               0x01     //?

// #define VREAD_ADR                           0x1B
// #define SDE_ADR                             0x11
#define VDD_ADR                             0xDE
#define VDDA_ADR                            0xDB
#define VDDSA_PB0_ADR                       0x16
#define VDDSA_PB1_ADR                       0x17

//=========================================================================
//Address Mapping
//=========================================================================
// #define COL_TO_X0(col)                      (col & 0xFF)
// #define COL_TO_X1(col)                      ((col >> 8) & 0x7F)

// #define STR_TO_X2(str)                      (str & 0x03)
// #define WL_TO_X2(wl)                        ((wl << 2) & 0xFC)
#define WLSTR_TO_X2(wl, str)                (((wl << 2) & 0xFC) | (str & 0x03))

// #define BLK_TO_X3(blk, wl)                  (((blk << 1) & 0xFE) | ((wl >> 6) & 0x01))

//=========================================================================
//BB/BC Limit Defines
//=========================================================================
//#define BB_LIMIT_PER_DIE                            0 //do not check
// #define MAX_CLUSTER_BB_LIMIT_X4                     35
// #define MAX_CLUSTER_BB_LIMIT_X16                    20

// #define ERASE_LD_GBB_LIMIT_PER_PLN                  50
// #define ERASE_LD_GBB_LIMIT_PER_DIE                  50
// #define MARGIN_GBB_LIMIT_PER_DIE                    8

// #define GBC_LIMIT_PER_PLN_SH                        5
// #define PQ_READ_GBC_LIMIT_PER_PLN                   3

//=========================================================================
//VSGD VSGS Defines
//=========================================================================
#define WLDS0                                       0
#define WLDS1                                       1
#define WLDD0                                       2
#define WLDD1                                       3
#define SGS                                         4
#define SGD                                         5
#define WLDL                                        6
#define WLDU                                        7
#define SGSB                                        8
// #define DWL_HIGH                                    1
// #define DWL_LOW                                     0

#define HIGH_VT                                     1
#define LOW_VT                                      0

#define SGS_LEAK                                    0x04
#define SGD_LEAK                                    0x05
#define SGSB_LEAK                                   0x08
// #define SGSB_LEAK                                   0x02

//=========================================================================
//Stamp Location
//=========================================================================
#define INCOMING_BACKUP_WL                          18  //WL18 & WL19
#define INCOMING_BACKUP_STR                         0  //Str0 & Str01
#define OUTGOING_BACKUP_WL                          20 //WL20 & WL21
#define OUTGOING_BACKUP_STR                         0  //Str0 & Str01

#define DS_BACKUP_BLK                               1
#define DS_BACKUP_WL                                0x0C
#define DS_BACKUP_STR                               0

// #define DS_STAMP_BLK                                1
// #define DS_HV_CAP_STAMP_WL                          8
// #define DS_HV_CAP_STAMP_STR                         0

#define DATA_LOG_START_BLK                   0x71C
#define DATA_LOG_STOP_BLK                    0x79D

#define MTST_UROM_BLK0                              0x00  //Blk 0x00
#define MTST_UROM_BLK1                              0x01  //Blk 0x01

#define MTST_STAMP_WL                               12  //Page 30
#define MTST_STAMP_STR                              0
#define SH_STAMP_WL                                 22
#define SH_STAMP_STR                                0
// #define STAMP_BYTES                                 16

// #define KGD_STAMP_WL                                0x14
// #define KGD_STAMP_STR                               0

#define GBC_FAIL_COL                                0x1920
#define GBC_FAIL_COL_SH                             0x1910
// #define PARACHK_COL                                 0x2200
#define DATA_LOG_STAMP_COL                          0x2B00

// #define LST2MT_STAMP                                0x1
// #define CDT_STAMP                                   0x2

// #define HV_CAP_STAMP_COL                            0x1940

// #define WL_WL_AC_STAMP_WL                           0x2A  //WL8 & WL9
// #define WL_WL_AC_STAMP_STR                          1     //Str0 & Str01
// #define WL_WL_AC_STAMP_COL                          0X0040  //Str0 & Str01

#define PASS_STAMP_WL                               12  //WL 12
#define PASS_STAMP_STR                              0
#define PASS_STAMP_COL                              0x2100

// #define MTST_GBB_STAMP_WL                           0x2A
// #define MTST_GBB_FAIL_COL                           0x0080

//=========================================================================
//
//=========================================================================
// #define DUMMY                                       0
// #define ENABLE                                      TRUE
// #define DISABLE                                     FALSE

#define DONOT_CHECK                                 0
// #define CHECK_STATUS                                1

// #define CDT_TIMEOUT                                 15000 //BiCS temp change it to high time out
// #define VCC_VOLTAGE                                 360   //3.6V

#define MLC_SEED                                    0x00
#define SLC_SEED                                    0x01

#define SLC_CMD                                     0xA2
#define PREFIX1                                     0x01
#define PREFIX2                                     0x02
#define PREFIX3                                     0x03

//=========================================================================
//BLS Off screen
//=========================================================================
#define TSB_SENSE                           0
#define ABL_SENSE                           1

#define SINGLE_PLN                             1   //Single Plane
#define DUAL_PLN                               2   //Dual Plane

#define DONOT_EVEN_ODD_WL                      1   //WL 0
#define EVEN_ODD_WL                            2   //WL 0,1

// #define LOWER                               1
// #define MIDDLE                              2
// #define UPPER                               3

// #define TEST_1                              0
// #define TEST_2                              1
#define PASS                                0
#define FAIL                                1
//=========================================================================
//BLS Off screen
//=========================================================================
#define TIER0                               0
#define TIER1                               580
#define TIER2                               1740
#define TIER3                               2900
#define TIER4                               4060
#define TIER5                               5220
#define TIER6                               6380
#define TIER7                               7540
#define TIER8                               8700
#define TIER9                               9860
#define TIER10                              11020
#define TIER11                              12180
#define TIER12                              13340
#define TIER13                              14500
#define TIER14                              15660
#define TIER15                              16820
#define TIER16                              17980

//=========================================================================
//Status Command Defines
//=========================================================================
#define MLC_STATUS                                  0x71
#define SLC_STATUS                                  0x72

//=========================================================================
//2 Pass Program Defines
//=========================================================================
// #define USE_5B                                      1
// #define DONOT_USE_5B                                0
#define USE_DD                                      1
#define DONOT_USE_DD                                0
#define USE_4C                                      1
#define DONOT_USE_4C                                0
//=========================================================================
//
//=========================================================================
#define MAIN                                        0
#define TEMP                                        1
#define SUBBB                                       16
#define MARKBB                                      1
#define DONOT_MARKBB                                0
// #define SG_ON                                       1
// #define SG_OFF                                      0
#define CDT_LOG_REV                                 6
#define SHMOO                                       1
#define NOSHMOO                                     0
#define MARK_LIMIT_3                                3
#define REJECT_LIMIT_4                              4

// #define GET_FROM_NAND                               1
// #define DEFAULT_VALUE                               0

// #define SLC                                         0
// #define LOWER                                       1
// #define MIDDLE                                      2
// #define UPPER                                       3

#define THROTTLE                                    1
#define DONOT_THROTTLE                              0

#define EXIST                                       1
#define DONOT_EXIST                                 0

#define PRINT_FAIL                                  1
#define DONOT_PRINT                                 0

#define SET_AB                                      1
#define DONOT_SET_AB                                0

#define USE_2A                                      1
#define DONOT_USE_2A                                0

#define ODD_ENABLE                                  1
#define ODD_DISABLE                                 0

#define SET_9E                                      1
#define DONOT_SET_9E                                0

#define AIPR_ENABLE                                 1
#define AIPR_DISABLE                                0

#define CMDB2_ENABLE                                   1
#define CMDB2_DISABLE                                  0

#define CMD8B_ENABLE                                   1
#define CMD8B_DISABLE                                  0

#define DYNRD_ENABLE                                1
#define DYNRD_DISABLE                               0

#define DLARD_ENABLE                                1
#define DLARD_DISABLE                               0

#define FASTRD_ENABLE                               1
#define FASTRD_DISABLE                              0

#define ERS_ENABLE                                  1
#define ERS_DISABLE                                 0

#define CACHE_ENABLE                                1
#define CACHE_DISABLE                               0

#define DAC_RD                                      1
#define STATUS_RD                                   0

#define USE_VDD_PARM                                1
#define DONOT_USE_VDD_PARM                          0
// #define SKIP_WL47                                   1
// #define DONOT_SKIP_WL47                             0

// #define MONITOR_SHMOO                               1
// #define DONOT_MONITOR_SHMOO                         0

#define REPAIR                                      1
#define DONOT_REPAIR                                0

#define INVERT                                      1
#define DONOT_INVERT                                0

#define LOGCOL                                      1
#define PHYCOL                                      2

#define EXP_E0                                      0xE0
//=========================================================================
//Log Level Defines
//=========================================================================
#define LV0                                         0x00
#define LV1                                         0x01
#define LV2                                         0x02
// #define LV_DFT                                      0x04 //give an > 3 value, default value from tester /debug station setting will overwrite it
//Define datalog level for log printing
// #define LV_TEST_NAME                                0x00
#define LV_ERROR                                    0x00
// #define LV_GBB                                      0x00
// #define LV_GBB_DETAIL                               0x00
// #define LV_SUB_NAME                                 0x02
// #define LV_STATUS_RD                                0x02
// #define LV_DEBUG                                    0x02

//=========================================================================
//Delays
//=========================================================================
#define ERS_DLY                                     10
#define PGM_DLY                                     400 //100 not enough for DAT6 4.17 material, update when material improves
#define RED_DLY                                     10
#define RB_POR                                      20000
#define RB_READ                                     20000
#define RB_PROG_SLC                                 50000
#define RB_PROG_MLC                                 50000
#define RB_ERASE                                    50000    //RB_Erase = 30000, when blk fail erase it is >30ms so need a larger RB value as 50000
#define RB_BIST                                     50000
#define RB_RESET                                    30000
#define RB_LEAKAGE                                  10000
#define STOP_PGM_DLY                                100
#define STOP_PGM_DLY_SLC                            50
#define GO_PGM_DLY                                  4000
#define GO_PGM_DLY_SLC                              2000
#define RB_LOW                                      1000
#define RB_POLL                                     50000
//=========================================================================
//AC Specifications
//=========================================================================
#define TADL                                        1        //Address to data-loading time
#define TAR                                         1        //ALE low to REn low time
#define TWHWP1                                      1        //80ns (tWHWP1 can be 0ns for parameter address 00h~EAh)
#define TWHR                                        1        //WEn high to REn low time, 300ns

#define TEST_READ_DLY                               150      //AEh test read wait, 1ms
#define EXT_TIMING_READ_DLY                         300      //External timing read
#define EXT_TIMING_READ_RESET                       20000    //External timing read reset
#define DUMMY_ERASE_HALF_DLY                        24000    //Dummy erase delay 48ms. if we put 48ms, it might be over max for some env, so put the half of delay 2 times.

//=========================================================================
//NAND Related Macro Operations
//=========================================================================
#define TESTMODE                                    testmode()
#define NAND_RESET                                  nand_reset()
#define ROMBLOCK_UPDATE                             romblock_update()
#define FEATURE_RESET                               feature_reset()
#define USERROM2                                    userrom2()
#define ROMBLOCK                                    romblock()
#define BIT_IGNORE(Data)                            SET_PARAM(0x03, Data)
#define FULLARRAY_BB_CHECK                          FullArray_BB_Check()
#define GBB_MONITOR_PRINT                           BB_Monitor_Print()
#define POR_CHECK_ALL_DIE                           por_check_all_die()
#define FLASH_WRITE                                 flash_write_w_parm()

#define STATUS_RESET                                BIST(0x00,0xBB)  //BiCS4
#define XDL_INVERT                                  BIST(0x00,0xCA)  //BiCS4     //~XDL to XDL
#define ADL_TO_XDL                                  BIST(0x01,0xCA)  //BiCS4
#define XDL_TO_ADL                                  BIST(0x02,0xCA)  //BiCS4
#define BDL_TO_XDL                                  BIST(0x03,0xCA)  //BiCS4
#define XDL_TO_BDL                                  BIST(0x04,0xCA)  //BiCS4
#define CDL_TO_XDL                                  BIST(0x05,0xCA)  //BiCS4
#define XDL_TO_CDL                                  BIST(0x06,0xCA)  //BiCS4
#define TDL_TO_XDL                                  BIST(0x07,0xCA)  //BiCS4
#define XDL_TO_TDL                                  BIST(0x08,0xCA)  //BiCS4
#define XDL_SET_ONE                                 BIST(0x0F,0xCA)  //BiCS4
#define XDL_SET_ZERO                                BIST(0x10,0xCA)  //BiCS4
#define XDL_CKBD                                    BIST(0x11,0xCA)  //BiCS4
#define XDL_CKBD_BAR                                BIST(0x12,0xCA)  //BiCS4
#define XDL_XNOR_ADL                                BIST(0x13,0xCA)  //BiCS4
#define XDL_XNOR_BDL                                BIST(0x14,0xCA)  //BiCS4
#define XDL_XNOR_CDL                                BIST(0x15,0xCA)  //BiCS4
#define ALL_ONE_DETECT                              BIST(0x2E,0xCA)  //BiCS4
#define ALL_ZERO_DETECT                             BIST(0x2F,0xCA)  //BiCS4
#define ZBITSCAN_ONE                                BIST(0x30,0xCA)  //BiCS4
#define FILL_PAT                                    BIST_CMDAA(0x07)
#define ADD_BB_TO_REG                               BIST(0x0A,0xBB)  //BiCS4

//=========================================================================
//Multi CE/FIM Selection
//=========================================================================
#define FOR_EACH_PAGE(adr)                             for(uint16 page_t=0; (adr.phy.wl=page_t/4, adr.phy.str=page_t%4,page_t<TOTAL_PAGE); page_t++)
#define FOR_EACH_PAGE_LOOP(adr, start, stop, step)      for(uint16 page_t=start; (adr.phy.wl=page_t/4, adr.phy.str=page_t%4,page_t<stop); page_t+=step)
#define FOR_EACH_WL(wl)                                 for(wl=0; wl<TOTAL_WL; wl++)
#define FOR_EACH_STR(str)                               for(str=0; str<TOTAL_STR; str++)//str only have 2 bits, so that if use str directly, for loop will be endless

#define FOR_EACH_PLN(pln)                               for(pln=0; pln<TOTAL_PLN; pln++)
#define FOR_EACH_PREFIX(prefix)                         for(prefix=1; prefix<TOTAL_PREFIX+1; prefix++) // TLC only have 3 pages, prefix=1->Lower, 2->Middle, 3->Upper,so that if use prifix directly, for loop will be endless
#define FOR_EACH_LOOP(loop, start, stop, step)          for(loop=start; loop<stop; loop+=step)
#define FOR_EACH_LOOP_BACK(loop, start, stop, step)     for(loop=start; loop>stop; loop-=step) 

uint8 g_MULTIFIM_RDBYTE_FLAG = 0;
uint8 g_CMDB2_FLAG = 0;
#ifndef FOR_EACH_DIE //allow to define different die loop like MTFL which will skip bad die
    #define FOR_EACH_DIE(die)                           for(die = 0; g_MULTIFIM_RDBYTE_FLAG=0, (die < TOTAL_DIE) && Sel_CE_FIM_by_Die_Check_Die(die); die++)
#endif

#ifndef SEL_ALL_CE_FIM //allow to define different bank loop in local folder
    #define SEL_ALL_CE_FIM                              Sel_All_CE_FIM();
    #define NAND_RESET_ALL_DIE                          Sel_All_CE_FIM(); {nand_reset();}
#endif
// #define FOR_EACH_CE(ce)                             for(ce = 0; (ce < TOTAL_CE) && Sel_CE_FIM_by_Ce(ce); ce++)
//=========================================================================
//CG loop and dummy read loop
//=========================================================================
// #define FOR_EACH_LOOP(Start_loop,TOTAL_LOOP)                  for(Start_loop = 0; Start_loop < TOTAL_LOOP; Start_loop++)
//=========================================================================
//SLC Read Defines
//=========================================================================
#define ADR_Init(adr)                               adr_t adr={.phy.col = 0, .phy.str = 0, .phy.wl = 0, .phy.blk = 0}
#define PAGE_TO_WLSTR(page)                         adr.phy.wl=(page)/4; adr.phy.str=(page)%4;    


#define ALLFF                                       0xFF
#define ALL00                                       0x00
#define ALLAA                                       0xAA
// #define ASPS                                        0x01

//=========================================================================
//Weak Pump Defines
//=========================================================================
// #define RRC_EN                                      0x8
// #define RRC_DIS                                     0x0

//=========================================================================
//Die info Defines----//BiCS4
//=========================================================================
#define DIE_INFO_BLK                                0x1
#define DIE_INFO_WL                                 0xD//wl 0x0C, 0x0D, 0x0E
#define DIE_INFO_STR                                0x2//str 2&3
// #define DIE_INFO_WL_KGD                             0x14
// #define DIE_INFO_STR_KGD                            0x0
#define LOT_OFFSET                                  0x0112
#define W_OFFSET                                    0x0129
#define X_OFFSET                                    0x012B
#define Y_OFFSET                                    0x012D
#define LOT_OFFSET_CRC                              0x05
#define W_OFFSET_CRC                                0x12
#define X_OFFSET_CRC                                0x14
#define Y_OFFSET_CRC                                0x16
#define LOT_LEN                                     14
#define W_LEN                                       3
#define X_LEN                                       3
#define Y_LEN                                       3
// #define DIE_INFO_WL_DB                              0x9
// #define DB_OFFSET                                   0x201
// #define COPY_OFFSET                                 0x402
// #define START_OFFSET                                0x05
#define CRC_COPY_OFFSET                             0x402
#define CRC_BLK                                     0x1
#define CRC_WL                                      0x9
#define CRC_STR                                     0x2
#define CRC_START_OFFSET                            0x05
#define CRC_POLY                                    0x814141AB
#define CRC_POLY_HIGH                               0x01
#define CRC_DATA_LENGTH                             32
//=========================================================================
//Parameters SET/RESET
//=========================================================================
// #define SET                                         1
// #define RESET                                       0
// #define RESERVE                                     0
#define TEMP_PARM_SET                               1
#define TEMP_PARM_RESET                             0
// #define FAST_READ                                   1
// #define NO_FAST_READ                                0

//=========================================================================
//BC Printing Mask Declaration
//=========================================================================

#define PREBCMASK     0x03
#define PSTBCMASK     0x0C

// #define PREBCMASK_P0  0x03
// #define PSTBCMASK_P0  0x0C
// #define PREBCMASK_P1  0x30
// #define PSTBCMASK_P1  0xC0

#define BC_PRINT    0x01
#define GBC_PRINT   0x02
#define NOBC_PRINT  0x03







//=========================================================================
//BB Map Declaration
//=========================================================================
#if (TOTAL_DIE>8)
    uint16 BBlk_Map_Main[TOTAL_BLK];
    uint16 BBlk_Map_Temp[TOTAL_BLK];
#else
    uint8 BBlk_Map_Main[TOTAL_BLK];
    uint8 BBlk_Map_Temp[TOTAL_BLK];
#endif

//=========================================================================
//Global Variable/Array Declaration
//=========================================================================
uint16 g_DS_Parm_Ver;
uint32 g_DS_Trim_Ver;
// uint16 g_SLC_SourceBlk;
uint16 g_Incoming_BC_Cnt[TOTAL_DIE][TOTAL_PLN];
uint16 g_Temp_BC[TOTAL_DIE][TOTAL_PLN];
uint16 g_Outgoing_BC[TOTAL_DIE][TOTAL_PLN];
// uint8 g_ID_Byte[TOTAL_DIE][5];
uint8 g_Incoming_Para[TOTAL_DIE][TOTAL_PARA];

uint8 g_Update_Para_Array_En = 0;
uint8 g_Incoming_Para_Scan_En = 0;

uint8 g_temperature_array[TOTAL_DIE];
uint8 g_Temp_Col[TOTAL_COL/2];
uint16 g_TestNum;
// uint8 DEVICE_CODE_TEMP[8]={0xAA, 0x55, 0x66, 0x99, 0xCC, 0x33, 0xA5, 0x5A};
uint8 *g_BuFF_Prt;
// uint8 g_Active_CE;
// uint8 g_Active_FIM;
uint16 g_CST_BINCODE;
uint8 g_Pass_Loc;
uint8 g_Fail_Loc;
uint16 g_Temp_Bin;
// uint8 g_Mask_Rev;
// uint16 Datalog_Block_num_for_Each_Die[TOTAL_DIE];
uint16 Die_Fail_Map[2]={0,0};//Die_Fail_Map[0] is the Main die map, each bit means the pass/fail for each die. Die_Fail_Map[1] is the temp die map.
uint8 g_WXY[TOTAL_DIE][19]; //for UID info program and read

//=========================================================================
//Parity Data
//=========================================================================

uint8 PARITY_TABLE[256] =
{
/*00*/ 0x0E, 0xD9, 0x77, 0xA0, 0xFC, 0x2B, 0x85,   0x52, 0x3D, 0xEA, 0x44, 0x93, 0xCF, 0x18, 0xB6, 0x61,
/*10*/ 0x68, 0xBF, 0x11, 0xC6, 0x9A, 0x4D, 0xE3,   0x34, 0x5B, 0x8C, 0x22, 0xF5, 0xA9, 0x7E, 0xD0, 0x07,
/*20*/ 0xC2, 0x15, 0xBB, 0x6C, 0x30, 0xE7, 0x49,   0x9E, 0xF1, 0x26, 0x88, 0x5F, 0x03, 0xD4, 0x7A, 0xAD,
/*30*/ 0xA4, 0x73, 0xDD, 0x0A, 0x56, 0x81, 0x2F,   0xF8, 0x97, 0x40, 0xEE, 0x39, 0x65, 0xB2, 0x1C, 0xCB,
/*40*/ 0x41, 0x96, 0x38, 0xEF, 0xB3, 0x64, 0xCA,   0x1D, 0x72, 0xA5, 0x0B, 0xDC, 0x80, 0x57, 0xF9, 0x2E,
/*50*/ 0x27, 0xF0, 0x5E, 0x89, 0xD5, 0x02, 0xAC,   0x7B, 0x14, 0xC3, 0x6D, 0xBA, 0xE6, 0x31, 0x9F, 0x48,
/*60*/ 0x8D, 0x5A, 0xF4, 0x23, 0x7F, 0xA8, 0x06,   0xD1, 0xBE, 0x69, 0xC7, 0x10, 0x4C, 0x9B, 0x35, 0xE2,
/*70*/ 0xEB, 0x3C, 0x92, 0x45, 0x19, 0xCE, 0x60,   0xB7, 0xD8, 0x0F, 0xA1, 0x76, 0x2A, 0xFD, 0x53, 0x84,
/*80*/ 0x90, 0x47, 0xE9, 0x3E, 0x62, 0xB5, 0x1B,   0xCC, 0xA3, 0x74, 0xDA, 0x0D, 0x51, 0x86, 0x28, 0xFF,
/*90*/ 0xF6, 0x21, 0x8F, 0x58, 0x04, 0xD3, 0x7D,   0xAA, 0xC5, 0x12, 0xBC, 0x6B, 0x37, 0xE0, 0x4E, 0x99,
/*A0*/ 0x5C, 0x8B, 0x25, 0xF2, 0xAE, 0x79, 0xD7,   0x00, 0x6F, 0xB8, 0x16, 0xC1, 0x9D, 0x4A, 0xE4, 0x33,
/*B0*/ 0x3A, 0xED, 0x43, 0x94, 0xC8, 0x1F, 0xB1,   0x66, 0x09, 0xDE, 0x70, 0xA7, 0xFB, 0x2C, 0x82, 0x55,
/*C0*/ 0xDF, 0x08, 0xA6, 0x71, 0x2D, 0xFA, 0x54,   0x83, 0xEC, 0x3B, 0x95, 0x42, 0x1E, 0xC9, 0x67, 0xB0,
/*D0*/ 0xB9, 0x6E, 0xC0, 0x17, 0x4B, 0x9C, 0x32,   0xE5, 0x8A, 0x5D, 0xF3, 0x24, 0x78, 0xAF, 0x01, 0xD6,
/*E0*/ 0x13, 0xC4, 0x6A, 0xBD, 0xE1, 0x36, 0x98,   0x4F, 0x20, 0xF7, 0x59, 0x8E, 0xD2, 0x05, 0xAB, 0x7C,
/*F0*/ 0x75, 0xA2, 0x0C, 0xDB, 0x87, 0x50, 0xFE,   0x29, 0x46, 0x91, 0x3F, 0xE8, 0xB4, 0x63, 0xCD, 0x1A
};

//=========================================================================
//Parameter declarations
//=========================================================================
typedef struct
{
   uint16 addr;
   uint8 value;
   uint16 mask;  //lower 8 bit: bit mask, upper 8 bit: indicate plus/minus
} Para_Table;


typedef struct
{
   uint16 GBB_CHECK_DIE;
   uint16 GBB_CHECK_PLN;
   uint8 MarkBB;  
} GBB_Check_t;

#define GBB_Check_Init(GBB_limit)       GBB_Check_t GBB_limit={.GBB_CHECK_DIE=DONOT_CHECK_GBB_DIE,.GBB_CHECK_PLN=DONOT_CHECK_GBB_PLN,.MarkBB=DONOT_MARKBB}

#define PLUS      0x100
#define MINUS     0x200
#define UPDATE    0x400

#define SET_PARAMETERS(die, Para_Array)    Set_Parameters(die, Para_Array, sizeof(Para_Array)/sizeof(Para_Table))
#define RESET_PARAMETERS(die, Para_Array)  Reset_Parameters(die, Para_Array, sizeof(Para_Array)/sizeof(Para_Table))
#define SET_PARAMETERS_ALL_DIE(Para_Array)    Set_Parameters_All_Die(Para_Array, sizeof(Para_Array)/sizeof(Para_Table))
#define RESET_PARAMETERS_ALL_DIE(Para_Array)  Reset_Parameters_All_Die(Para_Array, sizeof(Para_Array)/sizeof(Para_Table))
#define UPDATE_PARA_ARRAY(Para_Array,Para_addr,Para_value,Para_bitmask)  Update_Para_Array(Para_Array, sizeof(Para_Array)/sizeof(Para_Table), Para_addr, Para_value, Para_bitmask)

//=========================================================================
//External function & declarations
//=========================================================================

/*uint8 ZerosSetTable256[]=
{
	8,7,7,6,7,6,6,5,7,6,6,5,6,5,5,4,
	7,6,6,5,6,5,5,4,6,5,5,4,5,4,4,3,
	7,6,6,5,6,5,5,4,6,5,5,4,5,4,4,3,
	6,5,5,4,5,4,4,3,5,4,4,3,4,3,3,2,
	7,6,6,5,6,5,5,4,6,5,5,4,5,4,4,3,
	6,5,5,4,5,4,4,3,5,4,4,3,4,3,3,2,
	6,5,5,4,5,4,4,3,5,4,4,3,4,3,3,2,
	5,4,4,3,4,3,3,2,4,3,3,2,3,2,2,1,
	7,6,6,5,6,5,5,4,6,5,5,4,5,4,4,3,
	6,5,5,4,5,4,4,3,5,4,4,3,4,3,3,2,
	6,5,5,4,5,4,4,3,5,4,4,3,4,3,3,2,
	5,4,4,3,4,3,3,2,4,3,3,2,3,2,2,1,
	6,5,5,4,5,4,4,3,5,4,4,3,4,3,3,2,
	5,4,4,3,4,3,3,2,4,3,3,2,3,2,2,1,
	5,4,4,3,4,3,3,2,4,3,3,2,3,2,2,1,
	4,3,3,2,3,2,2,1,3,2,2,1,2,1,1,0
};
*/

uint8 ERROR_FLAG;
uint8 Current_Die;

#define NLE_SLC_ADR                                 0x12F   //[7:4]
#define NLE_MLC_ADR                                 0x12F   //[3:0]
#define NLP_MLC_ADR                                 0x133   //[4:0]
#define NLP_SLC_ADR                                 0x131   //[3:0]
#define BSPF_EV_ADR                                 0x137   //MLC:[2:0], SLC:[5:3]

#define NLE_SLC_ADJ                                 0x40   //[7:4], -4 loops
#define DONOT_CHECK_GBB_PLN                         0xFFFF
#define DONOT_CHECK_GBB_DIE                         0xFFFF
#define PAIR_1                                      1
#define PAIR_2                                      2
#define PAIR_4                                      4
#define PAIR_10                                     10
#define PAIR_12                                     12
#define PAIR_24                                     24
#define COPIES_3                                    3
#define BYTE_8                                      8
#define BYTE_100                                    100
#define BIT_IGNORE_10000                            10000
#define BIT_IGNORE_255                              255
#define BIT_IGNORE_150                              150
#define BIT_IGNORE_140                              140
#define BIT_IGNORE_110                              110
#define BIT_IGNORE_100                              100
#define BIT_IGNORE_90                               90
#define BIT_IGNORE_80                               80
#define BIT_IGNORE_75                               75
#define BIT_IGNORE_70                               70
#define BIT_IGNORE_55                               55
#define BIT_IGNORE_32                               32
#define BIT_IGNORE_28                               28
#define BIT_IGNORE_16                               16
#define BIT_IGNORE_10                               10
#define BIT_IGNORE_8                                8
#define BIT_IGNORE_5                                5
#define BIT_IGNORE_4                                4
#define BIT_IGNORE_2                                2
#define BIT_IGNORE_1                                1
#define BIT_IGNORE_0                                0
#define DLY_0                                       0
#define DLY_100                                     100
#define DLY_200                                     200
#define DLY_300                                     300
#define DLY_400                                     400
#define DLY_1000                                    1000
#define SLC_ERASE                                   1
#define MLC_ERASE                                   0
#define SLC_READ                                    1
#define MLC_READ                                    0
#define PARAM_COUNT_8                               8
#define PARAM_COUNT_16                              16
#define BC_IGNORE_0                                 0
#define CYCLE_20                                    20

#define IO_0                                        0
#define IO_1                                        1
#define IO_2                                        2

#define DIE0                                        0
#define WL0                                         0
#define WL1                                         1
#define WL2                                         2
#define WL3                                         3
#define WL10                                        10
#define WL18                                        18
#define WL19                                        19
#define WL20                                        20
#define WL21                                        21
#define WL24                                        24
#define WL47                                        47
#define WL48                                        48
#define WL51                                        51
#define WL64                                        64
#define WL72                                        72
#define STR0                                        0
#define STR1                                        1
#define STR2                                        2
#define STR3                                        3

#define BIN_FAIL                                    1

#define DATA_BAR                                    0
#define DATA_PARITY                                 1
#define ADL_PATTERN                                 0x13
#define BDL_PATTERN                                 0x14
#define CDL_PATTERN                                 0x15
#define SLC                                         0
#define LOWER                                       1
#define MIDDLE                                      2
#define UPPER                                       3
#define TLC                                         0xFF
#define ONE_BLK                                     1
#define BLK0_1                                      2
#define BLK1										1

#define PLN_0                                       0
#define PLN_1                                       1

#define BUF0                                        0
#define BUF1                                        1
#define BUF2                                        2
#define BUF3                                        3

#define CLUSTER_LIMIT_20                            20
#define CLUSTER_LIMIT_32                            32
#define CLUSTER_LIMIT_35                            35


//=========================================================================
//Majority Vote
//=========================================================================

typedef struct
{
    uint16 vote_value;
    uint16 vote_cnt;
    uint8 win_flag;
} Majority_Vote;

#define INIT_VOTE_ARRAY(vote_array) Init_Vote_Array(vote_array, sizeof(vote_array) / sizeof(Majority_Vote))
#define INSERT_VOTE_ARRAY(vote_array, insert_value) Insert_Value_to_Vote_Array(vote_array, insert_value, sizeof(vote_array) / sizeof(Majority_Vote))
#define OUTPUT_VOTE_RESULT(vote_array) Output_Max_Vote_Index(vote_array, sizeof(vote_array) / sizeof(Majority_Vote))
