/*******************************************************************************
    File name   : Macro_256Gb.h
    Description : To define value for specific memory config
    Device      : BiCS4.5 X3 256Gb
 *******************************************************************************/
typedef struct
{
    uint16 col;
    uint8 str;
    uint8 wl;
    uint16 blk;
}phy_t;

typedef struct 
{
    phy_t phy;
}adr_t;

typedef union
{
    struct
    {
        uint64 col  : 15;
        uint64 rfu1 : 1;
        uint64 str  : 2;
        uint64 wl   : 7;
        uint64 blk  : 11;
        uint64 die  : 3;
        uint64 rfu2 : 1;
    } phy;
    uint8 X[5];
    uint64 all;
} union_adr_t;

#define DENSITY_512                          FALSE
#define DENSITY_256                          TRUE
#define TOTAL_BLK                            1948
#define BB_START_COL                         0x800
#define BB_STOP_COL_WO_SWAP                  0x9EF
#define BB_STOP_COL_SWAP                     0x9F7
#define BB_PHY0_START                        0
#define BB_PHY0_STOP                         992
#define BB_PHY1_START                        1
#define BB_PHY1_STOP                         993
#define BB_PHY2_START                        992
#define BB_PHY2_STOP                         1948
#define BB_PHY3_START                        993
#define BB_PHY3_STOP                         1949


// #define MLC_EPR_SAPL_START1                  0
// #define MLC_EPR_SAPL_END1                    32
// #define MLC_EPR_SAPL_START2                  958
// #define MLC_EPR_SAPL_END2                    990
// #define MLC_EPR_SAPL_START3                  1946
// #define MLC_EPR_SAPL_END3                    1978
// #define MLC_EPR_SAPL_START4                  992
// #define MLC_EPR_SAPL_END4                    1024

#define MARGIN_G0_START                      0x0
#define MARGIN_G0_END                        0x10
#define MARGIN_G1_START                      0x3D0
#define MARGIN_G1_END                        0x3E0
#define MARGIN_G2_START                      0x3E0
#define MARGIN_G2_END                        0x3F0

#define PSR_BLK_START_1                      0
#define PSR_BLK_END_1                        96
#define PSR_BLK_START_2                      96
#define PSR_BLK_END_2                        288
#define PSR_BLK_START_3                      64
#define PSR_BLK_END_3                        175
#define PSR_BLK_START_4                      608
#define PSR_BLK_END_4                        832
#define PSR_BLK_START_5                      1024

#define BLK_CNT_8                            8
// #define WEAK_PUMP_ERASE_GBB_LIMIT            8

// #define DIE_TO_X4(die)                      (die << 4)
// #define DIE_BLK_TO_X4(die, blk)             ((die << 4)|((blk >> 7) & 0x0F))

#define TOP_BLK_EDGE                         990
#define BOT_BLK_EDGE                         992

#ifdef NDIE_1_SW
    #define DEVCODE                          0x3C    //Capacity/CE, 3A=126Gb, 3C=256Gb, 3E=512Gb, 48=1024Gb, 49=2049Gb
    #define DEVCODE_OUT                      0x3C
#endif

#ifdef NDIE_2_SW
    #define DEVCODE                          0x3E    //Capacity/CE, 3A=126Gb, 3C=256Gb, 3E=512Gb, 48=1024Gb, 49=2048Gb
    #define DEVCODE_OUT                      0x3C
#endif

#ifdef NDIE_4_SW
    #define DEVCODE                          0x48    //Capacity/CE, 3A=126Gb, 3C=256Gb, 3E=512Gb, 48=1024Gb, 49=2048Gb
    #define DEVCODE_OUT                      0x3C
#endif

#ifdef NDIE_8_SW
    #define DEVCODE                          0x49    //Capacity/CE, 3A=126Gb, 3C=256Gb, 3E=512Gb, 48=1024Gb, 49=2048Gb
    #define DEVCODE_OUT                      0x3E
#endif



// //=========================================================================
// //Sample BLK range
// //=========================================================================
#define MLC_EP_G0_START                             0x3D0
#define MLC_EP_G0_END                               0x3DF
#define MLC_EP_G1_START                             0
#define MLC_EP_G1_END                               0x0F
#define MLC_EP_G2_START                             0x3E0
#define MLC_EP_G2_END                               0x3EF

#define MLC_RE_G0_START                             0x3D0
#define MLC_RE_G0_END                               0x3DF
#define MLC_RE_G1_START                             0
#define MLC_RE_G1_END                               0x0F
#define MLC_RE_G2_START                             0x3E0
#define MLC_RE_G2_END                               0x3EF

// //=========================================================================
// //Edge BLK
// //=========================================================================
// #define EDGE_BLK_0                                  0x3DE
// #define EDGE_BLK_1                                  0x3DF
// #define EDGE_BLK_2                                  0x3E0
// #define EDGE_BLK_3                                  0x3E1

#define UR_REPAIR_BLK_START_P0                         1810
#define UR_REPAIR_BLK_STEP                             18

#define CLUSTER_X2_LIMIT                            32

// #define RF_BB_END_COL                               0x9F7 // BB_STOP_COL+SWAP_FLAG_COL

uint8 DIE_TYPE[17] = {0x42, 0x69, 0x43, 0x53, 0x34, 0x70, 0x35, 0x20, 0x32, 0x35, 0x36, 0x47, 0x62, 0x20, 0x56, 0x4C, 0x56}; //BiCS4p5 256Gb VLV
