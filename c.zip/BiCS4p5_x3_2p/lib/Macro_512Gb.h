/*******************************************************************************
    File name   : Macro_512Gb.h
    Description : To define value for specific memory config
    Device      : BiCS4.5 X3 512Gb
*******************************************************************************/
typedef struct
{
    uint16 col;
    uint8 str;
    uint8 wl;
    uint16 blk;
}phy_t;

typedef struct 
{
    phy_t phy;
}adr_t;

typedef union
{
    struct
    {
        uint64 col  : 15;
        uint64 rfu1 : 1;
        uint64 str  : 2;
        uint64 wl   : 7;
        uint64 blk  : 12;
        uint64 die  : 3;
    } phy;
    uint8 X[5];
    uint64 all;
} union_adr_t;

#define DENSITY_512                         TRUE
#define DENSITY_256                         FALSE
#define TOTAL_BLK                           3884
#define BB_START_COL                        0x800
#define BB_STOP_COL_WO_SWAP                 0xBCF
#define BB_STOP_COL_SWAP                    0xBD7
// #define CBB_G0_START                        0
// #define CBB_G0_STOP                         0
// #define CBB_G1_START                        0
// #define CBB_G1_STOP                         0
// #define CBB_G2_START                        0
// #define CBB_G2_STOP                         0
// #define CBB_G3_START                        0
// #define CBB_G3_STOP                         0

#define BB_PHY0_START                       0
#define BB_PHY0_STOP                        1968
#define BB_PHY1_START                       1
#define BB_PHY1_STOP                        1969
#define BB_PHY2_START                       1968
#define BB_PHY2_STOP                        3884
#define BB_PHY3_START                       1969
#define BB_PHY3_STOP                        3885

// #define MLC_EPR_SAPL_START1                 0
// #define MLC_EPR_SAPL_END1                   32
// #define MLC_EPR_SAPL_START2                 1934
// #define MLC_EPR_SAPL_END2                   1966
// #define MLC_EPR_SAPL_START3                 3882
// #define MLC_EPR_SAPL_END3                   3914
// #define MLC_EPR_SAPL_START4                 1968
// #define MLC_EPR_SAPL_END4                   2000

#define MARGIN_G0_START                      0x0
#define MARGIN_G0_END                        0x10
#define MARGIN_G1_START                      0x7A0
#define MARGIN_G1_END                        0x7B0
#define MARGIN_G2_START                      0x7B0
#define MARGIN_G2_END                        0x7C0

#define PSR_BLK_START_1                      0
#define PSR_BLK_END_1                        96
#define PSR_BLK_START_2                      96
#define PSR_BLK_END_2                        288
#define PSR_BLK_START_3                      64
#define PSR_BLK_END_3                        175
#define PSR_BLK_START_4                      608
#define PSR_BLK_END_4                        832
#define PSR_BLK_START_5                      1024

#define BLK_CNT_8                            8

// #define VREAD_MARGIN_G0_START                0     //TODO
// #define VREAD_MARGIN_G0_END                  2     //TODO
// #define VREAD_MARGIN_G1_START                980   //TODO
// #define VREAD_MARGIN_G1_END                  982   //TODO
// #define VREAD_MARGIN_G2_START                998   //TODO
// #define VREAD_MARGIN_G2_END                  1000  //TODO

// #define VCGRV_DS0_LOW                       3200 //VCGRV_DS0 3200mV
// #define VCGRV_DS0_HIGH                      5500 //VCGRV_DS0 5500mV
// #define VCGRV_DS1_HIGH                      2000 //VCGRV_DS1 2000mV
// #define VCGRV_DD0_HIGH                      2000 //VCGRV_DD0 2000mV
// #define VCGRV_DD1_HIGH                      2000 //VCGRV_DD1 2000mV

// #define HIGH_SGS_READ                       5750 //High SGS : VCGRV 5750mV
// #define HIGH_SGD_READ                       5500 //High SGD : VCGRV 5500mV
// #define LOW_SGS_READ                        2500 //Low SGS  : VCGRV 2500mV
// #define LOW_SGD_READ                        2500 //Low SGD  : VCGRV 2500mV

// #define WEAK_PUMP_ERASE_GBB_LIMIT           20

// #define DIE_TO_X4(die)                      (die << 5)
// #define DIE_BLK_TO_X4(die, blk)             ((die << 5)|((blk >> 7) & 0x1F))

#define TOP_BLK_EDGE                        1966
#define BOT_BLK_EDGE                        1968

#ifdef NDIE_1_SW
    #define DEVCODE                             0x3E    //Capacity/CE, 3A=126Gb, 3C=256Gb, 3E=512Gb, 48=1024Gb, 49=2048Gb
    #define DEVCODE_OUT                         0x3E
#endif

#ifdef NDIE_2_SW
    #define DEVCODE                             0x48
    #define DEVCODE_OUT                         0x3E
#endif

#ifdef NDIE_4_SW
    #define DEVCODE                             0x49
    #define DEVCODE_OUT                         0x3E
#endif

#ifdef NDIE_8_SW
    #define DEVCODE                             0x40
    #define DEVCODE_OUT                         0x48
#endif


// //=========================================================================
// //Sample BLK range
// //=========================================================================
#define MLC_EP_G0_START                             0x7A0
#define MLC_EP_G0_END                               0x7AF
#define MLC_EP_G1_START                             0
#define MLC_EP_G1_END                               0x0F
#define MLC_EP_G2_START                             0x7B0
#define MLC_EP_G2_END                               0x7BF

#define MLC_RE_G0_START                             0x7A0
#define MLC_RE_G0_END                               0x7AF
#define MLC_RE_G1_START                             0
#define MLC_RE_G1_END                               0x0F
#define MLC_RE_G2_START                             0x7B0
#define MLC_RE_G2_END                               0x7BF

// //=========================================================================
// //Edge BLK
// //=========================================================================
// #define EDGE_BLK_0                                  0x7AE
// #define EDGE_BLK_1                                  0x7AF
// #define EDGE_BLK_2                                  0x7B0
// #define EDGE_BLK_3                                  0x7B1

#define UR_REPAIR_BLK_START_P0                         3634
#define UR_REPAIR_BLK_STEP                             34

#define CLUSTER_X2_LIMIT                            62

// #define RF_BB_END_COL                               0xBE7 // BB_STOP_COL+SWAP_FLAG_COL
#define RF_BB_END_COL_WO_SWAP                          0xBCF

uint8 DIE_TYPE[17] = {0x42, 0x69, 0x43, 0x53, 0x34, 0x70, 0x35, 0x20, 0x35, 0x31, 0x32, 0x47, 0x62, 0x20, 0x56, 0x4C, 0x56}; //BiCS4p5 512Gb VLV
